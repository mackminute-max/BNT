from pathlib import Path
import json,csv,hashlib,subprocess
O=Path(__file__).resolve().parents[1];E=O/'evidence';r=Path('/workspace/BNT');load=lambda n:json.loads((E/n).read_text());base=load('baseline-verification.json');growth=load('existing-growth.json');cap=load('capacity-results.json');model=load('prototype-tests.json');db=load('idb-results.json');mem=load('memory-transfer.json')
def write(n,t):(O/n).write_text(t.strip()+'\n')
def table(h,rows):return '| '+' | '.join(h)+' |\n| '+' | '.join('---'for _ in h)+' |\n'+'\n'.join('| '+' | '.join(str(v).replace('|','/')for v in row)+' |'for row in rows)+'\n'
H='**M5-A investigation only • 24 November 2026.** Prototypes are isolated from native modules and player saves. No production source, persistence format, artifact, balance or gameplay was changed. All architecture below is proposed, not implemented acceptance.'
refs='''Source anchors: `src/persistence/envelope.js:8–81` seals primary/recovery and retained history; `career/championships/e5/schema6.js:40–49` replays all schema6 receipts from nested origin and compares full state; `cycles/schema4.js:65–89`, `championships/controller.js:80+` enforce older nested reconstruction; `economy/protected-registry.js` merge/lookup/historyRetentionPlan forbids compaction today; `persistence/e4/worker-service.js:28–70` validates exact career bytes and every retained official session; `e4/indexeddb.js:9–17,31–51` bounds logical records and atomically publishes head/previous; `e4/backup.js:2–16` bounds and verifies complete backups; `career-store.js:160–188` confirms recovery/export. This cannot be replaced by simply deleting arrays from a schema6 save.'''
write('BNT_M5A_Persistence_Feasibility_Report.md',f'''# BNT M5-A — Persistence Feasibility Report

{H}

## Executive verdict

**Protected checkpointing is feasible, with explicit new authority/format and validator work required before production.** Recommend Option B: current validated state becomes an authoritative checkpoint; bounded post-checkpoint journal; immutable paged compact history; active championship evidence kept intact; current and previous root manifests reference shared records. Keep native economic/racing/reward semantics, replace lifetime replay as the *sole* source of current-state authority. Do not increase limits.

This is not a drop-in serializer patch. Current schema6 validators require full historical origins and receipts, and the coordinator embeds all record bytes in each head. A versioned current-state validator and typed record references are mandatory. The owner-approved single-player threat model makes a checksummed validated checkpoint practical; cryptographic proof against a local save editor is neither provided nor required.

## Verified baseline

Branch `{base['branch']}`, HEAD `{base['head']}`. Accepted M4 source is the existing uncommitted working-tree candidate, source manifest `e2bc429c8f27cea1edeb2d0c9dd0117f21527a16762f4da5394a4697fdc81c75`; all187 source and53 changed-file hashes match. Accepted HTML3,159,171 bytes/SHA256 `d77e49e40457c5de0255e3c95779941bec67023a4760248a69760f60b7a8d60c`. All pre-existing modified/untracked files preserved, including the unrelated preimplementation audit. No branch/commit created. Files/hashes/status are recorded in evidence/.

{refs}

## Measured growth

The accepted four-championship/eight-event backup was read, not modified. Its career envelope is2,078,020 bytes; session records3,089,129 bytes; nine logical records total5,167,149 bytes; complete JSON backup5,438,562 bytes, with no previous root supplied in that historical fixture. IDB itself additionally keeps previous generation.

Envelope primary984,425 bytes + recovery978,712 bytes account for94.5% of that envelope. Its outer protectedHistory adds114,365 bytes. Primary state contains transactions89,504, history114,359, championshipFoundation372,101 and e5 337,442 bytes. Current e5.board79,625 + foundation.offers75,647 duplicate static schedule/geometry disclosures. e5.origin199,777 includes its own nested origins; current foundation.origin126,674 is another branch. **Nested measurements overlap; do not sum every reported origin depth as disjoint data.** Archive/controller result records and terminal facts remain in several representations, while full cleared race sessions remain separately retained.

Three→four championships adds244,199 envelope bytes and10 receipts in this two-event controlled historical fixture. Growth includes repeated receipts/protected command request/result encodings and detailed official result/settlement histories, not just fixed initial migration origins. Native full validateStateV6 took~{growth[-1]['nativeValidateV6Ms']:.1f}ms for the four-championship primary in this run. It verifies substantially more semantics than the prototype hash scan, so ratios are not equivalent workload speedups.

## Feasibility evidence

-25 isolated model checks pass: checkpoint rollover, absolute revision, duplicate/lost acknowledgment, stale writer, journal gaps, version/corruption, prior-generation reconstruction, ownership/financial invariants and injected quota denial.
-9 Chromium HTTP/temporary-IDB checks pass: atomic birth/abort/rollover, duplicate after rollover, competing connections, cold open, lost acknowledgment and page reload; actual large chunked synthetic dataset retained.
-36 existing persistence/worker/stage2 Node tests pass. Full888 baseline/browser/Windows acceptance was not rerun or re-certified.
-Synthetic target500 championships/5,000 races/50,000 financial-management summaries/100,000 generated candidates/128 recurring teams materializes11,695,000 logical bytes across bounded records,11,725,664-byte backup,228,222-byte checkpoint. No expired unused offers remain active;100 current offers retained. These are **representative synthetic records**, not50,000 executed transactions or5,000 completed native races.

## Principal limitations

Current8MiB career record and1,000 lifetime receipts fail the requested horizon; observed two-event fixture extrapolation reaches8MiB around championship30, not a certified production limit. Limits alone cannot solve repeated reconstruction and session retention. Paging histories below8MiB per record is necessary; putting everything into a new single checkpoint would merely move the problem. The256MiB backup limit has substantial synthetic headroom but browser quota varies.

Prototype current-state validation is intentionally incomplete: the model validates financial/ownership invariants and hashed journal transitions, not all M4 Legacy, payroll, graph, title, reward and clearance rules. Native checkpoint import requires full validateStateV6 **once before conversion** and a complete new current-state validator thereafter. This work is a production gate, not proven by prototype success.

Browser diagnostic observed a104ms long task, above the100ms preferred E4 target. Bulk export/decode/history inspection must stay in a worker with bounded/progressive transfer. Atomic IDB completion latency is asynchronous and must not be confused with uninterrupted main-thread time. Node transfer/memory samples are not browser production budgets.

## Required conclusion /13 answers

1. Yes, checkpointing is technically feasible; not production-ready without new validators/record contracts.
2. Career envelope duplication + repeated authoritative history/results and retained full sessions dominate; initial origins contribute fixed overhead.
3. After final settlement and pending permanent selection/archive: compact old native proofs/sessions into checked official summaries plus immutable names/awards/settlement refs; retire unused offers once their source effects are checkpointed. Active/pending claims and results remain complete.
4. Authority is created by validated native reducer/current state →validated checkpoint →hash/manifest →single completed IDB transaction. Cold-load state invariants and all referenced records remain verified.
5. Absolute operation revision and command epoch survive rollover; bounded recent receipt cache supports lost ack; permanent semantic counters/tombstones/summary references prevent old acquisitions/results/rewards being applied with a new wrapper ID. Old original commands are stale, not replayed.
6. Yes, expired unused offers can leave active state after new checkpoint authority replaces old offer-dependent replay; not safe under current schema6 reconstruction.
7. Yes, fixed128 or fewer recurring identities plus paged encounter summaries can remain bounded; no rival economics.
8. Targets fit this synthetic representation; full native long-career/cold validation/backup and browser quota remain acceptance gates.
9. Less repeated reconstruction/write volume expected, history cold verification still linear; large clone/export tasks remain measurable costs.
10. A wholesale Option C replacement is not currently justified over bounded Option B; a breaking development-save version is appropriate to avoid carrying every old layer forward.
11. Persistence implementation should precede renewable production integration; content/schema work can proceed in parallel.
12. Implement current-state boundary and journal correctness, paged storage/recovery/export, then generated assets/rivals/markets; complete bounded end-to-end tests before release.
13. Owner must authorize exact production checkpoint format/coordinator changes and explicit development-save transition. History compaction sacrifices full old-race replay/forensic reconstruction after finalization; that is consistent with approved direction but should be stated in implementation authorization. No owner-edit-proof trust claim or limit increase recommended.
''')
ret=[['Current assets/employment/finance','Permanent current authority','Keep native values/ownership/capacity/contracts/unpaid claims; do not synthesize original grants.'],['Owner Legacy/unlocks/trophies','Permanent authority + history refs','Keep balances/owned upgrades/loadout/qualifications and once-only semantic facts; repeated award descriptions static-ref + stable historical labels.'],['Active/pending championship','Full active authority','Keep frozen roster/rules/progression/setup, results and pending choices/settlement/publication recovery. No compaction on a finish-line display.'],['Past official championships/races','Compact immutable history pages','Full-precision classification, participant/start/title eligibility, scores, names, payout/condition/settlement references; no telemetry required for normal history UI.'],['Historical acquisitions/retirements','Compact authority/history','Owned identity/current economics permanent while relevant; after retirement preserve required ownership/effect provenance and finance summary, not the unpurchased candidate pool.'],['Market offers','One active renewable batch','Persist final candidates + epoch/pins; obsolete unused listings removable only after source transactions checkpointed.'],['Rival identities','Bounded permanent population','Stable organization/member IDs/personality/strength; encounters paged; no player graph or offscreen economy.'],['Completed detailed race sessions','Disposable after archival checkpoint','Only once official conditions/rewards/settlement facts retained and pending recovery paths no longer reference session. Existing worker requires them today.'],['Checkpoint/journal/current+previous','Operational authority','Current and previous manifest roots retain necessary journal tail/checkpoint/pages; garbage collect only unreachable records after atomic publication.'],['Static catalogs/geometry/source prose','Embedded static content','Reference version/digest, freeze full resolved active setup where native requires; do not duplicate whole static catalogs in every career.'],['Presentation sidecar/profile slots/options','Scoped persistent metadata','Preserve immutable identity pin, mutable radio/team selection, ownership and export/import rules; global options stay outside career mechanics.'],['Generation intermediates/telemetry','Disposable','Unacknowledged preparation can be abandoned; no accepted effect lives only in a worker.']]
write('BNT_M5A_Proposed_Persistence_Architecture.md',f'''# BNT M5-A — Proposed Persistence Architecture

{H}

## Structure

Proposed new save family (working name schema7, **not assigned/implemented**):

```text
manifest(version, career/profile identity, generation, checkpointRef,
         journalRef, historyPageRefs, pendingOperationRefs, catalogPins)
checkpoint(schema/rules, sequence, absoluteBaseRevision, currentState,
           historyRoots, generationEpochs, semanticHighWatermarks, parentRef)
journal(baseCheckpointHash, baseRevision, contiguous operations, resultHash)
historyPages(typed immutable official summaries, exact IDs/names, digest)
previousManifest -> complete previous valid checkpoint/journal/page set
```

Logical records remain≤8MiB and backup≤256MiB. History is partitioned into bounded pages (prototype128 rows/page is an engineering test choice, not final content policy). Keep the existing IndexedDB/inline-worker direction and atomic transaction principle. Extend coordinator to immutable record-body entries and small root references; current `head.records` inline arrays would still copy all history and should not be the final layout. New record-key whitelist, decoder and version required; current code is unchanged.

## Checkpoint authority

Create only from an already validated current state after all accepted operations finish. First conversion from accepted M4 must validate full schema6 before projecting; future checkpoints use complete current-state graph/finance/employment/progression/championship validators plus the bounded journal. Checksum/SHA protects accidental corruption; it does not establish correctness or authenticate an owner-edited save. Never trust a caller cache token. Rules/schema/catalog pins reject incompatible content; do not reroll.

Worker prepares/validates/encodes candidate; the main coordinator checks exact generation/read-set and commits records+current root+previous root in **one IDB transaction**; acknowledgment only after oncomplete. Preparation message success is not durability. Web Locks serialize friendly writers; IDB CAS handles stale tabs even if lock support fails. Worker failure before commit leaves old head; failure after commit but before acknowledgment reloads the new head and recovers the stored operation identity/result.

## Journal rollover and identity

Absolute career revision never resets to tail length. Each command carries checkpoint/command epoch, expected revision and source/effect scope. New command IDs must be structurally bound to operation epoch/sequence, not arbitrary globally reusable strings. Keep a bounded recent acknowledgment cache across rollover (prototype64); semantic once-only facts survive in current authority or indexed compact summaries: offer epoch+ID, acquisition ID, event/result ID, championship/settlement ID, reward-offer selection and upgrade ownership.

Rollover folds the fully validated journal into a new checkpoint, increments checkpoint sequence, sets absoluteBaseRevision, and clears only the incorporated tail. A stale command outside the receipt cache is rejected as obsolete and requires current-state read; it must never be silently retried as a new operation. If an ancient acknowledgment's detailed receipt is no longer available, report incorporated/obsolete with domain status lookup, not fabricated success or a duplicate effect. The prototype's small reducer is not a substitute for this full native contract.

## Trigger policy

Recommend automatic low-watermark scheduling after final championship settlement **and** permanent selection/archive, or a management tail/byte threshold. Initial engineering thresholds could be128–256 tail operations and a measured byte watermark below8MiB; determine during production benchmarks. Manual Save Game verifies durable accepted state and may coalesce a pending safe checkpoint; it does not save unfinished race ticks. Before registration reserve sufficient journal/size budget for worst-case supported events and allowed management transitions. If needed, snapshot-only checkpoint at a resolved intermission can retain the entire active aggregate, but do not compact its evidence; prove native anchor compatibility first. Never checkpoint ordinary playback.

## Retention classification

{table(['Category','Class','Policy'],ret)}

## Recovery / backup

Load root and referenced records, validate hashes/schema/identity, validate current native invariants, replay contiguous tail and compare resulting revision. Missing journal/page or contradictory publication evidence blocks; do not restart a completed result or create a DNF. For a corrupt latest root, validate previous root completely and present explicit recovery. Prior-generation reconstruction is proven by the prototype; **production activation must create a new monotonic generation**, not rewind generation counters or overwrite an unrelated career. Restoring older progress can lose newer facts; show replacement scope, preserve original data/quarantine and obtain explicit confirmation. No local system can recover destroyed acknowledged bytes with no valid copy.

Default portable export can become one complete between-race career package containing current/previous roots and deduplicated referenced pages/session evidence. Legacy career-only exports should remain clearly identified if they omit required external authority; do not label incomplete exports complete. Multi-career slots and global preferences remain distinct. Staged restore validates all references, invariants and destination identity/capacity before atomic activation; incompatible formats fail without replacing bytes. Same backend can stage immutable records; never pretend separate independent writes activate atomically. Test restore interruptions on every boundary.

## Procedural integration

Commit generation seed domain/catalog version/epoch and final active offers. Viewing never renews. Epoch replacement and purchase use native quote/capacity/contract reducers; after incorporation into a protected checkpoint, expired unused candidates no longer need indefinite retention. Acquired names/stats/personality remain durable independent of catalog updates.

Keep bounded rival organization/member state outside the player's ownership graph; per-championship entrant IDs map to stable rival IDs. Freeze coherent native attributes/identity at registration. Result-keyed encounters append compact pages once; historical names remain frozen even if an active rival is retired. No per-tick writes or offscreen organization simulation.

## Validation still required

Current native reducers mix source-fingerprint/history lookup with mechanics. Extract/adapter-test pure mechanics without bypassing quotes, wages, D2 or reward effects. Add schema7 current-state validator and checkpoint rebase command envelope; do not call old validateStateV6 with stripped origins. Race clearance/native prepare/capability →single official commit remains unchanged semantically. This is a bounded authority replacement at checkpoint boundaries, not permission to invent a second economy.
''')
write('BNT_M5A_Capacity_and_Performance_Report.md',f'''# BNT M5-A — Capacity and Performance

{H}

## Method and environment

Node24.22.1/Linux; existing installed tooling, isolated Node worker and Chromium `{db.get('browserVersion','recorded in evidence')}`. Native fixtures are accepted M4 historical backups read-only and a new private Map career; synthetic workload labels are explicit. Timings are single-run development diagnostics, not percentile guarantees or equivalent-validator speedup claims. Browser diagnostic shared the managed container with other verification; no exclusive CPU or Windows validation.

## Existing baseline

{table(['Fixture','Career envelope bytes','Receipts','Native schema6 validation ms','Read/parse ms'],[[x['label'],x['careerEnvelopeBytes'],x['receipts'],round(x['nativeValidateV6Ms'],2),round(x.get('readParseMs',0),2)]for x in growth])}

Four-championship envelope components and disjoint category bytes: see existing-growth.json. Native origins are nested/overlapping; use measured top-level tables rather than adding every origin depth. Stored sessions total3,089,129 bytes. Career-only envelope duplicates primary/recovery plus protected facts; complete backup additionally escapes JSON record strings. Historical fixture has no previous IDB root, so it understates current+previous retained storage. Native cold validator reconstructs full gameplay; synthetic scan below verifies hashes/selected invariants only.

## Accelerated capacity construction

Synthetic levels:5/100/500 championships;10 race summaries each;100 management-financial summaries per championship;200 candidate identities ever generated per championship, but only100 current offers retained. Recurring population32/64/128. This **materializes representative records**, not native races, economic transitions,50k durable writes or an integrated full career. Historical asset acquisition summaries omit some future domain detail; sensitivity estimates below account for richer payloads.

{table(['Champs / races','Historic tx / candidates','Rivals','Logical bytes','Checkpoint bytes','Tail bytes','Backup bytes','Largest record'],[[str(x['championships'])+' / '+str(x['races']),str(x['historicalTransactions'])+' / '+str(x['historicalCandidates']),x['rivals'],x['logicalTotalBytes'],x['checkpointBytes'],x['journalBytes'],x['backupBytes'],x['largestLogicalRecordBytes']]for x in cap['metrics']])}

Large case consists437 referenced records, no expired unused offer records, no ordinary playback writes. Total exceeds8MiB **across records**, while every logical record remains below8MiB. A new typed record/manifest layout is needed; current allowed career/session keys do not admit these pages. This is not a silent limit increase or proof the current format can hold the target.

{table(['Champs','History build/seal ms','Checkpoint seal ms','Cold all-record hash scan ms','Export ms','Parse+verify restore ms'],[[x['championships'],*[round(x[k],2)for k in ['historyBuildSealMs','checkpointSealMs','coldVerifyAllRecordsMs','backupStringifyMs','restoreParseAndVerifyMs']]]for x in cap['metrics']])}

Current native projection is{cap['nativeCurrentProjectionBytes']} bytes in the worker: profile/career/current registry/cycle state/facts/M4/trophies, stripped of origins/receipt replay. It is a *projection measurement*, not a complete new current-state schema/validator. Full active championship/proof evidence is not populated in this terminal stress case. Reserve and separately test the largest active12-event/8-entrant aggregate; do not claim maximum native active capacity here.

## Actual Chromium IndexedDB probe

The full11,725,664-byte synthetic portable set was written and read in a fresh temporary IDB origin: decode{db['capacity']['decodeMs']:.1f}ms, transaction wall time{db['capacity']['atomicWriteMs']:.1f}ms, readAll{db['capacity']['readAllMs']:.1f}ms.9 checks pass, including connection conflict and page reload. Reported origin quota{db['capacity']['estimate']['quota']} bytes, physical reported usage{db['capacity']['estimate']['usage']} bytes. Logical payload size differs from compressed/browser storage use; estimate is not guaranteed permanent quota. Real exhaustion was not tested; injected quota denial and atomic abort were tested separately.

Longest observed main-thread long task{db['capacity']['longestObservedTaskMs']}ms; raw entries{db['capacity']['longTasksMs']}. This diagnostic does **not** meet a strict≤100ms responsiveness goal. Move bulk parse/validation/preparation into worker, stream/chunk export/import safely and avoid all-history main-thread cloning. Async write wall time is not uninterrupted main-thread blocking.

## Memory / transfer

Largest sampled worker isolate heap{cap['metrics'][-1]['sampledWorkerHeapMax']} bytes. Samples are lower bounds on transient peak; no exact GC/peak allocation proof. Main thread before/after and transfer metadata in memory-transfer.json. Largest backup transfer took{mem['messages'][0]['workerToMainElapsedMs']:.2f}ms including clone/scheduling; Node main heap after receipt{mem['messages'][0]['mainHeapUsed']} bytes. Node RSS is process-wide, not worker-only memory. Browser sampled JS heap{db['capacity']['mainHeapUsed']} bytes is not a peak guarantee.

## Growth / write-volume model

Current authority checkpoints and bounded journals become bounded by live assets/active championship, with historical pages linear in completed facts. Populations/offers bounded; expired unused offer historyO(1) in active authority, generation epochO(log n) digits. Compact summaries remain linear—not zero-growth or unlimited storage. Native evidence may be deleted only after finalized checkpoint absorbs its authority. Current+previous roots can share immutable pages; GC only records unreachable from both roots/pending restore.

Prototype model does not instrument50k IDB writes. Proposed write-volume estimate: at128 operations/checkpoint,50k operations≈391 rollovers; append journal average64 entries of~200–500B means~0.64–1.6GB cumulative journal bytes plus~90MB of228KB checkpoints at391 rollovers, **before** new history pages. These are modeled cumulative writes, not retained bytes or measured flash I/O. Incremental record/journal design may reduce write amplification; exact-byte/generation validation must remain. Current inline-head rewrite would be far larger as history grows.

At500 champs, doubling every history payload from this synthetic set roughly adds another~11MB, still far below256MiB, but venue-rich fields, full active configuration, required reward/asset histories and previous roots need measurement. A10× detailed-history expansion could approach~120MB before other retained state; no blanket256MiB capacity guarantee. Example4→500 two-event native envelope linear extrapolation alone~123MB, already incompatible with8MiB and not a forecast for5000 races.

## Capacity recommendation

Retain target500 championships/5000 races/100k ever candidates/50k historical transactions/32–128 rivals as a **production stress gate**, not a certified cap. Use paged summaries/bounded current authority; test actual native10-event average and maximum active12-event8-entrant state, import/restore, journal rollover and browser restart. Do not increase record/backup bounds or discard required facts. The synthetic result establishes plausible storage feasibility, not complete production correctness/performance acceptance.
''')
steps=[['A1','Current-state semantic boundary','Define checkpoint schema/rules,current ownership/employment/finance/M4/progression/active-result invariants; factor existing mechanics from lifetime replay wrappers.','state.js,e5/schema6.js,cycles/schema4.js,history.js,domain command wrappers','high','Native Map-state parity: old validation →checkpoint projection→current validators→same legal/illegal command results.'],['A2','Checkpoint/journal authority','Monotonic absolute revision/command epoch;bounded tail/recent acknowledgment cache; semantic once-only IDs; new typed record hashes.','new checkpoint-format/domain journal modules, economic/controller contracts','high','Crash/duplicate/conflict/lost ack across multiple rollovers; no double Gold/assets/rewards/settlement.'],['A3','Atomic record-root persistence','Reuse IDB and inline-worker orchestration; immutable referenced record bodies, current/previous root CAS, stale-tab control.','e4/indexeddb.js,client.js,worker-service.js; no unawaited async CareerStore setItem','medium-high','Actual IDB transaction-abort, concurrent connections, worker failure before/after commit; no false durable ack.'],['A4','Compaction and retention','Archive only finalized/selection-complete outcomes; current+previous reachable-page retention; retire completed sessions only after new validator no longer requires them.','session-store,official publication adapters,e5 archive/history presentation','high','Pre/post-compaction official outcomes, condition, earned rewards and historical labels identical; unresolved active data never pruned.'],['A5','Save/restore/slots','New explicit version, complete portable snapshot, staged restore/CAS activation, incompatible-save messaging and old-save optional explicit converter.','envelope.js,career-store.js,e4/backup.js,recovery.js,startup/slots.js','medium-high','Cold corrupt/missing-page rejection, restore interruption/retry, profile/pack pins, unrelated-career preservation, explicit previous rollback as new generation.'],['A6','Integrated stress and M5 seams','Bounded offer/rival epochs and references; performance and actual long-career fault tests; standalone compatibility.','generation interfaces and benchmark fixtures; no procedural Market implementation in investigation','medium','Full native regression/references/M4, actual stress mix, browser quotas/main tasks, deterministic double build and owner Windows file acceptance.']]
write('BNT_M5A_Implementation_Plan.md',f'''# BNT M5-A — Proposed Implementation Plan

{H}

## Recommended sequence

{table(['Stage','Objective','Deliverables','Likely source seams','Relative effort','Acceptance'],steps)}

Dependencies: A1 before A2/A3; A4 after both; A5 can prepare format/UI in parallel after A1 but activation waits for A3/A4; A6 is final gate. Reuse the approved M4 functions/formulas and race engine, not full legacy reconstruction after every command. Field/key/version choices above are proposals, not source edits.

## Transition and rollback

Prefer a clean new development-save family for new M5 careers; retain accepted M4 HTML/source and reject incompatible files clearly. Previous development-save compatibility is lower priority. An optional explicit import converter may fully validate an M4 save, project it, validate new invariants and atomically create a separate compatible slot; no silent migration or in-place owner save edit. Do not retain all legacy schemas as live authority solely for sunk-cost reasons.

Rollback means reopen the preserved M4 artifact and its unchanged saves, or explicitly restore a validated new-format previous generation as a new generation. It does not mean loading schema7 in old M4 or merging two incompatible histories. All format/manifest changes require future production authorization.

## Regression requirements

Run full native Node888 baseline inventory plus new tests, all browser runners with raw exits, historical/payroll/clock/native replay references, D2, M4 Run/Legacy/settlement, signs, restart-seeded-boundary behavior, IDB/worker faults, slot independence/export/import and deterministic standalone double build. Windows direct-file acceptance remains owner testing. Investigation executed36 existing targeted tests,25 model tests and9 temporary-origin IDB checks; these are not those future acceptance gates.

## Owner decisions

Authorize exact Option B current-state/typed-manifest transition, compaction fidelity (no permanent detailed replay/telemetry after official archival), and development-save transition policy. Approve new-format implementation scope; do not treat this report as permission to edit production. No larger limits, gameplay changes, per-tick writes, server or distributed/tamper-proof infrastructure recommended. Retention page size/checkpoint cadence/cache bounds are routine engineering choices to validate, not separate gameplay votes.

## M5 coordination

Persistence production correctness precedes renewable asset/offer/rival state activation. Catalog compilation/content authoring can proceed in parallel. Provide APIs for prepareBatch(expectedEpoch),commitBatch, acquire through native economy,freezeRegistration,commitOfficialResult,finalize/archive and appendSummary once, all backed by one authority transaction. Domain effects remain native, not a second procedural economy.
''')
write('BNT_M5A_Architecture_Decision_Record.md',f'''# BNT M5-A — Architecture Decision Record

{H}

## Decision proposal

**Recommend Option B — Protected Checkpointing.** Owner preference is technically supported. Status: feasibility demonstrated in bounded prototypes; production implementation not authorized or accepted.

{table(['Option','Advantages','Measured / contract limits','Disposition'],[['A: Existing architecture + raised limits','Smallest immediate change; current validators unchanged','Envelope2.08MB at4 champs, growing244KB/champ in2-event fixture; full sessions3.09MB;1000 lifetime receipts; raising limits leaves repeated replay/duplication.','Reject as primary solution; no limit increase performed.'],['B: Validated current checkpoint + bounded journal + paged compact history','Preserves functional command/financial/race semantics; removes genesis replay requirement and obsolete session evidence; practical offline recovery','Synthetic target11.7MB total/228KB checkpoint, real IDB retention and25 model integrity checks; new complete current validators/record format required;104ms observed browser task remains.','Preferred bounded production project.'],['C: Fresh simplified authoritative snapshot replacement','Could simplify more old schema machinery; new saves easier to reason about','No independent C prototype or measured advantage; rebuilding native effects/authority risks drift; still needs current validators/atomic storage/once-only facts.','Defer separate owner review if B extraction becomes substantially more complex; not implemented.']])}

## Trust and integrity

Use validated domain transitions/current-state invariants, versioned checkpoint lineage, accidental-corruption hashes, atomic root publication and bounded journal continuity. Do not demand signatures/server authority against the owner of a local save. Recomputing a local hash does not prove financial validity; cold structural/domain validation remains necessary. Conversely, do not keep every historical native snapshot merely to simulate owner-edit-proof finance.

## Why B is not a cosmetic wrapper

Current schema6 requires complete reconstruction and retained official sessions. B intentionally changes the trusted base and validator semantics after a fully validated checkpoint. It can drop old origins and detailed telemetry only once new current/historical authorities validate independently. Small current validators, extracted native reducers and record-ref IDB manifests are bounded changes; they are real architecture work and require production tests. Calling a stripped schema6 object valid would be a defect.

## Capacity and responsiveness disposition

Approved provisional target appears practical under paging, but full native stress and native current-state validators are unproven. Existing limits are retained per logical record/container; typed pages extend the *representation*, not the bound. Cold history validation/export remains linear; no unlimited/quota-guaranteed promise.104ms browser task and~78MB sampled worker heap require worker/chunking attention. A larger backend replacement is not presently justified.

## Review boundary

Approve bounded Option B implementation after reviewing fidelity/transition choices. The following competition audit may use this architecture as a proposal with unresolved production gates, not as completed infrastructure. No source refactor, migration, merge or push occurred.
''')
scenarios=[
('Checkpoint prepare interrupted','worker→coordinator','Old root remains authoritative','exact-byte cache + candidate pending','No commit acknowledgment before completed transaction','PASS model preparation'),
('Record write abort','IDB publication','No partial checkpoint/journal visible','IDB tx abort / previous root','New body writes +head inone tx','PASS model3 boundaries +real IDB abort'),
('Lost acknowledgment after checkpoint','coordinator→UI','Discover committed new sequence','generation CAS /worker ack','Read durable root, retained recent results','PASS model +IDB'),
('Duplicate financial command across rollover','domain journal','Apply once','lookupCommitted retained forever today','Bound epoch/revision +recent receipts +semantic effect','PASS model bounded recent cache'),
('Conflicting same command ID','journal','Reject unchanged','protected ID/effect registry','Bind command ID/epoch/request hash','PASS model'),
('Ancient command after receipt eviction','checkpoint command epoch','Reject obsolete; query domain status, never reapply','current retains full history','Structured command epoch/absolute revision','PARTIAL model stale epoch; production ID derivation pending'),
('Purchase from expired batch','market','Reject; purchased asset retained','available flag, quote,owner graph','Committed epochs/native acquisition/current identity','PASS synthetic model; no native procedural Market'),
('Acquisition then batch rollover','ownership/checkpoint','Current asset survives; unused candidate discarded safely','old sourceoffer retained for replay','Checkpoint absorbs source facts before dropping unused offers','PASS model; native production integration required'),
('Official result repeated','publication','No duplicate condition/points/rewards','native prepare/capability+protected commit','Permanent event/result semantic identity plus archived summary','PASS model result-key only; native D2/publication gate not replaced'),
('Settlement/reward repeated','terminal authority','No duplicate Gold/Legacy/payroll','E5 terminalRegistry/reward selection','Checkpoint permanent semantic counters/summary refs','PASS model simplified settlement; native full effects untested'),
('Stale concurrent tab','coordinator CAS','Reject old generation/read set','generation +sameRecords +WebLocks','Exact root/readset CAS','PASS model +two real IDB connections'),
('Missing journal/page','cold decoder','Block, preserve records; validated previous offered','existing no stale fallback','Complete linked referenced records required','PASS model missing journal; full native missing-page test required'),
('Corrupt root/body','cold validation','Reject, no invented outcomes','sealed envelopes/codec/checksums','Hash/address binding+native current validators','PASS model corrupted hash and semantic checks'),
('Rehashed bad journal order','journal replay','Reject even if checksum valid','native journal watermark','Contiguous revision/epoch and request validation','PASS semantic gap model'),
('Unknown checkpoint schema','version boundary','Reject without save overwrite','version/schema allowlists','New version decoder with exact keys','PASS model rehashed version99'),
('Corrupt latest /valid previous','recovery','Validate previous, explicit new-generation activation','current confirmed recovery','Do not rewind generation; warn about lost newer data','PARTIAL reconstruct previous tested; new-generation recovery activation untested'),
('Quota denied','storage','Old durable state and retry-safe IDs','IDB abort /capacity estimate not guarantee','No loops/false ack, preserve previous data','PASS injected quota model; real exhaustion untested'),
('Worker dies before/after commit','worker acknowledgment','Cold reload distinguishes durable result','worker failure/restart+pending candidate','Idempotent root/operation result discovery','NOT TESTED end-to-end new model worker termination'),
('Import foreign career','restore activation','Reject or explicit separate-slot choice','ownership/restore staging','Full manifest scope/slot confirmation','NOT TESTED new-format staged native restore'),
('Restore interrupted','staged import','No mixed authority; complete/rollback/quarantine','existing stageRestore+atomicactivation','New root and referenced-page stage','NOT TESTED new-format transaction restore'),
('Unpaid claim/expired contract during compaction','current native validator','Never erase wages/debt/status','current graph/cycles reconstructor','Current claim snapshots/contract invariants preserved','NOT TESTED native compacted current-state validator'),
('Pending Run/Legacy choice','checkpoint eligibility','Retain pending offer/source/selection gate','native E5/reward authority','Snapshot-only; no final history compaction until resolved','NOT TESTED native checkpoint boundary'),
('Active race restart','between-race save','Same frozen initial seed; no in-memory tick writes','MemoryAttempt/P1 boundary','Preserve initial setup/pendingprepare only','EXISTING targeted suite; new checkpoint integration required'),
('Slot deletion/stale restore writer','career scope','No resurrection/foreign overwrite','retirement tombstone','Retain deletion/incarnation witness','NOT TESTED new-format model'),
('All referenced pages+head large write','capacity','Commit/read complete target set','current IDB records','Immutable body pages+manifest','PASS real IDB437-record synthetic payload'),
('Cold reload after close','durable authority','Recover acknowledged state','current discovery/worker decode','New versioned root+invariant scan','PASS real IDB connection/page reload; browser process crash not tested'),
('Read-only repository preservation','audit boundary','No game/save/artifact changes','manifest/source hashes','Independent before/after hashes/status','PASS baseline +final verification')]
with (O/'BNT_M5A_Integrity_and_Failure_Test_Matrix.csv').open('w')as f:
 w=csv.writer(f);w.writerow(['failure_scenario','authority_boundary','expected_behavior','existing_protection','proposed_protection','prototype_result','production_acceptance_test']);w.writerows([*x,'Execute with real native reducers/new-format worker+IDB and assert exact durable bytes/effects']for x in scenarios)
# Supporting measurements and investigation commands, not builds.
write('evidence/COMMANDS.md','''# M5-A executed commands

- `node prototype/inspect-baseline.mjs`: exit0, source/artifact verification, disjoint category measurements,3 native state validations. Historical fixture backups read-only; fresh Map fixture isolated.
- `node prototype/model-tests.mjs`: final exit0,25 model cases. First draft exited1 on a JavaScript test-harness syntax error; preserved in prototype-tests-initial-syntax-failure.log and corrected without production edits.
- `node prototype/capacity-main.mjs`: exit0,3 accelerated materialization workloads and Node worker memory/transfer measurements. No5000 native races or50k IDB commits executed.
- `node prototype/idb-proof.mjs`: final exit0,9 Chromium HTTP/new temporary-IDB checks. Initial harness root-route403 exited1, preserved in idb-proof-initial-harness-failure.log; corrected only the isolated server.
- In `/workspace/BNT`: `node --test tests/persistence.test.js tests/m2-e-e4-worker.test.js tests/m2-e-e4-stage2.test.js`: exit0,36 passed/0 failed/skipped/cancelled. No full888-suite or Windows acceptance claim.

Prototype code is not production implementation. Real-quota exhaustion, native checkpoint migration/current validators and full new-format staged restore remain untested. Raw JSON/logs identify those gaps. Browser timing is a diagnostic under managed shared-container load; do not report it as an isolated production benchmark.
''')
# Verify all original repository bytes and git status now, before task2 starts.
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=load('repository-before.json');after={str(p.relative_to(r)):sha(p)for p in r.rglob('*')if p.is_file()and not any(k in p.relative_to(r).parts for k in ['.git','node_modules'])};assert before==after
assert subprocess.check_output(['git','status','--porcelain=v1','--untracked-files=all'],cwd=r,text=True)==(E/'git-status-before.txt').read_text()
(E/'completion.json').write_text(json.dumps({'task':'M5-A','status':'COMPLETE_FEASIBILITY_ONLY','prototypeTests':model['passed'],'idbTests':db['passed'],'existingNodeTests':36,'sourceUnchanged':True,'architecture':'OPTION_B_RECOMMENDED_PRODUCTION_NOT_IMPLEMENTED','task2MayUseThisConclusion':True},indent=2))
print('M5-A complete:6 reports/matrix delivered; investigation only; source unchanged')
