# BNT M5-A — Proposed Implementation Plan

**M5-A investigation only • 24 November 2026.** Prototypes are isolated from native modules and player saves. No production source, persistence format, artifact, balance or gameplay was changed. All architecture below is proposed, not implemented acceptance.

## Recommended sequence

| Stage | Objective | Deliverables | Likely source seams | Relative effort | Acceptance |
| --- | --- | --- | --- | --- | --- |
| A1 | Current-state semantic boundary | Define checkpoint schema/rules,current ownership/employment/finance/M4/progression/active-result invariants; factor existing mechanics from lifetime replay wrappers. | state.js,e5/schema6.js,cycles/schema4.js,history.js,domain command wrappers | high | Native Map-state parity: old validation →checkpoint projection→current validators→same legal/illegal command results. |
| A2 | Checkpoint/journal authority | Monotonic absolute revision/command epoch;bounded tail/recent acknowledgment cache; semantic once-only IDs; new typed record hashes. | new checkpoint-format/domain journal modules, economic/controller contracts | high | Crash/duplicate/conflict/lost ack across multiple rollovers; no double Gold/assets/rewards/settlement. |
| A3 | Atomic record-root persistence | Reuse IDB and inline-worker orchestration; immutable referenced record bodies, current/previous root CAS, stale-tab control. | e4/indexeddb.js,client.js,worker-service.js; no unawaited async CareerStore setItem | medium-high | Actual IDB transaction-abort, concurrent connections, worker failure before/after commit; no false durable ack. |
| A4 | Compaction and retention | Archive only finalized/selection-complete outcomes; current+previous reachable-page retention; retire completed sessions only after new validator no longer requires them. | session-store,official publication adapters,e5 archive/history presentation | high | Pre/post-compaction official outcomes, condition, earned rewards and historical labels identical; unresolved active data never pruned. |
| A5 | Save/restore/slots | New explicit version, complete portable snapshot, staged restore/CAS activation, incompatible-save messaging and old-save optional explicit converter. | envelope.js,career-store.js,e4/backup.js,recovery.js,startup/slots.js | medium-high | Cold corrupt/missing-page rejection, restore interruption/retry, profile/pack pins, unrelated-career preservation, explicit previous rollback as new generation. |
| A6 | Integrated stress and M5 seams | Bounded offer/rival epochs and references; performance and actual long-career fault tests; standalone compatibility. | generation interfaces and benchmark fixtures; no procedural Market implementation in investigation | medium | Full native regression/references/M4, actual stress mix, browser quotas/main tasks, deterministic double build and owner Windows file acceptance. |


Dependencies: A1 before A2/A3; A4 after both; A5 can prepare format/UI in parallel after A1 but activation waits for A3/A4; A6 is final gate. Reuse the approved M4 functions/formulas and race engine, not full legacy reconstruction after every command. Field/key/version choices above are proposals, not source edits.

## Transition and rollback

Prefer a clean new development-save family for new M5 careers; retain accepted M4 HTML/source and reject incompatible files clearly. Previous development-save compatibility is lower priority. An optional explicit import converter may fully validate an M4 save, project it, validate new invariants and atomically create a separate compatible slot; no silent migration or in-place owner save edit. Do not retain all legacy schemas as live authority solely for sunk-cost reasons.

Rollback means reopen the preserved M4 artifact and its unchanged saves, or explicitly restore a validated new-format previous generation as a new generation. It does not mean loading schema7 in old M4 or merging two incompatible histories. All format/manifest changes require future production authorization.

## Regression requirements

Run full native Node888 baseline inventory plus new tests, all browser runners with raw exits, historical/payroll/clock/native replay references, D2, M4 Run/Legacy/settlement, signs, restart-seeded-boundary behavior, IDB/worker faults, slot independence/export/import and deterministic standalone double build. Windows direct-file acceptance remains owner testing. Investigation executed36 existing targeted tests,25 model tests and9 temporary-origin IDB checks; these are not those future acceptance gates.

## Owner decisions

Authorize exact Option B current-state/typed-manifest transition, compaction fidelity (no permanent detailed replay/telemetry after official archival), and development-save transition policy. Approve new-format implementation scope; do not treat this report as permission to edit production. No larger limits, gameplay changes, per-tick writes, server or distributed/tamper-proof infrastructure recommended. Retention page size/checkpoint cadence/cache bounds are routine engineering choices to validate, not separate gameplay votes.

## M5 coordination

Persistence production correctness precedes renewable asset/offer/rival state activation. Catalog compilation/content authoring can proceed in parallel. Provide APIs for prepareBatch(expectedEpoch),commitBatch, acquire through native economy,freezeRegistration,commitOfficialResult,finalize/archive and appendSummary once, all backed by one authority transaction. Domain effects remain native, not a second procedural economy.
