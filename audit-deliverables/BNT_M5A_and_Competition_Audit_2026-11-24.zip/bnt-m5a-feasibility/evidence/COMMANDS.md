# M5-A executed commands

- `node prototype/inspect-baseline.mjs`: exit0, source/artifact verification, disjoint category measurements,3 native state validations. Historical fixture backups read-only; fresh Map fixture isolated.
- `node prototype/model-tests.mjs`: final exit0,25 model cases. First draft exited1 on a JavaScript test-harness syntax error; preserved in prototype-tests-initial-syntax-failure.log and corrected without production edits.
- `node prototype/capacity-main.mjs`: exit0,3 accelerated materialization workloads and Node worker memory/transfer measurements. No5000 native races or50k IDB commits executed.
- `node prototype/idb-proof.mjs`: final exit0,9 Chromium HTTP/new temporary-IDB checks. Initial harness root-route403 exited1, preserved in idb-proof-initial-harness-failure.log; corrected only the isolated server.
- In `/workspace/BNT`: `node --test tests/persistence.test.js tests/m2-e-e4-worker.test.js tests/m2-e-e4-stage2.test.js`: exit0,36 passed/0 failed/skipped/cancelled. No full888-suite or Windows acceptance claim.

Prototype code is not production implementation. Real-quota exhaustion, native checkpoint migration/current validators and full new-format staged restore remain untested. Raw JSON/logs identify those gaps. Browser timing is a diagnostic under managed shared-container load; do not report it as an isolated production benchmark.

- `node prototype/native-cold.mjs`: exit0; actual unmodified worker cold/warm validation of real four-championship/nine-record backup. No writes.
