# BNT M5-A — Capacity and Performance

**M5-A investigation only • 24 November 2026.** Prototypes are isolated from native modules and player saves. No production source, persistence format, artifact, balance or gameplay was changed. All architecture below is proposed, not implemented acceptance.

## Method and environment

Node24.22.1/Linux; existing installed tooling, isolated Node worker and Chromium `156.0.8078.79`. Native fixtures are accepted M4 historical backups read-only and a new private Map career; synthetic workload labels are explicit. Timings are single-run development diagnostics, not percentile guarantees or equivalent-validator speedup claims. Browser diagnostic shared the managed container with other verification; no exclusive CPU or Windows validation.

## Existing baseline

| Fixture | Career envelope bytes | Receipts | Native schema6 validation ms | Read/parse ms |
| --- | --- | --- | --- | --- |
| fresh-current-m4 | 765509 | 4 | 106.56 | 0 |
| three-championships | 1833821 | 34 | 806.66 | 21.17 |
| four-championships | 2078020 | 44 | 1070.66 | 76.09 |


Four-championship envelope components and disjoint category bytes: see existing-growth.json. Native origins are nested/overlapping; use measured top-level tables rather than adding every origin depth. Stored sessions total3,089,129 bytes. Career-only envelope duplicates primary/recovery plus protected facts; complete backup additionally escapes JSON record strings. Historical fixture has no previous IDB root, so it understates current+previous retained storage. Native cold validator reconstructs full gameplay; synthetic scan below verifies hashes/selected invariants only.

## Accelerated capacity construction

Synthetic levels:5/100/500 championships;10 race summaries each;100 management-financial summaries per championship;200 candidate identities ever generated per championship, but only100 current offers retained. Recurring population32/64/128. This **materializes representative records**, not native races, economic transitions,50k durable writes or an integrated full career. Historical asset acquisition summaries omit some future domain detail; sensitivity estimates below account for richer payloads.

| Champs / races | Historic tx / candidates | Rivals | Logical bytes | Checkpoint bytes | Tail bytes | Backup bytes | Largest record |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 5 / 50 | 500 / 1000 | 32 | 221070 | 90580 | 18120 | 221704 | 90580 |
| 100 / 1000 | 10000 / 20000 | 64 | 2409845 | 129032 | 18374 | 2416219 | 245316 |
| 500 / 5000 | 50000 / 100000 | 128 | 11694994 | 228222 | 18374 | 11725658 | 321567 |


Large case consists437 referenced records, no expired unused offer records, no ordinary playback writes. Total exceeds8MiB **across records**, while every logical record remains below8MiB. A new typed record/manifest layout is needed; current allowed career/session keys do not admit these pages. This is not a silent limit increase or proof the current format can hold the target.

| Champs | History build/seal ms | Checkpoint seal ms | Cold all-record hash scan ms | Export ms | Parse+verify restore ms |
| --- | --- | --- | --- | --- | --- |
| 5 | 16.21 | 0.5 | 2.97 | 0.63 | 2.97 |
| 100 | 65.25 | 1.34 | 39.73 | 22.73 | 28.65 |
| 500 | 276.64 | 1.73 | 197.38 | 88.83 | 119.66 |


Current native projection is33526 bytes in the worker: profile/career/current registry/cycle state/facts/M4/trophies, stripped of origins/receipt replay. It is a *projection measurement*, not a complete new current-state schema/validator. Full active championship/proof evidence is not populated in this terminal stress case. Reserve and separately test the largest active12-event/8-entrant aggregate; do not claim maximum native active capacity here.

## Actual Chromium IndexedDB probe

The full11,725,658-byte synthetic portable set was written and read in a fresh temporary IDB origin: decode30.5ms, transaction wall time55.9ms, readAll130.5ms.9 checks pass, including connection conflict and page reload. Reported origin quota10739806208 bytes, physical reported usage2387968 bytes. Logical payload size differs from compressed/browser storage use; estimate is not guaranteed permanent quota. Real exhaustion was not tested; injected quota denial and atomic abort were tested separately.

Longest observed main-thread long task104ms; raw entries[60, 104]. This diagnostic does **not** meet a strict≤100ms responsiveness goal. Move bulk parse/validation/preparation into worker, stream/chunk export/import safely and avoid all-history main-thread cloning. Async write wall time is not uninterrupted main-thread blocking.

## Memory / transfer

Largest sampled worker isolate heap79284768 bytes. Samples are lower bounds on transient peak; no exact GC/peak allocation proof. Main thread before/after and transfer metadata in memory-transfer.json. Largest backup transfer took114.62ms including clone/scheduling; Node main heap after receipt17060120 bytes. Node RSS is process-wide, not worker-only memory. Browser sampled JS heap47030368 bytes is not a peak guarantee.

## Growth / write-volume model

Current authority checkpoints and bounded journals become bounded by live assets/active championship, with historical pages linear in completed facts. Populations/offers bounded; expired unused offer historyO(1) in active authority, generation epochO(log n) digits. Compact summaries remain linear—not zero-growth or unlimited storage. Native evidence may be deleted only after finalized checkpoint absorbs its authority. Current+previous roots can share immutable pages; GC only records unreachable from both roots/pending restore.

Prototype model does not instrument50k IDB writes. Proposed write-volume estimate: at128 operations/checkpoint,50k operations≈391 rollovers; append journal average64 entries of~200–500B means~0.64–1.6GB cumulative journal bytes plus~90MB of228KB checkpoints at391 rollovers, **before** new history pages. These are modeled cumulative writes, not retained bytes or measured flash I/O. Incremental record/journal design may reduce write amplification; exact-byte/generation validation must remain. Current inline-head rewrite would be far larger as history grows.

At500 champs, doubling every history payload from this synthetic set roughly adds another~11MB, still far below256MiB, but venue-rich fields, full active configuration, required reward/asset histories and previous roots need measurement. A10× detailed-history expansion could approach~120MB before other retained state; no blanket256MiB capacity guarantee. Example4→500 two-event native envelope linear extrapolation alone~123MB, already incompatible with8MiB and not a forecast for5000 races.

## Capacity recommendation

Retain target500 championships/5000 races/100k ever candidates/50k historical transactions/32–128 rivals as a **production stress gate**, not a certified cap. Use paged summaries/bounded current authority; test actual native10-event average and maximum active12-event8-entrant state, import/restore, journal rollover and browser restart. Do not increase record/backup bounds or discard required facts. The synthetic result establishes plausible storage feasibility, not complete production correctness/performance acceptance.

## Additional actual retained-worker cold-load probe

`node prototype/native-cold.mjs` exited0. The unmodified accepted worker validated the real four-championship envelope and all8 retained official sessions: cold7181.03ms; same exact-byte/generation warm call3.99ms,9 records/5,167,149 logical bytes. This is broader than the primary-only schema6 timing and excludes IDB/worker transport. It confirms retained-source reconstruction is a substantial cold-load cost; it is not comparable to a hash-only synthetic checkpoint scan as an equivalent-validator speedup.

## Explicit prototype retention limitations

Historical100,000-candidate count is counter-only:100 live objects per level, not100,000 generation calls.500 championship/5000 race/50,000 financial summary rows are actually materialized synthetic objects, with internally consistent simple financial after-balances; native gameplay transitions were not executed.

Capacity previous manifest shares current references, not a distinct full prior checkpoint/tail/changed-page set. Budget roughly0.3–0.6MB additional for this representation (estimate) and prove actual previous-body retention. The protocol model retains unreachable old record bodies: rollover tests prove state/authority, **not physical GC or expired-source deletion**. New implementation must prove current+previous+pending-restore reachability before claiming bounded body retention. No accepted history was pruned.
