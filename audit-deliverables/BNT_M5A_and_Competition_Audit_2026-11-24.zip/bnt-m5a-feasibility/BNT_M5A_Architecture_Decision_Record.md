# BNT M5-A — Architecture Decision Record

**M5-A investigation only • 24 November 2026.** Prototypes are isolated from native modules and player saves. No production source, persistence format, artifact, balance or gameplay was changed. All architecture below is proposed, not implemented acceptance.

## Decision proposal

**Recommend Option B — Protected Checkpointing.** Owner preference is technically supported. Status: feasibility demonstrated in bounded prototypes; production implementation not authorized or accepted.

| Option | Advantages | Measured / contract limits | Disposition |
| --- | --- | --- | --- |
| A: Existing architecture + raised limits | Smallest immediate change; current validators unchanged | Envelope2.08MB at4 champs, growing244KB/champ in2-event fixture; full sessions3.09MB;1000 lifetime receipts; raising limits leaves repeated replay/duplication. | Reject as primary solution; no limit increase performed. |
| B: Validated current checkpoint + bounded journal + paged compact history | Preserves functional command/financial/race semantics; removes genesis replay requirement and obsolete session evidence; practical offline recovery | Synthetic target11.7MB total/228KB checkpoint, real IDB retention and25 model integrity checks; new complete current validators/record format required;104ms observed browser task remains. | Preferred bounded production project. |
| C: Fresh simplified authoritative snapshot replacement | Could simplify more old schema machinery; new saves easier to reason about | No independent C prototype or measured advantage; rebuilding native effects/authority risks drift; still needs current validators/atomic storage/once-only facts. | Defer separate owner review if B extraction becomes substantially more complex; not implemented. |


## Trust and integrity

Use validated domain transitions/current-state invariants, versioned checkpoint lineage, accidental-corruption hashes, atomic root publication and bounded journal continuity. Do not demand signatures/server authority against the owner of a local save. Recomputing a local hash does not prove financial validity; cold structural/domain validation remains necessary. Conversely, do not keep every historical native snapshot merely to simulate owner-edit-proof finance.

## Why B is not a cosmetic wrapper

Current schema6 requires complete reconstruction and retained official sessions. B intentionally changes the trusted base and validator semantics after a fully validated checkpoint. It can drop old origins and detailed telemetry only once new current/historical authorities validate independently. Small current validators, extracted native reducers and record-ref IDB manifests are bounded changes; they are real architecture work and require production tests. Calling a stripped schema6 object valid would be a defect.

## Capacity and responsiveness disposition

Approved provisional target appears practical under paging, but full native stress and native current-state validators are unproven. Existing limits are retained per logical record/container; typed pages extend the *representation*, not the bound. Cold history validation/export remains linear; no unlimited/quota-guaranteed promise.104ms browser task and~78MB sampled worker heap require worker/chunking attention. A larger backend replacement is not presently justified.

## Review boundary

Approve bounded Option B implementation after reviewing fidelity/transition choices. The following competition audit may use this architecture as a proposal with unresolved production gates, not as completed infrastructure. No source refactor, migration, merge or push occurred.
