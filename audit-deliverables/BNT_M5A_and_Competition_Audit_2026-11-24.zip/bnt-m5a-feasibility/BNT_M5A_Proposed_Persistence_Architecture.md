# BNT M5-A — Proposed Persistence Architecture

**M5-A investigation only • 24 November 2026.** Prototypes are isolated from native modules and player saves. No production source, persistence format, artifact, balance or gameplay was changed. All architecture below is proposed, not implemented acceptance.

## Structure

Proposed new save family (working name schema7, **not assigned/implemented**):

```text
manifest(version, career/profile identity, generation, checkpointRef,
         journalRef, historyPageRefs, pendingOperationRefs, catalogPins)
checkpoint(schema/rules, sequence, absoluteBaseRevision, currentState,
           historyRoots, generationEpochs, semanticHighWatermarks, parentRef)
journal(baseCheckpointHash, baseRevision, contiguous operations, resultHash)
historyPages(typed immutable official summaries, exact IDs/names, digest)
previousManifest -> complete previous valid checkpoint/journal/page set
```

Logical records remain≤8MiB and backup≤256MiB. History is partitioned into bounded pages (prototype128 rows/page is an engineering test choice, not final content policy). Keep the existing IndexedDB/inline-worker direction and atomic transaction principle. Extend coordinator to immutable record-body entries and small root references; current `head.records` inline arrays would still copy all history and should not be the final layout. New record-key whitelist, decoder and version required; current code is unchanged.

## Checkpoint authority

Create only from an already validated current state after all accepted operations finish. First conversion from accepted M4 must validate full schema6 before projecting; future checkpoints use complete current-state graph/finance/employment/progression/championship validators plus the bounded journal. Checksum/SHA protects accidental corruption; it does not establish correctness or authenticate an owner-edited save. Never trust a caller cache token. Rules/schema/catalog pins reject incompatible content; do not reroll.

Worker prepares/validates/encodes candidate; the main coordinator checks exact generation/read-set and commits records+current root+previous root in **one IDB transaction**; acknowledgment only after oncomplete. Preparation message success is not durability. Web Locks serialize friendly writers; IDB CAS handles stale tabs even if lock support fails. Worker failure before commit leaves old head; failure after commit but before acknowledgment reloads the new head and recovers the stored operation identity/result.

## Journal rollover and identity

Absolute career revision never resets to tail length. Each command carries checkpoint/command epoch, expected revision and source/effect scope. New command IDs must be structurally bound to operation epoch/sequence, not arbitrary globally reusable strings. Keep a bounded recent acknowledgment cache across rollover (prototype64); semantic once-only facts survive in current authority or indexed compact summaries: offer epoch+ID, acquisition ID, event/result ID, championship/settlement ID, reward-offer selection and upgrade ownership.

Rollover folds the fully validated journal into a new checkpoint, increments checkpoint sequence, sets absoluteBaseRevision, and clears only the incorporated tail. A stale command outside the receipt cache is rejected as obsolete and requires current-state read; it must never be silently retried as a new operation. If an ancient acknowledgment's detailed receipt is no longer available, report incorporated/obsolete with domain status lookup, not fabricated success or a duplicate effect. The prototype's small reducer is not a substitute for this full native contract.

## Trigger policy

Recommend automatic low-watermark scheduling after final championship settlement **and** permanent selection/archive, or a management tail/byte threshold. Initial engineering thresholds could be128–256 tail operations and a measured byte watermark below8MiB; determine during production benchmarks. Manual Save Game verifies durable accepted state and may coalesce a pending safe checkpoint; it does not save unfinished race ticks. Before registration reserve sufficient journal/size budget for worst-case supported events and allowed management transitions. If needed, snapshot-only checkpoint at a resolved intermission can retain the entire active aggregate, but do not compact its evidence; prove native anchor compatibility first. Never checkpoint ordinary playback.

## Retention classification

| Category | Class | Policy |
| --- | --- | --- |
| Current assets/employment/finance | Permanent current authority | Keep native values/ownership/capacity/contracts/unpaid claims; do not synthesize original grants. |
| Owner Legacy/unlocks/trophies | Permanent authority + history refs | Keep balances/owned upgrades/loadout/qualifications and once-only semantic facts; repeated award descriptions static-ref + stable historical labels. |
| Active/pending championship | Full active authority | Keep frozen roster/rules/progression/setup, results and pending choices/settlement/publication recovery. No compaction on a finish-line display. |
| Past official championships/races | Compact immutable history pages | Full-precision classification, participant/start/title eligibility, scores, names, payout/condition/settlement references; no telemetry required for normal history UI. |
| Historical acquisitions/retirements | Compact authority/history | Owned identity/current economics permanent while relevant; after retirement preserve required ownership/effect provenance and finance summary, not the unpurchased candidate pool. |
| Market offers | One active renewable batch | Persist final candidates + epoch/pins; obsolete unused listings removable only after source transactions checkpointed. |
| Rival identities | Bounded permanent population | Stable organization/member IDs/personality/strength; encounters paged; no player graph or offscreen economy. |
| Completed detailed race sessions | Disposable after archival checkpoint | Only once official conditions/rewards/settlement facts retained and pending recovery paths no longer reference session. Existing worker requires them today. |
| Checkpoint/journal/current+previous | Operational authority | Current and previous manifest roots retain necessary journal tail/checkpoint/pages; garbage collect only unreachable records after atomic publication. |
| Static catalogs/geometry/source prose | Embedded static content | Reference version/digest, freeze full resolved active setup where native requires; do not duplicate whole static catalogs in every career. |
| Presentation sidecar/profile slots/options | Scoped persistent metadata | Preserve immutable identity pin, mutable radio/team selection, ownership and export/import rules; global options stay outside career mechanics. |
| Generation intermediates/telemetry | Disposable | Unacknowledged preparation can be abandoned; no accepted effect lives only in a worker. |


## Recovery / backup

Load root and referenced records, validate hashes/schema/identity, validate current native invariants, replay contiguous tail and compare resulting revision. Missing journal/page or contradictory publication evidence blocks; do not restart a completed result or create a DNF. For a corrupt latest root, validate previous root completely and present explicit recovery. Prior-generation reconstruction is proven by the prototype; **production activation must create a new monotonic generation**, not rewind generation counters or overwrite an unrelated career. Restoring older progress can lose newer facts; show replacement scope, preserve original data/quarantine and obtain explicit confirmation. No local system can recover destroyed acknowledged bytes with no valid copy.

Default portable export can become one complete between-race career package containing current/previous roots and deduplicated referenced pages/session evidence. Legacy career-only exports should remain clearly identified if they omit required external authority; do not label incomplete exports complete. Multi-career slots and global preferences remain distinct. Staged restore validates all references, invariants and destination identity/capacity before atomic activation; incompatible formats fail without replacing bytes. Same backend can stage immutable records; never pretend separate independent writes activate atomically. Test restore interruptions on every boundary.

## Procedural integration

Commit generation seed domain/catalog version/epoch and final active offers. Viewing never renews. Epoch replacement and purchase use native quote/capacity/contract reducers; after incorporation into a protected checkpoint, expired unused candidates no longer need indefinite retention. Acquired names/stats/personality remain durable independent of catalog updates.

Keep bounded rival organization/member state outside the player's ownership graph; per-championship entrant IDs map to stable rival IDs. Freeze coherent native attributes/identity at registration. Result-keyed encounters append compact pages once; historical names remain frozen even if an active rival is retired. No per-tick writes or offscreen organization simulation.

## Validation still required

Current native reducers mix source-fingerprint/history lookup with mechanics. Extract/adapter-test pure mechanics without bypassing quotes, wages, D2 or reward effects. Add schema7 current-state validator and checkpoint rebase command envelope; do not call old validateStateV6 with stripped origins. Race clearance/native prepare/capability →single official commit remains unchanged semantically. This is a bounded authority replacement at checkpoint boundaries, not permission to invent a second economy.
