# Blood and Thunder — M5-A Protected Persistence Feasibility

Investigation only. No production changes, builds, save migration, commits or pushes. Files are individually available; no ZIP required.

1. [BNT_M5A_Persistence_Feasibility_Report.md](BNT_M5A_Persistence_Feasibility_Report.md)
2. [BNT_M5A_Proposed_Persistence_Architecture.md](BNT_M5A_Proposed_Persistence_Architecture.md)
3. [BNT_M5A_Capacity_and_Performance_Report.md](BNT_M5A_Capacity_and_Performance_Report.md)
4. [BNT_M5A_Integrity_and_Failure_Test_Matrix.csv](BNT_M5A_Integrity_and_Failure_Test_Matrix.csv)
5. [BNT_M5A_Implementation_Plan.md](BNT_M5A_Implementation_Plan.md)
6. [BNT_M5A_Architecture_Decision_Record.md](BNT_M5A_Architecture_Decision_Record.md)

[SHA-256 checksums](SHA256SUMS.txt)

[Raw measurement data](evidence/existing-growth.json) · [Capacity results and limitations](evidence/capacity-results.json) · [Model tests](evidence/prototype-tests.json) · [IDB results](evidence/idb-results.json) · [Existing retained-worker cold load](evidence/native-cold-results.json)

Prototype source is under prototype/. Capacity uses synthetic history;100k candidates is a counter-only assumption; physical GC/distinct prior-root capacity remain production gates.
