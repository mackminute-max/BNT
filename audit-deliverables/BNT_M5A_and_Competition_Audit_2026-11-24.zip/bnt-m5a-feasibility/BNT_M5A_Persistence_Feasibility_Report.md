# BNT M5-A — Persistence Feasibility Report

**M5-A investigation only • 24 November 2026.** Prototypes are isolated from native modules and player saves. No production source, persistence format, artifact, balance or gameplay was changed. All architecture below is proposed, not implemented acceptance.

## Executive verdict

**Protected checkpointing is feasible, with explicit new authority/format and validator work required before production.** Recommend Option B: current validated state becomes an authoritative checkpoint; bounded post-checkpoint journal; immutable paged compact history; active championship evidence kept intact; current and previous root manifests reference shared records. Keep native economic/racing/reward semantics, replace lifetime replay as the *sole* source of current-state authority. Do not increase limits.

This is not a drop-in serializer patch. Current schema6 validators require full historical origins and receipts, and the coordinator embeds all record bytes in each head. A versioned current-state validator and typed record references are mandatory. The owner-approved single-player threat model makes a checksummed validated checkpoint practical; cryptographic proof against a local save editor is neither provided nor required.

## Verified baseline

Branch `feat/e5-d-m1-startup-slots-options`, HEAD `27f9ecc086f27a1fb9fe593132308128ecd1249d`. Accepted M4 source is the existing uncommitted working-tree candidate, source manifest `e2bc429c8f27cea1edeb2d0c9dd0117f21527a16762f4da5394a4697fdc81c75`; all187 source and53 changed-file hashes match. Accepted HTML3,159,171 bytes/SHA256 `d77e49e40457c5de0255e3c95779941bec67023a4760248a69760f60b7a8d60c`. All pre-existing modified/untracked files preserved, including the unrelated preimplementation audit. No branch/commit created. Files/hashes/status are recorded in evidence/.

Source anchors: `src/persistence/envelope.js:8–81` seals primary/recovery and retained history; `career/championships/e5/schema6.js:40–49` replays all schema6 receipts from nested origin and compares full state; `cycles/schema4.js:65–89`, `championships/controller.js:80+` enforce older nested reconstruction; `economy/protected-registry.js` merge/lookup/historyRetentionPlan forbids compaction today; `persistence/e4/worker-service.js:28–70` validates exact career bytes and every retained official session; `e4/indexeddb.js:9–17,31–51` bounds logical records and atomically publishes head/previous; `e4/backup.js:2–16` bounds and verifies complete backups; `career-store.js:160–188` confirms recovery/export. This cannot be replaced by simply deleting arrays from a schema6 save.

## Measured growth

The accepted four-championship/eight-event backup was read, not modified. Its career envelope is2,078,020 bytes; session records3,089,129 bytes; nine logical records total5,167,149 bytes; complete JSON backup5,438,562 bytes, with no previous root supplied in that historical fixture. IDB itself additionally keeps previous generation.

Envelope primary984,425 bytes + recovery978,712 bytes account for94.5% of that envelope. Its outer protectedHistory adds114,365 bytes. Primary state contains transactions89,504, history114,359, championshipFoundation372,101 and e5 337,442 bytes. Current e5.board79,625 + foundation.offers75,647 duplicate static schedule/geometry disclosures. e5.origin199,777 includes its own nested origins; current foundation.origin126,674 is another branch. **Nested measurements overlap; do not sum every reported origin depth as disjoint data.** Archive/controller result records and terminal facts remain in several representations, while full cleared race sessions remain separately retained.

Three→four championships adds244,199 envelope bytes and10 receipts in this two-event controlled historical fixture. Growth includes repeated receipts/protected command request/result encodings and detailed official result/settlement histories, not just fixed initial migration origins. Native full validateStateV6 took~1070.7ms for the four-championship primary in this run. It verifies substantially more semantics than the prototype hash scan, so ratios are not equivalent workload speedups.

## Feasibility evidence

-25 isolated model checks pass: checkpoint rollover, absolute revision, duplicate/lost acknowledgment, stale writer, journal gaps, version/corruption, prior-generation reconstruction, ownership/financial invariants and injected quota denial.
-9 Chromium HTTP/temporary-IDB checks pass: atomic birth/abort/rollover, duplicate after rollover, competing connections, cold open, lost acknowledgment and page reload; actual large chunked synthetic dataset retained.
-36 existing persistence/worker/stage2 Node tests pass. Full888 baseline/browser/Windows acceptance was not rerun or re-certified.
-Synthetic target500 championships/5,000 races/50,000 financial-management summaries/100,000 historical-candidate counter/128 recurring teams materializes11,694,994 logical bytes across bounded records,11,725,658-byte backup,228,222-byte checkpoint. No expired unused offers remain active;100 current offers retained. These are **representative synthetic records**, not50,000 executed transactions or5,000 completed native races.

## Principal limitations

Current8MiB career record and1,000 lifetime receipts fail the requested horizon; observed two-event fixture extrapolation reaches8MiB around championship30, not a certified production limit. Limits alone cannot solve repeated reconstruction and session retention. Paging histories below8MiB per record is necessary; putting everything into a new single checkpoint would merely move the problem. The256MiB backup limit has substantial synthetic headroom but browser quota varies.

Prototype current-state validation is intentionally incomplete: the model validates financial/ownership invariants and hashed journal transitions, not all M4 Legacy, payroll, graph, title, reward and clearance rules. Native checkpoint import requires full validateStateV6 **once before conversion** and a complete new current-state validator thereafter. This work is a production gate, not proven by prototype success.

Browser diagnostic observed a104ms long task, above the100ms preferred E4 target. Bulk export/decode/history inspection must stay in a worker with bounded/progressive transfer. Atomic IDB completion latency is asynchronous and must not be confused with uninterrupted main-thread time. Node transfer/memory samples are not browser production budgets.

## Required conclusion /13 answers

1. Yes, checkpointing is technically feasible; not production-ready without new validators/record contracts.
2. Career envelope duplication + repeated authoritative history/results and retained full sessions dominate; initial origins contribute fixed overhead.
3. After final settlement and pending permanent selection/archive: compact old native proofs/sessions into checked official summaries plus immutable names/awards/settlement refs; retire unused offers once their source effects are checkpointed. Active/pending claims and results remain complete.
4. Authority is created by validated native reducer/current state →validated checkpoint →hash/manifest →single completed IDB transaction. Cold-load state invariants and all referenced records remain verified.
5. Absolute operation revision and command epoch survive rollover; bounded recent receipt cache supports lost ack; permanent semantic counters/tombstones/summary references prevent old acquisitions/results/rewards being applied with a new wrapper ID. Old original commands are stale, not replayed.
6. Yes, expired unused offers can leave active state after new checkpoint authority replaces old offer-dependent replay; not safe under current schema6 reconstruction.
7. Yes, fixed128 or fewer recurring identities plus paged encounter summaries can remain bounded; no rival economics.
8. Targets fit this synthetic representation; full native long-career/cold validation/backup and browser quota remain acceptance gates.
9. Less repeated reconstruction/write volume expected, history cold verification still linear; large clone/export tasks remain measurable costs.
10. A wholesale Option C replacement is not currently justified over bounded Option B; a breaking development-save version is appropriate to avoid carrying every old layer forward.
11. Persistence implementation should precede renewable production integration; content/schema work can proceed in parallel.
12. Implement current-state boundary and journal correctness, paged storage/recovery/export, then generated assets/rivals/markets; complete bounded end-to-end tests before release.
13. Owner must authorize exact production checkpoint format/coordinator changes and explicit development-save transition. History compaction sacrifices full old-race replay/forensic reconstruction after finalization; that is consistent with approved direction but should be stated in implementation authorization. No owner-edit-proof trust claim or limit increase recommended.

Explicit limitations:100k candidate history is a modeled counter (100 live objects constructed); distinct previous-root capacity and physical unreachable-record GC remain production gates. Actual existing retained-worker cold validation is7.18s in an additional read-only probe; see performance report. No complete new native current-state validator,50k durable transactions or5000 native races is certified.
