from pathlib import Path
import json,csv,hashlib,subprocess
O=Path(__file__).resolve().parents[1];E=O/'evidence';R=Path('/workspace/BNT');C=Path('/workspace/deliverables/bnt-m5-content-v1');A=Path('/workspace/deliverables/bnt-m5a-feasibility');INV=json.loads((E/'native-inventory.json').read_text());TIM=json.loads((E/'timing-summary.json').read_text());S=json.loads((O/'BNT_M5_Proposed_Competition_Content_Schemas.json').read_text());EX=json.loads((O/'BNT_M5_Illustrative_Competition_Profiles.json').read_text());VALID=json.loads((E/'schema-validation-results.json').read_text());assert json.loads((A/'evidence/completion.json').read_text())['status']=='COMPLETE_FEASIBILITY_ONLY'
def w(n,t):(O/n).write_text(t.strip()+'\n')
def tab(h,rows):return '| '+' | '.join(h)+' |\n| '+' | '.join('---'for _ in h)+' |\n'+'\n'.join('| '+' | '.join(str(c).replace('|','/')for c in r)+' |'for r in rows)+'\n'
H='**M5 competition readiness audit • 24 November 2026 • Investigation/design only.** Accepted M4 source/artifact and M5 Content Candidate v1.0 unchanged. EXISTING denotes verified code; PROPOSED denotes unimplemented contracts. Examples are explicitly UNAPPROVED.'
geomrows=[[x['id'],x['name'],x['kind'],round(x['referenceLengthM'],3),'/'.join(str(round(z,3))for z in x['laneLengthsM']),x['segments'],x['cells'],x['defaultGridMaxEntrants'],x['checkpointCount']]for x in INV['rows']]
ctx=[]
for d in INV['championships']:
 v=d['offer']['value'];t=d['terms'];ctx.append([d['id'],v['name'],json.dumps(v['qualification']),v['entryFee'],v['fieldSize'],len(v['schedule']),' / '.join(x['format']for x in v['schedule']),t['titleGold'],t['titleRep'],t['trophyId']])
# CSV has distinct record types so no invented conflation of geometry and surface.
with(O/'BNT_M5_Geometry_and_Surface_Inventory.csv').open('w')as f:
 writer=csv.writer(f);writer.writerow(['record_type','native_id','name_or_kind','reference_length_m','lane_lengths_m','lanes','default_lane_width_m','segments','cells','default_grid_supported_up_to','championship_cap','parameters','validation','source'])
 for x in INV['rows']:writer.writerow(['geometry',x['id'],x['name'],x['referenceLengthM'],json.dumps(x['laneLengthsM']),4,4,x['segments'],x['cells'],x['defaultGridMaxEntrants'],8,json.dumps({'terrainMetres':x['terrainMetres'],'checkpointCount':x['checkpointCount'],'firstStraightTiles':x['firstStraightTiles'],'gridGap':x['gridGap'],'gridOffset':x['gridOffset']}),x['footprint']['valid'],'src/track/catalog.js:3–32; course.js:17–77; oval.js:6–44'])
 for id,coef in INV['terrainProfiles'].items():writer.writerow(['surface',id,id,'','','','','','','','',json.dumps(coef),'native coefficient ranges verified','src/track/course.js:3–9; surfaces.js:2–3'])
 for id,coef in INV['weatherPresets'].items():writer.writerow(['weather',id,id,'','','','','','','','',json.dumps(coef),'environmentConfig finite0.1..3','src/sim/environment.js:4–44,135–155'])
 for cat,x in TIM['generatedByCategory'].items():writer.writerow(['rally-category','generated-'+cat,cat,str(x['minLength'])+'..'+str(x['maxLength']),'',4,4,'variable','variable',64,8,json.dumps(x),'30 seeded probes +native footprint; default grid64 observed for fixed legacy rallies, generated field8 tested','src/track/rally-generator.js:9–77'])
w('BNT_M5_Track_and_Venue_Contracts.md',f'''# BNT M5 — Track and Venue Contracts

{H}

## Verified geometry catalog

EXISTING `src/track/catalog.js:3–32`:3 oval presets and12 circuits. `course.js:107–112` also retains2 legacy circuits and2 fixed rallies. Thus19 inspected fixed preset entries, not19 distinct new catalog circuits. `technical-circuit`/C01 and `fast-circuit`/C05 share geometry but may differ in surface assignment; do not alias full physics merely from equal lengths.

{tab(['Native ID','Name','Kind','Reference metres','Lane0/1/2/3 metres','Segments','Cells','Default grid max≤64','Intermediate checkpoints'],geomrows)}

These lengths are computed from actual compiled geometry/default four lanes4m wide. The grid column probes createRace counts1..64 with default gridGap2 tiles/gridOffset.5.64 means the native input ceiling was reached, not proof of capacity beyond64. Championship field remains1..8 (`championships/offers.js:11–16`). Actual changed width/grid configuration needs validation again; all catalog tracks accept the current8-entrant field.

## Physical contracts

- `track/oval.js:6–44`: two straights/two semicircular turns; shared longitudinal cells; start/finish halfway through a straight. Lane radius=innerRadius+lane*laneWidth, lap length=2*straightLength+2π*radius. Default oval per-source configuration differs between Short/Standard/Grand. Global config permits lanes1..8, but M5 default4.
- `track/course.js:17–77`: id ASCII native-safe≤64/name≤100, kind Circuit/Rally, closed iff Circuit, **lanes exactly4**,2..128 segments. Each segment: unique id, length1..2000m, tiles1..256, turn−180..180°, correct next linkage; first segment straight with≥8 tiles; Rally final straight. Native turn radius must fit all lane offsets. Closed seam position tolerance1e−6m/heading1e−7rad.
- Course lane length uses radius−sign(angle)*lane*laneWidth; right/left relative lanes differ. This is not the oval convention of monotonically longer outer-lane laps. Circuit start offset=floor(firstStraight.tiles/2); Rally offset0 and open endpoint extensions. `coursePoint`, `courseLocation`, `courseDistance`, `oval.point/location/finishQ` serve physics/rendering/progress.
- `validateFootprint(track,config)` samples the road corridor and detects distant overlap/ambiguous proximity. **createRace/freezeOffer do not automatically call this full corridor test**; generator does. The authoring compiler must call it on every resolved new configuration, not just accept JSON/connectivity.
- Race setup stores the resolved normalized course and full native config/entrants/surfaces/weather/environment metadata (`sim/race.js:235–263`). Freeze exact setup/hash at race birth; never reconstruct an established race from mutable current defaults.

## Surface and environment

{tab(['Terrain','Grip','Roughness','Rolling resistance','Hazard placement weight'],[[id,*v.values()]for id,v in INV['terrainProfiles'].items()])}

Coefficient bounds from `track/surfaces.js`: grip.1..2, roughness0..2, rollingResistance.1..2, hazardModifier0..2. First M5 content should select existing terrain presets rather than author arbitrary coefficients. Dirt is not neutral oval surface: oval defaults are1/0/1/1 until patched. Course segments merge defaults→terrain→explicit surface. When changing terrain on a previously normalized segment, old explicit coefficients can override the new terrain; compile from fresh template, clear derived overrides or deliberately compute final patches. Do not alter frozen active segments.

`createRace({{surfaces:{{segmentId:patch}}}})` supports per-segment patches for oval and courses; every segment can receive one terrain preset's coefficients. Course definitions also carry terrain per segment. Uniform/all, straight/corner patterns and explicit keyed segment maps are feasible compiler operations; seeded weighted pattern selection is a new generation adapter. Oval surface patch changes coefficients, not an existing terrain-name field. UI venue metadata must label intended surface correctly.

{tab(['Weather','Grip','Visibility','Fatigue','Recovery','Rolling','Crowd'],[[id,*v.values()]for id,v in INV['weatherPresets'].items()])}

Weather preset values from `sim/environment.js:4–44`; overrides finite.1..3 but first M5 should use presets. `race.js:421–430` combines surface/environment grip and rolling; environment.js:105–132 uses fatigue/recovery/roughness/wear; AI perception uses visibility. `incidents.js:92–106` hazardModifier weights eligible placement cells, **not global incident-clock frequency**. Incident types debris/animal/spectator exist; regional snow/ice, gust lateral forces, flooding, magic terrain or crowd-driven physics do not. Cold national architecture can be visual with existing Clear/Rain conditions; no snow traction approximation claimed as native ice mechanics.

## Rally generator

`rally-generator.js:9–77` has17 chunk IDs, categories short6/medium12/long22 chunks, terrain profiles balanced/road/rugged, safe-integer seed, optional weights0..100 nonnegative/nonzero, turnFrequency/turnSeverity0..1, chunks4..24, attempts1..32(default12), laneWidth1..4(default4), custom chunk library≤64 entries/1..5 segments with length1..200, turn±170. M5 need not expose custom chunks. Each generated route has80m endpoints, full resolved geometry, generation.version1/seed/options/attempt/fallback/chunk list. Bounded attempts then deterministic straight fallback are existing behavior, not arbitrary reroll success.

90 fresh seeded samples (30/category) repeated exactly and pass corridor validation; fallback0 in that sample. Median generation/validation short{TIM['generatedByCategory']['short']['medianMs']:.3f}ms, medium{TIM['generatedByCategory']['medium']['medianMs']:.3f}ms, long{TIM['generatedByCategory']['long']['medianMs']:.3f}ms; observed long maximum{TIM['generatedByCategory']['long']['maxMs']:.3f}ms. Existing deliberate-fallback tests also pass in the executed suite. Names like `wide-passing`, `narrow-passage`, `rough-section` are **chunk labels**: no variable per-segment lane count/width or guaranteed rough surface follows from the name.

Seed alone is insufficient for permanent prestige reconstruction: pin generator version, ordered terrain/chunk recipe/catalog digest and fixed seed, validate/cache static resolved definition. Native metadata preserves full options, and import treats resolved geometry authoritative. Object iteration order influences native weighted chunk/terrain choices; do not re-sort old native recipes or update defaults under the same version. New content compiler uses a declared stable native terrain order and keeps exact resolved active geometry.

## Checkpoints / Signs / distance

Base generateRally always emits3 quarter-route checkpoints. Accepted `prototype/session.js:9–11` wrapper creates category Sign Points short1@1/2, medium2@1/3,2/3, long3@1/4,1/2,3/4; `normalizeCourse` validates the explicit policy and fractional distances. These are distinct configured paths, not proof every career Rally currently uses category-dependent points. M5 compiler should reuse the approved explicit policy for new generated courses and preserve old configurations unchanged.

`race.js:451–459,962–976` stops subevents at marker arrival and processes ordered crossed points in a while loop. Multi-marker/tick advance cannot skip queued activation if existing logic is reused. Pause/step changes playback, not tick order; crossing an activation point does not itself spend an opportunity—the queue command does. Default budget3 remains, with existing M4 modification. Point-to-point finishQ ignores lap multiplier; current Iron Gauntlet advertises laps2 even on fixed Rally, but its native Rally still runs once. Preserve that historical behavior; new Rally authoring declares one point-to-point traversal, not fake multi-lap open courses.

## Venue separation and prestige plan

PROPOSED geometryRef→venue identity/config→event setup. Embed16 prestige definitions (2/N planning target), share existing geometry refs and versioned surface/environment profiles. Store only venue/template versions in idle offers; freeze full resolved native setup at registration/start where native replay requires. No bespoke geometry/physics is needed for signature combinations. Generated venue IDs come from a separate career/epoch/context RNG domain, proper names from regional pools with bounded collision retries. Retain generated identity through the championship, compact historical name/region/geometry digest afterward; no ever-growing active venue registry.

Keep geometry template IDs and venue/event IDs separate. Existing renderer geometry cache/track sampling can draw every template. Oval template names and native reporter track tokens are not venue-aware; extend display metadata/projection without rewriting accepted reporter events or mutating old presets. Do not claim renamed geometry is a separate new physical circuit. Signature terrain/weather/architecture is feasible; narrow variable-width tracks, jumps, ice, magic obstacles and procedural circuit synthesis are deferred.
''')
w('BNT_M5_Event_and_Championship_Contracts.md',f'''# BNT M5 — Event and Championship Contracts

{H}

## Native event / schedule boundary

A venue is identity+physical configuration; an event chooses that venue, format/distance/weather/grid and official competition context. EXISTING native race `createRace` accepts course, seed, overrides, entrants, Pure/Combat, weather, surfaces, environmentOverrides, player/coaching/payroll/progression contexts and consequences (`sim/race.js:45–108,235–263`). Track topology Oval/Circuit/Rally is **not** the Pure/Combat enum.

`championships/offers.js:11–20` template exact fields: kind/version/templateId/name/entryFee/fieldSize/qualification/schedule/points/dnfPoints. Field1..8; races1..12; points length=field size, nonnegative native Gold-safe integers. Schedule exact input keys **course,format,weather,laps,grid**. It resolves native course and full config, adds raceOrdinal, computes fingerprint, freezes. Grids random/standings/reverse. Native laps1..100; new open Rally authoring uses one traversal, not lap multiplication.

No event/venue ID, surface patch, arbitrary width override, location, reward binding or opportunity epoch is currently accepted in that schedule shape. Course-segment terrain can be authored inside a normalized Circuit/Rally definition; **oval surface overrides require an additive resolved-event adapter** because surfaces cannot be added directly to current freezeOffer rows.19 geometry probes prove native createRace surfaces roundtrip, not controller acceptance of arbitrary extra schedule keys. Corridor validation must be explicit. Do not route generated competitions around current validators.

PROPOSED event identity wrapper references venue/template version, native resolved setup fingerprint, format/distance and competition binding. Different events may share permanent venue definitions and differ in race seed/weather/laps/grid without copying a full static catalog. Freeze resolved per-event setup in active authority; use names/digests in compact history.

## Existing competition contexts and rewards

{tab(['ID','Competition','Qualification','Fee Gold','Field','Races','Pure/Combat order','Title Gold','Title Rep','Trophy'],ctx)}

Catalog `e5b-provisional-catalog-v1` (`e5/catalog.js:4–26`) is static playtest content. All events Clear; first random grid then standings; ordinary laps1, Iron Gauntlet laps2 (Rally ignores multipliers natively). Five standard contexts match supplied M5 difficulty bindings. Iron Gauntlet is a special Bannerfall-trophy-qualified competition; reuse existing top strength context if approved, not a new adaptive sixth ladder. No separate native Combat/Circuit/Rally unlock flag exists: qualify the championship, then its disclosed schedule may contain both Pure/Combat. Do not invent format-specific reputation gates.

{tab(['Context','Points','Ordinary purse','Final purse','Champ placement Gold'],[[d['id'],'/'.join(map(str,d['offer']['value']['points'])),'/'.join(map(str,d['terms']['purses'][0])),'/'.join(map(str,d['terms']['purses'][-1])),'/'.join(map(str,d['terms']['placement']))]for d in INV['championships']])}

All DNF points/purses0 in this catalog. XP each start/finish/podium/win1; player driver+both registered beasts receive applicable XP. Reputation start10/finish5/podium10/win15; final placement20/15/10/5 then0, truncated to field. Title values above and trophy/victory facts apply per current rules. Full native definitions/terms/fingerprints are preserved in evidence/native-inventory.json, not replaced by a parallel reward table.

## Qualification / registration / lifecycle

`offers.js:2–9` supports reputationAtLeast, hasTrophy, victoryCountAtLeast and nested all/any (≤32 each). `e5/schema6.js:27–33` e5.register resolves **catalogDefinition(templateId)** and demands exact board equality. `controller.js:30–40` validates qualification, one active/unsettled run, owned legal assignment, all event grids, revisions and funds before one fee debit. Frozen selection, ordered two beasts, chariot/equipment and player payroll context cannot be changed by generated content.

Manual start (`controller.js:45–48`) from INTERMISSION_READY/AI_CONTINUATION freezes raceSetup/race ID and binds durable birth. Race runs in memory through accepted P1 boundary. D5 clearance must resolve pending processing and validate classification/identity/final native condition; durable native prepare/capability precedes single protected official career commit (`foundation/checkpoint.js:48+`, `controller.js:49–55`, `progression.js:35–55`). D2 condition mapping, standings, participation, pending awards, eligibility and phase commit atomically. Failed clearance blocks and preserves evidence, never fabricates DNF/advance.

Nonfinal event: Run offer only after actual player start, official result and continuing eligibility, excluding DNS/DQ/withdrawal; selection blocks next preparation. Forced ineligibility/voluntary withdrawal ends player participation, **not** remaining frozen schedule. AI-only fields can shrink to1 starter (run normally) or0 (validated no-starter evidence). Final official event →SETTLEMENT_PENDING; one final settlement processes prize/XP/reputation/trophy/payroll/contracts/recovery; eligible Completion Bonus selection, then archive/unlock (`e5/schema6.js:12–38`, rewards.js:1–23).

## Scoring / eligibility details

Native finishTime and finishTolerance{INV['config']['finishTolerance']} define official shared places, using full precision, not rounded display text (`race.js:378–419`). Competition ranking ties receive full points/purses and each shared first place counts as win. `scoring.js:3–39` adds authoritative first-reached DNF progress ordering, points→countback places→last rank→stable ID; title candidate must start final event, with legitimate DNF allowed, DNS/Disqualified/Withdrawn excluded. Native engine checkpoint statuses are Racing/Finished/Retired/DNS; DQ names in downstream filters do **not** prove an implemented native disqualification action. Do not author a new DQ mechanic under event metadata.

Legacy/Completion eligibility includes a legitimate start, full frozen schedule completion (including AI continuation) and no voluntary abandonment. M4 uses functional21 Run Rewards/8 Legacy upgrades/3 Active slots. `m4/progression.js:29` Completion Bonus uses **BONUS_TIERS[templateId] ??1**. That fallback is a generated-ID trap: new tier5 template IDs would silently receive tier1 completion Gold/reputation. Add explicit approved mechanics context binding; do not accept fallback as intended balancing.

## Static-ID dependencies and required changes

- e5.register/catalogDefinition and board validation accept only6 static IDs. Add a trusted generated-definition/opportunity producer, not an arbitrary UI offer object.
- Terms/trophy IDs/qualification facts/victory counts and Completion Bonus tier derive from native template IDs. Separate permanent competition identity, generated opportunity/instance identity and mechanics/qualification/reward context. Preserve native formulas and signature achievements.
- e5.refresh merely republishes the same static catalog; no generation epoch/expiration/market renewal exists. New batch authority required.
- Native offer cannot carry oval surfaces/environment customizations/venue identity; version the resolved-event contract and validators. Do not add permissive unknown keys or bypass setup checks.
- Current hard-coded generic rival generation must receive frozen persistent/local native profiles; official entrant/result keys remain unchanged.

## Schedule and opportunity proposal

Start with context-approved field size/event count/fee/award binding and native format pattern; generate locations/compatible geometry/surfaces from versioned profiles.1..12 races and1..8 fields are native capabilities, **not blanket approval** to pay a7-race purse/title for a1-race generated event. A single-event competition can reuse the lifecycle but needs an explicit supported economic binding. Avoid a separate special-event controller. No player-relative strength.

Seed schedule before fee, validate all venues/grids/format/distance/geo rules, bound retries, freeze entire selected schedule/roster once. On failure retain committed opportunity batch and Gold; no new epoch/reroll. Permanent signatures remain available independently of renewable opportunities; selecting/previewing is read-only. Persist opportunityId +batchEpoch +fingerprint/revision; source selection stale rejects. Exact counts/renewal criteria configurable, not hidden UI behavior.

## Owner-facing open decisions

Generated trophies/victory qualification credit must be explicit: do generated Bannerfall-context wins earn trophy-bannerfall and unlock Iron Gauntlet, or are named trophies reserved for permanent championships? Do not silently choose either. Recommend preserving signature-only unlock credit pending approval and explicitly binding generated Completion Bonus tier/fee/purse. Zero-start voluntary withdrawal renewal and cross-championship rival condition reset also need disposition. National→international weighting is a content proposal, not a new travel cost or qualification gate.
''')
w('BNT_M5_Hybrid_Rival_and_Local_Competitor_Contracts.md',f'''# BNT M5 — Hybrid Rivals and Local Competitors

{H}

## Existing native foundation

`championships/controller.js:35` creates rivals **per championship**, using defaultRU(entrantId,46+2*i), same stat for every component, no independent driver/beast/chariot career records and assetIds:null. Strength follows field ordinal48..60, not the five proposed competitive tiers. `progression.js:16–17` normalizes/freezes personality at registration; :45–46 updates native condition and management conditionState after each official result. `prepareRace:69–77` uses same engine/native stats for players/rivals, deterministic grid/race seeds and eligibility. No offscreen finance/development or recurring identity population exists.

## Approved new model / proposed contract

Maintain3–5 persistent organizations per accessible competitive context, lazily generated once using a committed tier birth epoch and fixed final native member profiles. Five tiers yield15–25 teams at that planning scale; M5-A32–128 is a stress target/reserve, **not a required minimum population**. Exact counts remain configurable. Save org/member IDs, proper names, culture/nation, native attributes, six driver traits, native chariot/equipment configuration, presentation refs and lightweight result-keyed encounters. Do not resample quality/attributes after player wins, wealth, Legacy, years or reentry into a tier.

For each championship, select2–3 persistent entrants where field permits, then fill other nonplayer slots from location-weighted local generation. For field4,3 persistent would leave no locals: cap persistent participants to min(configured,fieldSize−2) when at least one local is required. Recommended starting default2 persistent for current4..8 fields. Smaller fields1/2/3 degrade explicitly; never fabricate entrants or alter current eligibility handling. Unavailable/rejected candidates need bounded selection from remaining valid profiles; failure must not debit fee or silently reroll an established batch.

Local teams use existing nation/culture/name/background/AI/species/stock/temperament/quality/chariot/equipment profiles, weighted toward championship venue region with nonzero imported competitors. A local is championship-scoped, named as completely as a persistent team, and frozen for the full schedule. All mixed-ancestry/national routes remain source-compatible; local does not mean ancestry-exclusive. No generic AI Team/Rival3/Driver4/Beast2 fallback.

## Identity and authority mapping

Separate `organizationId`/member IDs from native per-instance entrantId. Example future mapping: entrant e2-… →rival organization stableID or local(instanceID,ordinal); driver/beast/chariot identity refs+frozen final name map. Existing official proof/rows/effects continue referencing entrantId. Do not replace result keys or insert rival assets into player-owned registries. Native ownership graph requires player career owner for owned assets; it is the wrong container for rivals.

Persistent profile=current birth strength, active snapshot=mutable condition for this championship, history=compact encounter/source result references. No complete organization graph copied into every race; freeze display/roster once at registration and reference from results. Local active records leave after final settlement/Completion Bonus/archive checkpoint, **not** immediately after one race. History pages retain exact team/member/venue names and final outcomes even when active locals disappear. Updates to catalogs must not rename old results.

## Cross-championship condition policy — unresolved design

Native current rivals are newly initialized each championship; no permanent death/deletion is modeled by current D2 Critical/Destroyed. Recommend an abstract fresh-native-condition baseline at next championship while preserving fixed attributes/personality/configuration; this maintains fixed competitive strength without an offscreen hospital/repair simulation. It is a proposed player-facing reset policy and requires owner disposition. Carrying injuries indefinitely would change effective strength/deplete the small population and require an explicit replacement rule. Do not automatically infer permanent death or silently heal before approval. Within-championship carryover remains unchanged under either future boundary policy.

## Candidate v1.0 compatibility

Reuse all16 catalogs: identity/attributes/naming/AI/species/stock/staff/chariot/equipment/quality/visual records are factories/content inputs, not mature lifecycle code. Existing40 rival generation profiles already bind eight nations×five contexts and disable offscreenSimulation. Reuse them for **birth**, once per persistent organization, or once per local championship. The same profile does not imply reroll each registration.

Targeted candidate v1.1 companion additions: explicit tier birth/lazy population policy, immutable final strength/provenance, persistent-vs-local lifecycle, encounter history keys and regional input reference. Amend provisional-balance-policy/difficulty bindings and integration notes to describe fixed birth +location-weighted locals, not player adaptation; preserve v1.0 hashes. No wholesale factory rewrite or new rival economy needed. Iron Gauntlet can use existing tier5 strength binding rather than grow a parallel ladder, while its trophy qualification remains separate.

## Tests required

Same org/member names/traits/stats recur after save/reload/reenter; no player-relative changes; new tiers create distinct fixed populations; duplicate entrant selection rejected; field4 reserves a local; smaller fields and zero-starter proof; condition and personality persist within schedule; explicit between-run reset/carry policy; local names never generic; exact historical names survive compaction/catalog update; lost publication acknowledgment does not double encounter counters; no player-owned graph injection. Full native race/Sign/D2/reward regression after future integration. Audit probes validate native geometry and existing lifecycle tests, **not** an implemented hybrid field.
''')
sections=[]
for family,qs in EX['records'].items():
 d=S['$defs'][family];rows=[]
 for k,v in d['properties'].items():
  descriptor=v.get('$ref',v.get('const',v.get('enum',v.get('type','nullable/compound'))));bounds=', '.join(str(x)+'='+str(v[x])for x in ['minimum','maximum','minItems','maxItems','maxLength']if x in v);rows.append([k,'required'if k in d['required']else'optional',str(descriptor),bounds or'local $defs /semantic checks'])
 sections.append('### '+family+'\n\n'+tab(['Field','Presence','Type/ref/exact enum','Bounds'],rows)+'\nExample: `records.'+family+'[0]` in illustrative bundle. No example is approved production content.\n')
w('BNT_M5_Competition_Content_Authoring_Specification.md',f'''# BNT M5 — Competition Content Authoring Specification

{H}

## Production scope

Author static/versioned competition catalogs against the proposed Draft2020-12 schema.11 families consolidate the requested logical list: geometry, environment(surface+weather), naming(venue/event/championship), venue(prestige+renewable), event, tier binding, championship(permanent/generated/prestige/special), rivals, locals, presentation and renewal. Do not create a new runtime engine/save schema from these records.

Target16 authored prestige venues,2 per N1–N8, plus regional generated venue profiles; all use existing3 ovals/12 circuits or existing rally generator. No complete production venue/championship catalog was created by this audit. Supplied21 records are small relationship examples, all `UNAPPROVED_EXAMPLE` and root `UNAPPROVED_EXAMPLES`.

## Existing catalogs and references

M5 Content Candidate v1.0 remains unchanged:16 catalogs/256 records,35 cultural profiles,30 visual profiles and40 rival birth recipes. Its canonical index maps N1–N8/A01–A13/B01–B09 and39 stock styles/lines. Original canon v1.0 files are centrally available in candidate/canon; original nation prose governs architecture/location associations, not numerical track bonuses. Missing separate prior World Identity Catalog/differently named Updated_2026-11-21 source remains disclosed; no replacement canon invented. The current source catalog, not a prose proposed venue name, decides what geometry exists.

External references: existing `culture.nX.rY`, `visual.nX`, `rival.nX.context` and `difficulty.context`; native qualification/fee/awards binding `native.context` resolves actual accepted e5 catalog. Region IDs are existing cultural-affinity keys, not falsely asserted native geographic IDs. Prestige names/concepts from nation prose may be explicitly provisional; cite them rather than promote them to established tracks silently.

## Shared contract

Profile id lowercase namespaced ASCII≤64, distinct from native instance IDs (native IDs disallow dots). Every record has version1, approval UNAPPROVED_EXAMPLE/DRAFT_FOR_REVIEW/APPROVED, label≤100 and1..8 sources. Source fields authority canon/native-contract/audit-proposal, file≤250, SHA25664hex, positive start/end lines. Actual file digest/range, source authority and approved canon associations must validate. Root declares format, catalogVersion, approval and records. All fields required unless noted; unknown keys reject. Optional null explicitly means inapplicable, never random hidden fallback.

Weights positive finite≤1e6, typed unique refs; no automatic demographic exclusion from missing profile. Use declared stable ordering/versioned domains. Naming pools must be nonempty, pronounceable, source-compatible, max100 characters; bounded retries≤64 and no generic fallback. Profiles describe factories; successful generated venue/event/championship gets a proper persisted name distinct from internal ID/template label.

### Native constraints authors must respect

- Geometry: preset IDs in inventory; four-lane Circuit/Rally, geometry-specific valid widths/corner radii; M5 contract conservatively permits width1..4, current controller only propagates laps, so nondefault width needs the proposed resolved-event adapter. Preset resolver has rallyOptions=null; generated resolver requires valid category/options and corresponding generated-* selection token. That token is **not** directly accepted as a native course string: call generateRally then pass resolved definition.
- Surface/environment: dirt/stone/gravel/sand/mud; Clear/Rain/Heavy Rain/Mud/Dust/Wind/Extreme Heat exact strings. Assignment selectors all/straights/corners/segment are compiler instructions, not native fields. Explicit segment must resolve; segmentId null for other selectors. Reject overlap/ambiguous assignments unless precedence is specified; recommended all base then disjoint scoped overrides, no order-dependent surprise. Native preset coefficient table governs values; no invented snow/ice/gusts.
- Rally seed/options/generator version and terrain weight order pin reproducibility. Prestige pinned seed retains resolved static course; renewable venue uses independent generation domain. Fixed route can host different weather/race RNG seeds. Category Sign Points are an existing explicit wrapper, not default native3 checkpoints; compile chosen policy once, never rewrite old courses.
- Event: Pure/Combat independent from topology; grid random/standings/reverse, laps1..100 for closed, exactly1 for new point-to-point. All candidate venue topologies must match distanceMode and supportedFormats. Native field count1..8/races1..12 are upper capabilities; economic binding must explicitly authorize selected values.
- Tier: use native five contexts; Iron Gauntlet remains an existing special exception, not a new progression tier. qualificationBinding/feeAndAwardBinding must match approved native catalog, field/race counts and Completion Bonus tier. Custom Gold/purse formula fields are forbidden. Generated named-trophy/victory credit cannot be left undecided in a production build.
- Rival population:3..5 per tier planning range; 2..3 per field planning target; actual selection leaves player/local slots where possible. Final birth attributes/personality/config never scale to player. Cross-champ condition policy must be approved, not silently selected from examples.
- Renewal: committed epochs; no page-open/reload/time RNG; purchase never automatically replaces a listing. Full Home and limited regional policy contexts distinct; regional permanent staff disabled for initial M5. Exact counts/triggers are configurable content, with zero-start withdrawal disposition requiring review. No roster substitution through purchases.

## Required / optional field reference

'''+ '\n'.join(sections)+'''
## Typed dependencies and semantic validation

Build indexes before resolving references; reject duplicate IDs/JSON keys/nonfinite numbers and unknown versions. geometry nativeId/kind/resolver must agree with source catalog. environment references only native coefficients/weather and actual segment IDs after resolve. naming usage must match venue/event/championship consumer; culture belongs to intended nation/region without ancestry lock. venue nationality/region/environment/geometry/presentation must resolve. events reference compatible venues and native contexts. championships reference supported events/tier/rival/renewal/presentation, geographic scope and source-compatible regions. Local and persistent birth weights reference the unchanged M5 recipes of the correct context; permanent attributes are sampled once, not every race.

Compiler must additionally enforce ordered ranges, unique weights, group field capacity, scalar checks, corridor/grid validity, prestige count≤races, repetition limits, event format order, field+points/purses vector sizes, exact fee/qualification/tier mapping, no new unapproved unlocks, supported asset IDs and production approval status. These semantics are not guaranteed by JSON Schema alone. Example validation covers source/reference/type relationships, native context equality and topology, plus six invalid-input cases; it is not a complete future production compiler.

Production rejects REQUIRES_OWNER_DISPOSITION or unapproved examples. Missing expected content stops batch preparation without fees/epoch changes; it must not reroll repeatedly or substitute Generated Arena. Statically compile catalogs and source digests into single HTML; no network/schema fetch or runtime LLM.

## Proposed authoring order and outputs

1. Geometry references and environment patterns from inventory; native mechanics unchanged.
2. Venue/event/championship naming by all8 nations/35 regions; existing cultural pools can supply components, but supplier/team words are not automatically venue nouns.
3.16 prestige venues and regional renewable venue profiles; select authored proper names/geometry/weather/surface distinctions without bespoke physics.
4. Context bindings and schedule profiles after trophy/short-event economic decisions; preserve permanent signatures. National/regional baseline, higher-tier international variety as proposed weighted content policy, not mandatory travel/unlock mechanics.
5. Hybrid tier population/local competitor and renewal policies, tied to M5-A epochs and explicit intermission acquisition scope.
6. Presentation/brief metadata and compiler/statistical/native test fixture packs.

Content production can start now for identities, naming, geometry/surfaces, prestige concepts and provisional profiles. Mark unresolved gameplay-policy fields draft until owner dispositions. No blocker requires inventing absent native mechanics. Files should be separate versioned catalogs plus manifest/source/dependency reports, not a native-save dump.

## Visual metadata and briefs

Reuse `worldVisualProfileId` and existing architecture asset refs. Dark Deco silhouettes, reusable national materials/palettes, venue/environment framing and championship emblem parameters are sufficient before final art. No unique image for every generated venue/event/team. Any futureBrief must include id, SVG/PNG format, source≤8192px/runtime≤2048px dimensions, complete prompt and required licensing; art validation/source transparency/anchor/layer must follow accepted presentation contract. No image generated here.

Current manifest64 entries, existing11; AssetLibrary image24 entries/8MiB and composites16/4MiB. Do not combine55 candidate future art IDs +11 current into66 silently; stage/replace verified proof entries under separate art integration authorization. The competition metadata examples use existing proof architecture assets, with no new actual image dependency.

## Versioning / candidate amendment

Publish supplemental competition schema/catalog version separately. If changing M5 candidate metadata (fixed-tier lifecycle, regional Market context, difficulty/economic bindings), issue v1.1 with new hashes and explicit supersession; retain original v1.0 bytes. Most16 core profile shapes remain reusable, not a reason to rebuild world/personnel catalogs. New runtime/save contracts require implementation authorization and native regression; JSON validation is not implemented gameplay support.
''')
persistRows=[['Prestige geometry/venue definitions','Static embedded','Version/digest refs in idle state; full resolved active setup frozen; no copies of whole world catalog.'],['Opportunity batches/epoch','Renewable durable inventory','One committed batch; stale epoch rejects; viewing/reload never renew; expiration policy needs zero-start disposition.'],['Selected schedule/entrants','Active championship authority','Freeze after trusted registration; preserve D5,condition,standings,Run/settlement gates; not disposable until fully archived.'],['Generated venues/events/local teams','Active then compact history','Keep final proper names/region/type/digest and result-linked identities; discard detailed active candidates only after checkpoint authority.'],['Persistent tier populations','Bounded permanent authority','Birth once per accessible tier; fixed stats/personality/config; encounter refs paged, no offscreen management.'],['Regional Market','Scoped temporary durable inventory','Epoch=(instance,nextEvent,batchVersion); consumed IDs never auto-replace; acquired asset facts survive disposal.'],['Home Market','One renewable durable batch','Full renewal at approved between-champ transition; distinct epoch from regional/opportunity; zero-start exception clarified.'],['Geometry caches/preview meshes','Derived disposable','Rebuild from validated frozen setup; cache not authority.'],['History labels/settlement refs','Compact authoritative history','No rename on catalog updates; retain full-precision official classification and earned award identities.'],['Generation retries/intermediate pools','Disposable unacknowledged','Failure no fees/epoch advancement; bounded retries; no generics.']]
w('BNT_M5_Competition_Persistence_Coordination.md',f'''# BNT M5 — Competition Persistence Coordination

{H}

## M5-A input, not repetition

M5-A completed first and recommends **Option B**: validated current checkpoint +bounded journal +immutable paged compact history +current/previous root references.25 model tests,9 actual temporary-IDB checks,36 existing tests pass. Target500 championships/5000 race/50k finance-summary rows materializes~11.7MB total/228KB checkpoint; historical100k-candidate count is modeled, only100 active candidate objects materialized. Prior-root distinct-body overhead and physical unreachable-body GC remain production gates, not proven bounded retention. Current coordinator/validator changes are not implemented.

Expanded competition does **not** change that architectural recommendation. It expands current-state validator/epoch/identity obligations and increases compact labels. It must not reintroduce completed full session replay as sole career authority or demand a new backend. Production M5-A remains a prerequisite before renewable competition authority.

{tab(['New data','Retention class','Rule'],persistRows)}

## Atomic lifecycle and checkpoint coordination

Initial opportunity/Home batch creation is part of staged career initialization; no partial playable career. Registration verifies exact opportunity epoch/fingerprint/qualification/revisions, prepares full valid schedule/entrants and atomically debits fee+freezes active authority. Failed generation/registration keeps previous committed batch and funds. Do not consume generation counters on rejected preparation.

Official event publication still uses durable native prepare→validated capability→single career commit; Run choice and permitted regional batch generation follow its committed intermission. A regional batch is pinned to the next disclosed venue/event, not frame rate or map navigation. Each resource has its own committed epoch/semantic key. Terminal archive can roll a checkpoint and renew Home/opportunity batches in one authoritative transition or an explicitly staged once-only follow-up; a lost acknowledgment cannot repeat either renewal or reward credit. Exact zero-start withdrawal trigger needs owner disposition.

Keep full active evidence through settlement/Completion Bonus/archive, including old per-event financial anchors. Current settlement validates retained session authority (`e5/capabilities.js:8–17`); do not drop sessions early. After a new checkpoint establishes compact official authority, history no longer needs exact session bodies solely for old replay. Active interrupted races still restart saved initial setup; uncommitted Signs discarded, completed results durable.

## Regional acquisition requires a narrow new authority exception

`cycles/policy.js:8–9` currently makes stable management read-only during any active/unsettled run. Owner-approved regional recruitment/purchases therefore require **moderate command integration**, not a UI toggle. Permit only validated regional market.acquire at resolved eligible intermission, correct batch/next-event epoch, available funds/capacity/native employment terms. Keep registered RU frozen; purchases go to reserves/uninstalled equipment and cannot rescue an eliminated team or alter old race proofs. No ordinary treatment, repairs,training,contract changes,facility management or staff recruitment should slip through this exception.

Current next-race setup uses frozen entrant.native and player payroll context; registry expansion must not substitute its lineup. New financial anchor must reflect accepted intermission state for next event while old result anchors remain immutable. Terminal payroll uses complete current contract roster, so regional employment must disclose native full-cycle wage obligations rather than invent pro-rating; test those same existing semantics. Capacity may make a regional chariot offer unbuyable unless a spare bay already exists; show native reason, not an invented exemption.

## Capacity amendment

Synthetic M5-A already includes8 named participants/championship and event labels, so do not add that entire cost twice. Additional nation/region/tier/venue descriptors, version/digest links and surface/weather labels modeled at~160–600 extra bytes/race imply~0.8–3MB across5000 races, plus small current batches and persistent profiles. These are **estimates**, not measured generated career results.

A resolved Long Rally is6.7–8.9KB in measured samples. Retaining every route for5000 races would add~34–45MB before config/proofs/previous data. That is unnecessary for compact history; keep static refs/seed/version/digest and frozen labels there, full geometry only for active authority or explicit optional replay archive.12 active long routes~107KB raw course bytes +native configs/entrants/proofs; test actual whole aggregate against8MiB, do not infer fit from course bytes alone.

Five tiers at3–5 recurring teams mean15–25 initial populations, below M5-A128 stress reserve. Locals bounded by current frozen field≤8; remove active local registry after archival checkpoint/retained-name summary. History pages remain linear; no unlimited career claim. Opportunity counts/retry work should be management-transition worker work; do not generate during ordinary simulation or add per-tick writes.

## Save/restore invariants

Export checkpoint roots/tails/history pages, active frozen schedule/roster/venue identity, generator/catalog pins and needed native session prepare/birth. Validate all source/version/identity/capacity/epoch links before staged atomic restore activation; unrelated careers untouched. Do not regenerate absent offers/venues/teams on load. A missing referenced active record is recovery-required, not permission to invent names or reroll. Catalog updates do not relabel completed competitions. Previous-valid root activation is a new monotonic generation after explicit recovery, not rollback of writer generations.
''')
# Classification matrix.
readiness=[
('Existing oval/circuit geometry','Supported without modification','track/catalog.js;course.js;oval.js','3/12 templates and legacy presets','none','low','Native configs/source refs','inventory/footprint/grid','low',1),
('Region-specific surfaces/weather','Supported through configuration','course.js:3–38;environment.js:4–44;race.js:96–108','Native terrains/presets and segment patches','Resolved-event adapter for oval overrides','medium','environment profiles','all pattern/weather/native roundtrip','low-medium',2),
('Prestige venues','Supported through minor extension','geometry catalog +presentation renderer','Static identity wrapper/shared geometry','Proper names/location refs/version pins','low','16 proposed prestige venues','stable identity/reuse/name projection','low',2),
('Renewable venue identity','Supported through minor extension','M5 naming/RNG primitives','No live venue generation registry','Committed IDs/name collision/source pins','medium','regional naming/venue profiles','same seed/no reroll/bounded retries','medium',3),
('Seeded permanent/renewable Rally','Supported through configuration','rally-generator.js;prototype/session.js','Existing generator/fallback/SignPoint policy','Pin ordered recipe/resolved output/version','medium','rally profiles','90 probes +full native/replay','low-medium',2),
('Generated event resolution','Requires moderate implementation','offers.js:11–20;controller.js:69–77','Static schedule exact5 input keys','Versioned event surfaces/config/venue refs','medium','event/environment profiles','shape rejection +frozen setup parity','medium',3),
('Generated championship registration','Requires moderate implementation','e5/schema6.js:27–33;catalog.js','Static catalogDefinition/board equality','Trusted dynamic definition +mechanics binding','high','championship/tier profiles','atomic fee/stale/duplicate/capability','medium-high',4),
('Qualification/scoring/settlement','Supported through minor extension','offers.js:2–9;scoring.js;e5/rewards.js','Existing formulas/lifecycle reusable','Context/identity binding; preserve formulas','high','approved trophy/fee/award rules','exact old/new mechanical parity','medium',4),
('Completion Bonus tier binding','Supported through minor extension','m4/progression.js:29','Static BONUS_TIERS fallback1','Explicit context, no silent fallback','high','native tier binding','new IDs top-tier bonus parity','low-medium',3),
('Renewable opportunities','Requires moderate implementation','e5.refresh/static board','No batch epochs/expiration','Protected epoch/renewal/CAS/anti-reroll','high','renewal policy','withdraw/stale/failure/restore','medium-high',4),
('Fixed persistent tier rivals','Requires moderate implementation','controller.js:35;progression.js:16','Per-champ fixed snapshots only','Lazy tier birth/fixed native profiles','high','rival policy and reset decision','recurrence/no adaptation/condition','medium',3),
('Location-weighted locals','Supported through minor extension','M5 factories;native entrant shape','Catalog recipes available, no runtime factory','Champion-local birth/frozen identity','medium','local profiles','named/coherent/no duplicates','medium',3),
('Regional purchasing/recruitment','Requires moderate implementation','cycles/policy.js:8–9;economy reducers','Current active management rejects all','Narrow batch-scoped intermission acquire','high','regional renewal/purchase scope','roster freeze/anchor/payroll/fees','medium-high',4),
('Home full-market renewal','Requires moderate implementation','economy/market.js fixed23','No renewable epochs','Protected batch replacement/postcheckpoint','high','Home renewal/zero-start policy','no view/reload renew/acquire repeat','medium',4),
('Competition history compaction','Requires major architectural change','M5-A proposal/current full replay','No production compaction','M5-A checkpoint/current validator/pages','high','compact summary identity contract','rollover/GC/restore/native invariants','high',1),
('Management/viewer UI','Supported through minor extension','career-race/flow.js;HQ model;renderer','Existing events/details/standings/map','Venue/tier/local/persistent/name display','medium','display identity metadata','keyboard/responsive/actual packaged UI','medium',5),
('Procedural circuit geometry','Unsupported and recommended for deferral','Only preset circuit constructor/catalog','Not required by owner','Defer','high','none initial','not initial acceptance','high','defer'),
('Snow/ice/magic/variable segment width','Unsupported and recommended for deferral','native surfaces/weather/4lanes','No such mechanic','Use supported approximations as labeled;defer new physics','high','none initial','reject unknown properties','high','defer'),
('Independent rival economy/development','Unsupported and recommended for deferral','No offscreen authority','Owner prohibits','Do not implement','high','none','no generated hidden adaptation','high','excluded')]
with(O/'BNT_M5_Competition_Implementation_Readiness_Matrix.csv').open('w')as f:
 writer=csv.writer(f);writer.writerow(['capability','classification','source','existing_contract','proposed_change','risk','content_dependencies','required_tests','relative_complexity','order']);writer.writerows(readiness)
w('BNT_M5_Competition_Validation_and_Regression_Plan.md',f'''# BNT M5 — Competition Validation and Regression Plan

{H}

## Executed during this audit

{tab(['Command','Raw exit','Actual outcome'],[['node tools/native-inventory.mjs',0,'44 diagnostic groups,19 fixed preset entries;90 generated Rally recipes repeat/validate;6 repeated100-tick Pure/Combat cases'],['python tools/create-contracts.py',0,'11 strict authoring families;21 explicitly unapproved examples; no production catalog'],['python tools/validate-contracts.py',0,'172 schema/source/reference/native-context/candidate-preservation checks;6 invalid-input cases rejected'],['node --test tests/track-expansion.test.js tests/courses.test.js tests/m2-e-e2-e3.test.js tests/e5-b-foundation.test.js tests/e5-b-lifecycle.test.js tests/m4.test.js',0,'94 tests pass,0 fail/skipped/cancelled;96.9s managed-container run']])}

All command logs/JSON in evidence/. Existing tests include300 generated seeds in track-expansion plus three full native category races/replays and lifecycle/condition/reward cases. The separate audit diagnostic sample is90 seeds, not an additional300 claim. M5-A separately ran36 existing tests,25 model checks and9 HTTP temporary-IDB checks; do not describe these as a passing complete888-suite or a Windows acceptance run.

No full application/browser UI suite, build or Windows file acceptance executed here. Accepted888 tests/Windows success are historical baseline evidence. All187 source and53 changed-file hashes/artifact match; no golden references modified. Existing numerical/cross-runtime diagnostics were not “fixed” by updating expected values.

## Required native geometry matrix

-3 oval +12 catalog circuits, Pure/Combat, all supported context field sizes; validate corridor, start grid, lane lengths, closure, tile/turn bounds and initial footprints. Include legacy course aliases/fixed Rally to preserve old behavior. Each proposed surface pattern and weather preset resolves/freeze/reloads exactly.
- Generated short/medium/long: seed corpus including negative/large safe integer seeds, road/rugged/weighted terrain, corner settings, bounded retry/fallback and category SignPoint wrapper. Preserve native default-three legacy fixtures. Reject unknown surfaces/weather/lane count, bad grids, changed generator version, unsupported widths and invalid topology.
- Pause/step/speed and queued input at start/crossing/SignPoint; multi-marker/tick correctness, default3 opportunities/M4 modifier, no consumption merely from crossing. Replay setup and identical inputs exact in supported runtime. No new geometry, rounding, event-order or RNG consumption changes.

## Championship / economic matrix

Five contexts +Iron Gauntlet exception; exact qualificationRep/trophy/victory predicates, field/event count, fee, points/purses/title/XP/reputation/Completion tier and trophy policy. Same permanent venue hosts Pure/Combat/different weather without physical drift. Static signatures unchanged. Generated IDs cannot fall back to tier1 Completion Bonus or arbitrary UI awards.

Registration atomic fee+frozen roster/schedule; duplicate/lost ack/stale opportunity/invalid setup cannot charge or consume epoch. Native official publication only after D5; unresolved/stalled blocks. Shared placement fullprecision/finishTolerance/competition rank/full rewards; DNF first-reached progress; final start/title/null champion; DNS/disqualification restrictions preserved without inventing native DQ action.

Run choices, hard elimination, voluntary withdrawal, AI completion,1/0 starters, settlement/payroll/recovery once, Completion Bonus and archive. Rewards21/Legacy8/slots3/caps and authority unchanged. No unapproved travel, auto start, auto roster substitution, new fees or parallel economy.

## Hybrid rivals / markets

Lazy population3–5/context, fixed birth stats/personality;2–3 persistent selection constrained by field/local reserve. Local nationality/culture/import routes, coherent named members, collision bounds and frozen identities. Same team can recur without player-relative adaptation; higher contexts introduce new strength populations. Within-championship damage/fatigue persists; between-champ condition follows approved policy only. No permanent deletion rule inferred from Critical/Destroyed.

Home full renewal and regional limited batches: opening/reloading has zero renew effect; purchases don't refill; stale/failed writes preserve funds/epochs/remaining candidates. Full native acquisition/wage/capacity proof; regional staff excluded, purchases reserve/uninstalled only, registered lineup unaffected, no elimination rescue. Source previous/result financial anchors immutable; next race/terminal payroll includes correct accepted contracts. M4 Veteran Recruiters renewal frequency needs explicit policy: one lifetime extra candidate versus one extra Premium slot per renewed Home batch must not be guessed.

## M5-A / recovery / performance

Checkpoints: monotonic sequence/revision, complete current/native validators, tail/semantic once-only facts, missing/corrupt pages, stale tabs, worker death before/after commit, lost ack, quota denial, explicit previous recovery as new generation, staged import/restore and unrelated slot protection. Physically remove obsolete candidate/journal bodies only after two-root+pending-restore reachability proof; model state omission is not physical GC proof.

Accelerated500-champ/5000-race/50k-management/100k-candidate-history counters plus128 rival stress is sizing, not full native gameplay. Production must exercise real current validators/reducers/IDB across actual rollovers and representative full native maximum-field/long-schedule games. Label synthetic candidate counters/full-race executions distinctly. Preserve per-record8MiB and backup256MiB; no protected-data deletion shortcut.

Measure separate catalog/schedule/rally/preparation/durable commit/clone/cold verify/export/restore times, main-thread long tasks and sampled memory. Generation outside playback, zero ordinary tick writes. Preferred≤100ms main tasks; quantify residual synchronous commit/UI work rather than weakening validation. Bulk history/backup work in worker; chunk transfer safely. Repeat workloads under controlled load for release; this audit is feasibility evidence.

## Production release gate

Run full accepted Node/browser inventories with raw process exits and legacy-failure dispositions, historical12/payroll/clock references, all new integration/fault tests, double standalone build byte identity/dependency checks and owner Windows Chrome/Edge direct-file tests. No server/network/adjacent assets required. Audit completion is not that acceptance.
''')
stages=[['1','Protected foundation + renewable assets','Implement bounded Option B/current validators/record roots/GC/restore; native identity/factory adapters; fixed tier population and Home batch authority. Prove one complete existing championship→settlement→archive→checkpoint→renewal loop early.','M5-A production authorization;16-catalog candidate/version pins; native mechanic parity','Largest risk is authority transition, not geometry. Stop for failed correctness proof.'],['2','Competition/Regional workflow','Trusted generated definitions, event surface/venue resolution, opportunity epochs, hybrid local fields, narrowly scoped intermission purchases, display identities and compact histories. Supplemental content integrates here.','Stage1 correctness; owner trophy/reset/renewal/Recruiters decisions; authored supplemental profiles','Keep existing UI/lifecycle; no wholesale renderer/controller rewrite.'],['3','Integrated balance and acceptance gate (within delivery2)','Native race/economy/statistical tests, retained-history capacity/GC, UI/standalone regressions, controlled performance and Windows owner acceptance.','Stages1/2 and complete content; same source revision frozen','This is an acceptance gate, not another speculative architecture project.']]
w('BNT_M5_Consolidated_Implementation_Recommendation.md',f'''# BNT M5 — Consolidated Implementation Recommendation

{H}

## Recommendation

Use **two dependent implementation deliveries**, with one integrated acceptance gate, rather than one unreviewable persistence+gameplay rewrite or many backend-only milestones. Content authors can work in parallel. No production implementation is authorized by these audits.

{tab(['Gate','Scope','Deliverables','Dependencies','Risk / completion'],stages)}

### Required seams

- Persistence: new current-state validator/command wrappers, explicit checkpoint version, paged history and record-ref IDB roots; preserve sync domain contracts with awaited coordinator, not async setItem masquerade.
- Generation: reuse16 core factories/name/profile contracts, independent domain seeds/committed epochs; fixed persistent birth and scoped locals; no player adaptation.
- Competition: versioned trusted offer/definition producer; separate competition identity/opportunity/instance from mechanical context; extend exact schedule adapter for surfaces, width and presentation while keeping native setup/clearance/scoring.
- Economy: Home/Regional batch identity and native market.acquire/capacity/contract terms; narrow intermission permission only, no roster swap/treatment loophole. Preserve existing M4 effects and disclose full wage terms.
- Presentation: reuse Events tiles/Details/Registration/Current Championship/Last Event, renderer/map/radio; add region/tier/venue and persistent/local identity projection. Save/load remains existing Options workflow.

## Content production readiness

Begin supplemental authoring now:16 prestige venue concepts, regional venue/environment/naming profiles, event/schedule/tier bindings, hybrid population/local policies and presentation. Actual geometry references and source ranges are verified; no new physics required. Provisional content must not be stamped approved while the material policy fields remain unresolved. Keep candidate v1.0 unchanged; publish additions/amendments under a new version with hashes and cross-reference compiler.

Do not make full procedural circuit generation, travel economy, snow/ice mechanics, variable road width, independent rivals, player scaling, runtime LLMs, replay archives or unique art prerequisites. Proper names/shared placeholders/native courses are enough for a playable M5.

## Material owner dispositions before production

1. Generated competition wins' eligibility for named trophies/victory unlocks; explicit Completion Bonus/award context, with1-event or altered race counts requiring a real approved economic binding.
2. Persistent rival condition between championships: abstract healthy native baseline (recommended) versus retained injury/fatigue, without offscreen medical simulation or invented permanent losses.
3. Exact renewal handling after zero-player-start voluntary withdrawal: retain opportunity batch and/or Home inventory versus renewal only after terminal AI schedule. Full between-champ Home renewal and anti-reroll objectives must be reconciled explicitly.
4. Veteran Recruiters under renewable inventory: its original one extra Premium candidate in a fixed Market must not silently become an unapproved recurring grant or disappear.
5. Authorize bounded M5-A current-state/record format and compact historical fidelity/development-save transition. No unchanged-format deletion, limit increase or silent save migration.

Ordinary schema keys/module boundaries/independent RNG/caches/retry limits/asset reuse need no extra owner votes. Home nation selection is not required: use a neutral existing Home Market mix initially. If making player-selected home nation mechanically bias inventory, obtain an explicit player-facing creation/location contract; do not invent one as a dependency. Geographic national→international schedule weighting is a content proposal, not new travel costs or format unlocks.

## Acceptance stop boundary

Each delivery freezes exact tested source/artifact/evidence and awaits owner review under its future authorization. New physics/economic formulas, unsupported geometry, unsafe compaction, ambiguous once-only effects or inability to recover durable authority require stop/report. No E5/E6-style scope expansion, commit/merge/push/deploy occurs in this investigation.
''')
w('BNT_M5_Competition_Generation_Readiness_Audit.md',f'''# BNT M5 — Competition Generation Readiness Audit

{H}

## Verdict

**READY WITH IDENTIFIED PREREQUISITES** for supplemental content production and a bounded implementation authorization. Production integration remains blocked on M5-A implementation/current validators and explicit trophy/rival-condition/renewal/Recruiters policy dispositions. Existing native racing can support the geometry/format/environment scope; no engine replacement is justified.

M5-A was completed first (`../bnt-m5a-feasibility/evidence/completion.json`), with Option B recommended and prototype limitations carried into this audit. Its six reports/matrix, all eleven prior M5 audit deliverables and the complete256-record/16-catalog content candidate were reviewed. Original eight-nation/ancestry/beast canon remains the authority. Existing candidate source hashes and all accepted M4 source/artifact hashes remain unchanged; no production code, saves, builds or branches modified.

## Baseline

Branch `feat/e5-d-m1-startup-slots-options`; HEAD `27f9ecc086f27a1fb9fe593132308128ecd1249d` plus accepted uncommitted M4 source, manifest tree hash `e2bc429c8f27cea1edeb2d0c9dd0117f21527a16762f4da5394a4697fdc81c75`. HTML3,159,171 bytes/SHA256 `d77e49e40457c5de0255e3c95779941bec67023a4760248a69760f60b7a8d60c`. Current schema6/e5.version2/m4-progression-v1,21 functional Run Rewards/8 Legacy upgrades/3 Active slots. Historical accepted888 tests/Windows result not rerun here.

## Confirmed reusable systems

-3 oval/12 catalog circuits plus4 legacy presets, fixed four-lane course geometry, analytic lane/tile mapping and shared rendering point functions (`track/catalog.js:3–32`, course.js:17–126, oval.js).
-5 surfaces/5 weather presets; native segment patching and generator terrain distributions (`course.js:3–38`, surfaces.js, environment.js:4–44, race.js:96–108).
- Seeded Rally generation, bounded attempts/deterministic fallback, full resolved setup/recipe; explicit category SignPoint wrapper (`rally-generator.js`, prototype/session.js:9–11).
- Existing qualification, manual start, frozen lineup, D5 publication, D2, scoring/title/withdrawal/AI continuation/zero-starter, settlement and M4 progression. Reuse rules/reducers through explicit new bindings, not a second competition controller.
- Current Events/Details/Registration/Current/Last Event components; race/map/radio; shared art fallbacks. Extend data projection, not replace renderer/framework.

## Main integration blockers and limitations

1. **Static authority:** e5.register resolves catalogDefinition(templateId) and exact static board; arbitrary generated definitions cannot enter safely without a trusted versioned producer (`e5/schema6.js:27–33`).
2. **Event adapter:** freezeOffer schedule accepts only course/format/weather/laps/grid, so Oval surface override/custom width/location fields cannot simply be appended (`offers.js:11–20`). Native createRace supports patches; production controller bridge is missing.
3. **Reward identity:** trophy/victory/terms and M4 BONUS_TIERS depend on static template IDs, with fallback1 for unknown IDs. Separate generated identity from mechanics and approved trophy context. Do not reward tier5 as tier1 or grant signature unlocks accidentally.
4. **Rivals:** native fixed snapshots are championship-local with unnamed members and ordinal strength, not lazy recurring tier populations. Existing M5 recipes support birth inputs; lifecycle/identity storage required.
5. **Regional Market:** current policy blocks all active-run management. Approved intermission purchase exception must preserve frozen RU, native capacity/wages/financial anchors and no elimination rescue (`cycles/policy.js:8–9`).
6. **Persistence:** current full genesis replay/session retention cannot sustain target horizon. M5-A proposal requires production work, including physically safe GC and distinct prior-root retention not proven by sizing alone. No silent old save pruning.
7. **Missing policy:** generated trophy credit, rival between-run recovery, zero-start withdrawal renewal and Veteran Recruiters renewal frequency remain material decisions. Full and shorter generated schedules need explicitly approved economic bindings.

## Native geometry/environment findings

19 fixed preset entries and90 fresh generated Rally samples were probed;44 diagnostic groups pass. All current15 catalog tracks accept8 default starters and corridor validation. Native64 race ceiling differs from championship8 ceiling. Course lanes fixed4; Oval supports global1..8 but first M5 can stay4. Base generator emits3 checkpoints; category wrapper emits1/2/3; don’t reinterpret old tracks. Open Rally ignores lap multipliers (including current Iron Gauntlet laps2 disclosure); new profiles should declare one open traversal. Surfaces influence grip/rolling/fatigue and incident placement, not new weather physics or incident frequency. Full details/lengths/capacity tests in Track and Venue Contracts/CSV.

## Native lifecycle and policy findings

Five existing standard contexts align supplied difficulty files; Iron Gauntlet qualification is trophy-bannerfall and can reference top fixed strength context without new ladder. There is no separate native Combat/Circuit/Rally unlock. Shared ties use native finishTolerance/fullprecision, DNF ordering uses first-reached progress. Native disqualification action is not implemented merely because downstream filters mention DQ. Withdrawn/eliminated players leave AI schedule running; completing an event is not championship settlement.

## UI readiness map

{tab(['Surface','Existing seam','Missing integration data / bounded work'],[['Events/qualification','management/career-race/flow.js:27–31','OpportunityId/epoch, proper competition names, tier/nation/region, eligibility; preserve read-only selection and confirmation.'],['Details/schedule','same flow;trackLabel and awardDisclosure','Venue vsgeometry label, surfaces/weather/point-to-point distance, previews and frozen reward context; avoid generic preset as venue identity.'],['Race/map/commentary','presentation/renderer.js:1–28;full-screen model;career-race/host.js','Frozen team/local/persistent name map and venue labels; native reporter untouched; graphics never affect RNG.'],['Current/Last Event/archive','headquarters/model.js:11–13;consolidated.js:21','Current Rival RU/number fallbacks replaced by persisted proper org/member names; exact historical labels after compaction.'],['Market/services','player-pages.js;HQ context-actions;cycles/policy','Regional batch source/location/expiry/count, reserve-only acquisitions and native terms; no generic staff/search UI.'],['Trophies/rewards','M4 management +E5 archive','Explicit generated-vs-signature trophy credit; Completion Bonus context; existing Run/Legacy mechanics unchanged.']])}

## Performance / capacity evidence

Measured fresh Rally median0.64/1.56/4.16ms short/medium/long; long max20.29ms in90-seed sample. Resolved course3151–8945 bytes. Schedule-generation/offer/rival factory throughput is not measured because no production generator exists.3 opportunities×12 worst observed Rally generation samples implies~0.73s serial worker work as an **estimate**, not a UI target result. Cache static prestige courses; generation management-only.

M5-A synthetic set~11.7MB across437 records,228KB checkpoint; extra compact competition context~0.8–3MB estimate. Full historical courses would add34–45MB for5000 Long Rallies and are not required for compact history. Keep complete active setup/proofs; verify true native maximum aggregates before acceptance. Largest104ms browser task/worker memory concerns remain; no per-tick writes or bound increases.

## Final decision summary —18 required answers

1. **Yes:** existing template catalog supports renewable venue configuration/identity; no procedural circuit synthesis needed.
2. **Yes:** five native surfaces and weather profiles produce supported regional variation; explicit event bridge needed for oval patches.
3. **Yes:**16 prestige concepts can share geometry with fixed config and reusable art; no new mechanics required.
4. **Yes:** current Rally generator supports both; fixed prestige needs version/ordered recipe/resolved geometry, not seed alone.
5. **Yes, with adapter:** native race setup reusable; frozen controller event shape must be versioned for new metadata/config.
6. **Yes, with trusted definition/context binding:** retain qualification/registration/settlement formulas; static-ID assumptions need explicit integration.
7. Add committed opportunity epochs/batches/expiration/source revisions and idempotent renewal; preserve permanent signatures and no page/reload rerolls.
8. **Yes:** lazily birth fixed tier populations, no independent economics/training/player adaptation.
9. **Yes after new checkpoint authority:** locals freeze during championship, proper names/result refs survive compact history; current schema6 cannot simply delete them.
10. **Yes:** next venue location can scope limited intermission inventory; native active-management restriction needs narrow exception, not roster substitution.
11. **No material new backend direction:** Option B still fits; add validators/epochs/identities and measured historical metadata/GC tests.
12. Reuse16 core catalogs; amend/version rival birth/lifecycle, difficulty/valuation, regional policy and name/presentation bindings; do not alter v1.0 bytes silently.
13. Author geometry/environment/naming/venue/event/tier/championship/hybrid-rival/local/presentation/renewal catalogs (11 consolidated schema families).
14. Defer procedural circuits,new weather/physics/travel systems,offscreen rivals/adaptation,unique art and permanent replay telemetry.
15. Two dependent deliveries: protected persistence+asset/fixed-rival/Home foundation, then competitions/Regional workflow and integrated balance/standalone acceptance; content in parallel.
16. Owner dispositions: generated trophy/unlock credit/economic binding, rival between-run recovery, zero-start renewal, Veteran Recruiters semantics and concrete M5-A production format/transition authorization.
17. **No blocker to supplemental draft content production:** actual native contracts available; unresolved policy values must remain draft, not invented canon.
18. **Production has specific blockers:** M5-A current validators/record roots/GC/restore, trusted definition/event/market adapters and approved policies+balance. Catalog delivery alone is insufficient.

## Tests and scope

94 existing Node tests pass,44 diagnostic groups and172 schema/reference checks pass, all process exit0.13 requested files and raw evidence supplied individually. Complete test list/limits in Validation and Regression Plan. Accepted source/artifacts/content hashes preserved. No production implementation, images, migrations, builds, commits, merges, pushes or deployment occurred.
''')
