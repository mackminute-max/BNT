from pathlib import Path
import json,hashlib,copy
from jsonschema import Draft202012Validator
O=Path(__file__).resolve().parents[1];C=Path('/workspace/deliverables/bnt-m5-content-v1');checks=[]
def check(n,c):
 if not c:raise AssertionError(n)
 checks.append(n)
def load(p):return json.loads(p.read_text())
s=load(O/'BNT_M5_Proposed_Competition_Content_Schemas.json');a=load(O/'BNT_M5_Illustrative_Competition_Profiles.json');Draft202012Validator.check_schema(s);v=Draft202012Validator(s);v.validate(a);check('Schema syntax/example shapes',True)
IDX={q['id']:(f,q)for f,qs in a['records'].items()for q in qs};old={q['id']:(p.stem,q)for p in(C/'catalogs').glob('*.json')for q in load(p)};native=load(O/'evidence/native-inventory.json');context={r['id']:r for r in native['championships']}
check('Example IDs unique',len(IDX)==sum(map(len,a['records'].values())))
for f,qs in a['records'].items():
 for q in qs:
  check('Unapproved '+q['id'],q['approval']=='UNAPPROVED_EXAMPLE')
  for r in q['sources']:
   p=O/r['file'];check('Source bytes '+q['id'],hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'])
REFS={'venue':{'environmentId':'environment','namingProfileId':'naming','presentationId':'presentation'},'event':{'namingProfileId':'naming'},'championship':{'namingProfileId':'naming','tierBindingId':'tier','rivalPopulationPolicyId':'rivals','renewalPolicyId':'renewal','presentationId':'presentation'},'rivals':{'localProfileId':'locals'}}
WEIGHT={'venue':{'geometryWeights':'geometry'},'event':{'venueWeights':'venue'},'championship':{'eventWeights':'event'}}
for f,qs in a['records'].items():
 for q in qs:
  for k,target in REFS.get(f,{}).items():check('Typed ref '+q['id']+k,q[k]in IDX and IDX[q[k]][0]==target)
  for k,target in WEIGHT.get(f,{}).items():
   for z in q[k]:check('Typed weight '+q['id']+z['id'],z['id']in IDX and IDX[z['id']][0]==target)
  if f=='naming':check('Existing culture '+q['id'],q['culturalNamingProfileId']in old and old[q['culturalNamingProfileId']][0]=='culturalNaming')
  if f=='venue':
   check('Region belongs to nation '+q['id'],q['regionId']in old and q['nationId']in old[q['regionId']][1]['canonicalNationIds'])
   check('Prestige identity/seed semantics '+q['id'],q['permanence']!='prestige'or(q['properName']and q['seedPolicy']=='pinned'and q['pinnedSeed']is not None))
  if f=='geometry':check('Rally resolver/category consistent '+q['id'],(q['resolver']=='rally-generator-v1')==(q['rallyOptions']is not None))
  if f in ['rivals','locals']:
   for key in ['birthProfileWeights','existingRivalProfileWeights']:
    for z in q.get(key,[]):check('Existing rival recipe '+q['id']+z['id'],z['id']in old and old[z['id']][0]=='rivalGeneration')
  if f=='presentation':check('Existing visual '+q['id'],q['worldVisualProfileId']in old)
  if f=='tier':
   n=context[q['nativeCatalogId']]['offer']['value'];check('Native mechanics binding '+q['id'],q['fieldSize']==n['fieldSize']and q['raceCount']==len(n['schedule']) and q['qualificationBinding']=='native.'+q['nativeCatalogId'])
  if f=='event':
   for vw in q['venueWeights']:
    venue=IDX[vw['id']][1];check('Event format supported '+q['id']+venue['id'],q['format']in venue['supportedFormats'])
    for g in venue['geometryWeights']:
     geo=IDX[g['id']][1];check('Event distance topology '+q['id']+geo['id'],(geo['kind']=='Rally')==(q['distanceMode']=='point-to-point'))
   check('Rally1 lap '+q['id'],q['distanceMode']!='point-to-point'or q['laps']=={'min':1,'max':1})
# Invalid payloads must reject structurally; semantic constraints described separately.
for label,change in [('unknown weather',lambda x:x['records']['environment'][0]['weatherWeights'][0].update(weather='Snow')),('field9',lambda x:x['records']['tier'][0].update(fieldSize=9)),('extra-economic-override',lambda x:x['records']['event'][0].update(prizeGold=1000)),('unseeded-rng',lambda x:x['records']['venue'][0].update(seedPolicy='time-now')),('adaptive-rivals',lambda x:x['records']['rivals'][0].update(fixedAttributesAndPersonality=False)),('generic-name-fallback',lambda x:x['records']['naming'][0].update(genericFallback=True))]:
 x=copy.deepcopy(a);change(x);check('Reject '+label,not v.is_valid(x))
# Existing candidate unchanged versus its delivered version manifest.
manifest=load(C/'CATALOG_VERSION_MANIFEST.json')
for f in manifest['files']:check('Existing candidate bytes '+f['file'],hashlib.sha256((C/f['file']).read_bytes()).hexdigest()==f['sha256'])
productionIssues=['Every illustrative record unapproved','Generated trophy/victory credit disposition unresolved','Rival between-championship condition disposition unresolved','Zero-start withdrawal renewal disposition unresolved','Native adapters/M5-A production authority not implemented']
res={'exit':0,'passed':len(checks),'failed':0,'families':len(a['records']),'exampleRecords':len(IDX),'checks':checks,'productionReady':False,'productionBlockers':productionIssues}
(O/'evidence/schema-validation-results.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items()if k!='checks'},indent=2))
