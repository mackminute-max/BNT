# Blood and Thunder — M7 audit return

Date: 2026-11-25 (America/Los_Angeles). Audited commit: `0c29a65a7cf8bdf0ced1821eb59da314981507f6`.

**Audit complete. M7 production remains unauthorized.** No production source, assets, catalogs, manifests, save schemas or build configuration was changed; all965protected-file hashes and the initial Git status match.

## Findings requiring owner review

- **Verified M6defect:**5isolated Traditional-career driver purchases rejected `Invalid driver visual identity`, leaving purchase state/Gold/personnel unchanged. Consumed-offer visual metadata survives deletion of its identity; a separate correction and offer→owned sex-continuity proof are needed. No fix is included.
- Current proof-only64entry/eager loader cannot host the proposed M7catalog. New versioned presentation plumbing is proposed, not implemented.
- Final Bible/Design Library originals,3logos, fonts/licenses and exact UI export/slice metadata are not supplied. Body font, viewport/internal feeds and selected/critical contrast need owner/design decisions.

## Proposed quantities

Minimum395image files+2fonts=397logical files; target866+4=870. Minimum49templates/target53, including one technical mask (48/52pictorial templates). Reuse21approved UI state exports+3logo originals rather than drawing substitutes. Shared Owner/Driver portraits prevent double counting. All quantities are recommendations, not approved production requirements. Existing8prooffiles/3builtin entries remain separate legacy fallbacks.

## Templates to produce first, after authorization

First deliver the already approved UI/logo/font originals. Then T-character-A01, T-beast-B01, T-ru-B01 and aligned T-mask, T-emblem+T-mark, T-background+T-stable can prove the Market/Barn/one-race vertical slice. Complete13ancestry portrait,9species portrait and9species RU templates plus remaining generic families to claim full minimum-catalog support. No artwork was generated in this audit.

## Evidence and next step

44presentation/asset tests passed, exit0. Existing8image hashes/master files validated. Proposed filename map has870unique target paths,397minimum-scope paths. Existing M6full-regression results were not rerun and do not substitute for new M7acceptance. No browser/Windows test or new build is claimed.

Review the7required deliverables, confirm the M6baseline/corrective scope, then supply final production sources and authorize a bounded M7vertical slice. Stop here; no implementation is implied by this return.
