# Blood and Thunder — Visual Asset Reference (M7 audit refresh)

Audit date: **2026-11-25** (America/Los_Angeles). Audited commit: `0c29a65a7cf8bdf0ced1821eb59da314981507f6`; branch `feat/e5-d-m1-startup-slots-options`.

**OBSERVED** means verified source or a named audit probe. **PROPOSED M7 / REQUIRES CHANGE** is a recommendation, never an installed feature or approved quantity. **DEFER** is outside the initial visual scope. **UNKNOWN** is not silently estimated as a fact. All proposed tables are documentation, not runtime inputs.

## 1. What exists, and what is proposed

The existing system is Canvas2D race drawing plus HTML/CSS management, not a general-purpose identity-aware production art catalog. Preserve it as the rendering base. “Replace placeholder” often means adding a resolver/consumer first: eight proof image files do not cover Owner, roster, World, reward or Den art. The supplied interim Bible is direction; final library originals are missing locally.

Observed asset set:11manifest entries (3builtins,3PNG,5SVG),8file-backed images, 28,640 raw bytes, 38,396 data-URL characters and 1,649,920 declared decoded RGBA bytes for one library. `assets/presentation.manifest.json:1`. Source masters3SVG and an internal proof license ledger exist. No approved Logo_TitlePage/Framed/Clean originals, Bangers/IM Fell font files, state SVGs, studies or master-button-settings.json were found in repository/library-files or attached ZIP. Do not recreate approved artwork from text.

| Existing ID | File | Actual runtime dimensions | Consumer/status |
|---|---|---|---|
| ru.proof.static.v1 | assets/runtime/proof/ru.png | 128x64 | Embedded proof / not final artwork |
| ru.proof.livery.v1 | assets/runtime/proof/ru-livery.png | 128x64 | Embedded proof / not final artwork |
| portrait.driver.proof.v1 | assets/runtime/proof/portrait.png | 256x256 | Embedded proof / not final artwork |
| team.proof.emblem.v1 | assets/runtime/proof/emblem.svg | 256x256 | Embedded proof / not final artwork |
| team.proof.mark.v1 | assets/runtime/proof/mark.svg | 24x24 | Generic hard-coded proof binding; mark has no direct consumer found |
| ui.proof.corner.v1 | assets/runtime/proof/corner.svg | 48x48 | Embedded proof / not final artwork |
| architecture.tower.proof.v1 | assets/runtime/proof/tower.svg | 512x256 | Embedded proof / not final artwork |
| architecture.arch.proof.v1 | assets/runtime/proof/arch.svg | 512x256 | Embedded proof / not final artwork |
## 2. Renderer and binding contract

`src/presentation/renderer.js:13`: true top-down Canvas. Draw order is background/static road tiles → decorative tower/arch → start/finish/checkpoints → direction arrows → hazards → sorted RUs/player highlight/wreck overlay → event-effect rings/labels. Full-course map caches road separately and draws procedural markers; it must not decode portrait sprites per entrant. Main camera follows player with visual look-ahead/lag, predictable lexical entrant fallback; north/up fixed, RU rotates to tangent. `src/presentation/geometry.js:19`.

Canvas nominal logical width1000 (durable legacy760; map640), height derived from actual CSS content aspect, DPR capped2 even on deviceDPR3. The old1000×550/640×400 labels are nominal, not forced responsive CSS rectangles. Pointer transforms account for CSS box and backing pixels. `src/presentation/canvas.js:9`. Default lane width4 and zoom8 produce a full RU image footprint≈59.7×29.9CSSpx; alpha-body height22.4px. Current zoom range4–10; tactical markers radius5.5CSSpx. These are measured from native setup/math, not proposed sprite screen dimensions.

Current RU uses one128×64 PNG+mask for all two-beast teams, +X facing, axle(40,32), visual bounds(16,8,96,48), driver(32,32), wheels(32,16)/(32,48), beasts(76,18)/(76,46). At body<8CSSpx or non-two-beast composition it falls back to markers. Static art does not implement frame playback or modular composition despite manifest frame/anchor metadata. Collision geometry is never derived from alpha bounds. `src/presentation/assets.js:11`; `src/presentation/renderer.js:25`.

**PROPOSED M7:** retain complete RU sprites+aligned livery. Recommend256×128 exports for proposed catalog (2x reference anchors80,64 etc.) to support DPR2/upper zoom; current128×64 is adequate around default zoom and remains a valid legacy fallback. Freeze after a pixel/rotation proof; do not rescale world collision footprints. New renderer/composite metadata is required because current code hard-codes128×64 and one base/mask ID. No mandatory eight-direction sheet, gait loop or modular rig.

Den is a separate900×400 Canvas overview with colored points and no image library, `src/management/m6-den.js:9`. It can reuse presentation helpers later but never receives player Sign/ability controls. Its spectator team choice/speed dropdowns also need M7 direct-choice replacements.

## 3. Verified limits and required production changes

- Manifest-v1:≤64entries, version1, only `builtin/png/svg`, status exactly `temporary-proof`; production/approved status and fonts reject. IDs follow lowercase dotted/hyphenated `*.vN`; paths are relative, hashes/license/frames/anchors required. Do not label finished art `temporary-proof` just to bypass validation.
- PNG:8-bit RGBA, noninterlaced, ≤2048 per side, CRC and exact inflated size. Opaque illustrations still need RGBA with alpha255. Source-path validation assumes SVG masters; PSD/KRA/other raster masters need a separate reviewed ledger/intake, not a fake SVG path.
- SVG:≤256KiB,2048nodes,32768path commands; explicit namespace/width/height/viewBox; local IDs/acyclic references only. Scripts, foreignObject, filters, SMIL, image/text/style nodes, event attributes, CSS variables/currentColor paints, external resources, XML declarations and entities reject. `<defs>/<use>` and explicit local gradients are supported. Export exact hex paints; UI live labels remain HTML. Check approved library SVG exports rather than bypassing this validator.
- AssetLibrary immediately preloads every image. Image LRU24entries/8MiB; composite16/4MiB. `get()` does not reload an evicted image. A large new catalog can churn at startup and leave useful art unavailable even before hitting memory bounds. Lazy loading, payload-sharing, pinning visible requirements and explicit reload are required.
- Renderer tiles32entries/28MiB; map2/4MiB; shared geometry4/4MiB. Nominal total48MiB for one presenter/library, not a process peak or a cross-iframe cap. DOM images/browser font/GPU allocations add memory. No silent limit increases.

Sources: `src/presentation/contracts.js:3`, `scripts/p2/assets.mjs:4`, `scripts/p2/svg.mjs:13`, `src/presentation/assets.js:4`, `src/presentation/renderer.js:14`.

## 4. Complete old33-category crosswalk and production classes

### A01 — Complete racing-unit sprite

**OBSERVED prior classification:** EXISTING FILE — replacement contract. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 9 minimum / 27 target additional files; aliases/procedural entries deliberately count0.

- `B01`: png 256×128; source/master 1024x512 raster or reusable512x256 SVG master; alpha True; anchor 80,64; +X; reference40,32 in128x64. src/presentation/renderer.js:25. Path `assets/runtime/m7/race/B01/ru_B01_{slot:03d}.png`. Fallback: Existing generic marker for absent/unsupported composition. Three target cosmetic chassis/livery compositions per species; no driver×chariot×breed sprite explosion. M7 2x export is proposed, not existing.
- `B02`: png 256×128; source/master 1024x512 raster or reusable512x256 SVG master; alpha True; anchor 80,64; +X; reference40,32 in128x64. src/presentation/renderer.js:25. Path `assets/runtime/m7/race/B02/ru_B02_{slot:03d}.png`. Fallback: Existing generic marker for absent/unsupported composition. Three target cosmetic chassis/livery compositions per species; no driver×chariot×breed sprite explosion. M7 2x export is proposed, not existing.
- `B03`: png 256×128; source/master 1024x512 raster or reusable512x256 SVG master; alpha True; anchor 80,64; +X; reference40,32 in128x64. src/presentation/renderer.js:25. Path `assets/runtime/m7/race/B03/ru_B03_{slot:03d}.png`. Fallback: Existing generic marker for absent/unsupported composition. Three target cosmetic chassis/livery compositions per species; no driver×chariot×breed sprite explosion. M7 2x export is proposed, not existing.
- Full 9strata, exact native tags and sizes are in `M7_ASSET_CATALOG_PLAN.csv`; ancestry/stock matrices in `M7_POOL_SIZING.md`.

### A02 — Racing-unit primary livery mask

**OBSERVED prior classification:** EXISTING FILE — paired technical derivative. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 9 minimum / 27 target additional files; aliases/procedural entries deliberately count0.

- `B01`: png 256×128; source/master 1024x512 raster or reusable512x256 SVG master; alpha True; anchor 80,64; +X; reference40,32 in128x64. src/presentation/renderer.js:25. Path `assets/runtime/m7/race/B01/livery_B01_{slot:03d}.png`. Fallback: Existing generic marker for absent/unsupported composition. Three target cosmetic chassis/livery compositions per species; no driver×chariot×breed sprite explosion. M7 2x export is proposed, not existing.
- `B02`: png 256×128; source/master 1024x512 raster or reusable512x256 SVG master; alpha True; anchor 80,64; +X; reference40,32 in128x64. src/presentation/renderer.js:25. Path `assets/runtime/m7/race/B02/livery_B02_{slot:03d}.png`. Fallback: Existing generic marker for absent/unsupported composition. Three target cosmetic chassis/livery compositions per species; no driver×chariot×breed sprite explosion. M7 2x export is proposed, not existing.
- `B03`: png 256×128; source/master 1024x512 raster or reusable512x256 SVG master; alpha True; anchor 80,64; +X; reference40,32 in128x64. src/presentation/renderer.js:25. Path `assets/runtime/m7/race/B03/livery_B03_{slot:03d}.png`. Fallback: Existing generic marker for absent/unsupported composition. Three target cosmetic chassis/livery compositions per species; no driver×chariot×breed sprite explosion. M7 2x export is proposed, not existing.
- Full 9strata, exact native tags and sizes are in `M7_ASSET_CATALOG_PLAN.csv`; ancestry/stock matrices in `M7_POOL_SIZING.md`.

### A03 — Driver portraits

**OBSERVED prior classification:** EXISTING FILE + monogram replacements needing identity mapping. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 117 minimum / 338 target additional files; aliases/procedural entries deliberately count0.

- `A01/male`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m6/schema.js:28. Path `assets/runtime/m7/portraits/A01/male/portrait_A01_male_{slot:03d}.png`. Fallback: Same-ancestry neutral; then non-anatomical unknown medallion. 4 known-sex choices/group limit immediate repetition; 12 target provides variety. Neutral is a fallback category, not a new Owner sex.
- `A01/female`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m6/schema.js:28. Path `assets/runtime/m7/portraits/A01/female/portrait_A01_female_{slot:03d}.png`. Fallback: Same-ancestry neutral; then non-anatomical unknown medallion. 4 known-sex choices/group limit immediate repetition; 12 target provides variety. Neutral is a fallback category, not a new Owner sex.
- `A01/unspecified`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m6/schema.js:28. Path `assets/runtime/m7/portraits/A01/unspecified/portrait_A01_unspecified_{slot:03d}.png`. Fallback: Same-ancestry neutral; then non-anatomical unknown medallion. 4 known-sex choices/group limit immediate repetition; 12 target provides variety. Neutral is a fallback category, not a new Owner sex.
- Full 39strata, exact native tags and sizes are in `M7_ASSET_CATALOG_PLAN.csv`; ancestry/stock matrices in `M7_POOL_SIZING.md`.

### A04 — Full stable/team emblem

**OBSERVED prior classification:** EXISTING FILE — generic race emblem. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 32 minimum / 64 target additional files; aliases/procedural entries deliberately count0.

- `N1`: svg 256×256; source/master SVG viewBox 0 0 256 256; alpha True; anchor 128,128. src/management/m6-world.js:7. Path `assets/runtime/m7/emblems/N1/emblem_N1_{slot:03d}.svg`. Fallback: Inline emblem/number or labeled schematic placeholder. Four persistent rivals/nation; target8 emblem alternatives/nation. World maps must not invent borders. Full emblem and reduced mark counted separately.
- `N2`: svg 256×256; source/master SVG viewBox 0 0 256 256; alpha True; anchor 128,128. src/management/m6-world.js:7. Path `assets/runtime/m7/emblems/N2/emblem_N2_{slot:03d}.svg`. Fallback: Inline emblem/number or labeled schematic placeholder. Four persistent rivals/nation; target8 emblem alternatives/nation. World maps must not invent borders. Full emblem and reduced mark counted separately.
- `N3`: svg 256×256; source/master SVG viewBox 0 0 256 256; alpha True; anchor 128,128. src/management/m6-world.js:7. Path `assets/runtime/m7/emblems/N3/emblem_N3_{slot:03d}.svg`. Fallback: Inline emblem/number or labeled schematic placeholder. Four persistent rivals/nation; target8 emblem alternatives/nation. World maps must not invent borders. Full emblem and reduced mark counted separately.
- Full 8strata, exact native tags and sizes are in `M7_ASSET_CATALOG_PLAN.csv`; ancestry/stock matrices in `M7_POOL_SIZING.md`.

### A05 — Tiny emblem / reduced identity mark

**OBSERVED prior classification:** EXISTING FILE — embedded; no direct consumer found. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 32 minimum / 64 target additional files; aliases/procedural entries deliberately count0.

- `N1`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/management/m6-world.js:7. Path `assets/runtime/m7/emblems/N1/mark_N1_{slot:03d}.svg`. Fallback: Inline emblem/number or labeled schematic placeholder. Four persistent rivals/nation; target8 emblem alternatives/nation. World maps must not invent borders. Full emblem and reduced mark counted separately.
- `N2`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/management/m6-world.js:7. Path `assets/runtime/m7/emblems/N2/mark_N2_{slot:03d}.svg`. Fallback: Inline emblem/number or labeled schematic placeholder. Four persistent rivals/nation; target8 emblem alternatives/nation. World maps must not invent borders. Full emblem and reduced mark counted separately.
- `N3`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/management/m6-world.js:7. Path `assets/runtime/m7/emblems/N3/mark_N3_{slot:03d}.svg`. Fallback: Inline emblem/number or labeled schematic placeholder. Four persistent rivals/nation; target8 emblem alternatives/nation. World maps must not invent borders. Full emblem and reduced mark counted separately.
- Full 8strata, exact native tags and sizes are in `M7_ASSET_CATALOG_PLAN.csv`; ancestry/stock matrices in `M7_POOL_SIZING.md`.

### A06 — Reusable Deco panel corner

**OBSERVED prior classification:** EXISTING FILE — replacement contract. **Current disposition:** OBSERVED_REUSE. PROPOSED counts 0 minimum / 0 target additional files; aliases/procedural entries deliberately count0.

- `existing proof corner`: existing-svg 48×48; source/master SVG48x48; alpha True; anchor 24,24. src/presentation/bootstrap.js:42. Path `assets/runtime/proof/corner.svg`. Fallback: Omit decoration. No additional M7 file; approved new component frames own their corners.

### A07 — Trackside tower / architectural cluster

**OBSERVED prior classification:** EXISTING FILE — replace elevation-like proof with top-down art. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 1 minimum / 4 target additional files; aliases/procedural entries deliberately count0.

- `tower`: svg 512×256; source/master SVG512x256; alpha True; anchor 256,128; 16x8 world box. src/presentation/renderer.js:18. Path `assets/runtime/m7/scenery/tower_{slot:03d}.svg`. Fallback: Omit decoration; retain road visibility. Two base modules minimum; four variants each target. Top-down only, never collision geometry.

### A08 — Trackside arch / gateway module

**OBSERVED prior classification:** EXISTING FILE — replacement contract. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 1 minimum / 4 target additional files; aliases/procedural entries deliberately count0.

- `arch`: svg 512×256; source/master SVG512x256; alpha True; anchor 256,128; 16x8 world box. src/presentation/renderer.js:18. Path `assets/runtime/m7/scenery/arch_{slot:03d}.svg`. Fallback: Omit decoration; retain road visibility. Two base modules minimum; four variants each target. Top-down only, never collision geometry.

### A09 — Home Stable illustration

**OBSERVED prior classification:** INLINE TEMPORARY IMAGE — new external source reference needed. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 1 minimum / 8 target additional files; aliases/procedural entries deliberately count0.

- `shared stable`: png 800×300; source/master 1600x600 layered; alpha False; anchor 400,150; center cover. src/management/headquarters/consolidated.js:12. Path `assets/runtime/m7/stable/stable_{slot:03d}.png`. Fallback: Current labeled inline stable illustration. One shared scene minimum; eight nation-inspired alternatives target, aesthetic only.

### A10 — Owner portrait

**OBSERVED prior classification:** INLINE TEMPORARY IMAGE — replaceable dashboard reference. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 0 minimum / 0 target additional files; aliases/procedural entries deliberately count0.

- `reuse only`: reuse ×; source/master TBD; alpha ; anchor . src/management/headquarters/consolidated.js:13. Path `Existing A03/B01/B02 pool paths`. Fallback: Monogram with readable names. Zero additional files is an intentional alias count, not an unknown count.

### B01 — Beast portraits

**OBSERVED prior classification:** MONOGRAM PLACEHOLDER — UI image mapping required. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 39 minimum / 117 target additional files; aliases/procedural entries deliberately count0.

- `stock.b01.1-1`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m5/generation.js:30. Path `assets/runtime/m7/beasts/B01/stock.b01.1-1/beast_stock.b01.1-1_{slot:03d}.png`. Fallback: Same-species anatomy-neutral silhouette; never substitute another species. 39 real stock profiles; one minimum/three target per stock, without sex or nation Cartesian products. Stock-specific details optional until canon verified.
- `stock.b01.1-2`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m5/generation.js:30. Path `assets/runtime/m7/beasts/B01/stock.b01.1-2/beast_stock.b01.1-2_{slot:03d}.png`. Fallback: Same-species anatomy-neutral silhouette; never substitute another species. 39 real stock profiles; one minimum/three target per stock, without sex or nation Cartesian products. Stock-specific details optional until canon verified.
- `stock.b01.1-3`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m5/generation.js:30. Path `assets/runtime/m7/beasts/B01/stock.b01.1-3/beast_stock.b01.1-3_{slot:03d}.png`. Fallback: Same-species anatomy-neutral silhouette; never substitute another species. 39 real stock profiles; one minimum/three target per stock, without sex or nation Cartesian products. Stock-specific details optional until canon verified.
- Full 39strata, exact native tags and sizes are in `M7_ASSET_CATALOG_PLAN.csv`; ancestry/stock matrices in `M7_POOL_SIZING.md`.

### B02 — Chariot inspection / roster illustrations

**OBSERVED prior classification:** LETTER PLACEHOLDER — UI image slot required. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 3 minimum / 12 target additional files; aliases/procedural entries deliberately count0.

- `generic chariot styling`: png 512×256; source/master 1024x512 layered; alpha True; anchor 256,128. src/career/economy/market.js:16. Path `assets/runtime/m7/chariots/chariot_{slot:03d}.png`. Fallback: Text/letter placeholder. Three minimum visual alternatives/12target; do not treat naming profiles or tiers as new chariot classes.

### B03 — Staff / specialist portraits

**OBSERVED prior classification:** LETTER PLACEHOLDER — UI image mapping required. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 12 minimum / 24 target additional files; aliases/procedural entries deliberately count0.

- `Beast Handler`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m5/generation.js:35. Path `assets/runtime/m7/staff/beast-handler/staff_beast-handler_{slot:03d}.png`. Fallback: Neutral occupational symbol, not an inferred human. No native specialist ancestry/sex generation; do not fabricate 13x2x24 portrait requirements.
- `Mechanic`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m5/generation.js:35. Path `assets/runtime/m7/staff/mechanic/staff_mechanic_{slot:03d}.png`. Fallback: Neutral occupational symbol, not an inferred human. No native specialist ancestry/sex generation; do not fabricate 13x2x24 portrait requirements.
- `Physician`: png 256×256; source/master 512x512 layered/vector; alpha True; anchor 128,128. src/career/m5/generation.js:35. Path `assets/runtime/m7/staff/physician/staff_physician_{slot:03d}.png`. Fallback: Neutral occupational symbol, not an inferred human. No native specialist ancestry/sex generation; do not fabricate 13x2x24 portrait requirements.

### B04 — Equipment / inventory item images

**OBSERVED prior classification:** LETTER PLACEHOLDER — item image connection required. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 6 minimum / 12 target additional files; aliases/procedural entries deliberately count0.

- `generic equipment`: png 256×256; source/master 512x512 layered; alpha True; anchor 128,128. src/career/economy/catalog.js:3. Path `assets/runtime/m7/equipment/equipment_{slot:03d}.png`. Fallback: Generic hardware medallion plus exact name. Native equipment templates expose mass/combat, not a reliable harness/wheel/class enum. Avoid inference from names.

### B05 — Barn driver/beast/chariot slot illustrations

**OBSERVED prior classification:** GEOMETRIC SYMBOL PLACEHOLDERS — reuse B/A artwork first. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 0 minimum / 0 target additional files; aliases/procedural entries deliberately count0.

- `reuse only`: reuse ×; source/master TBD; alpha ; anchor . src/management/headquarters/consolidated.js:16. Path `Existing A03/B01/B02 pool paths`. Fallback: Monogram with readable names. Zero additional files is an intentional alias count, not an unknown count.

### B06 — Active Legacy perk icons and empty slot

**OBSERVED prior classification:** UNICODE PLACEHOLDERS — icon renderer needed. **Current disposition:** OBSERVED_REUSE. PROPOSED counts 0 minimum / 0 target additional files; aliases/procedural entries deliberately count0.

- `retain procedural`: canvas/css ×; source/master TBD; alpha True; anchor Existing geometry. src/management/m4.js:6. Path `No external file`. Fallback: Live labels and Canvas/CSS. Zero physical files by design.

### C01 — Strategy Sign icons

**OBSERVED prior classification:** TEXT CONTROLS — optional artwork, not missing image files. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 6 minimum / 6 target additional files; aliases/procedural entries deliberately count0.

- `Push the Pace,Conserve Strength,Seek Open Track,Race Defensively,Engage Rivals,Hold Position`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/ai/signs.js:4. Path `assets/runtime/m7/icons/sign/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.

### C02 — Tactical-map entrant symbols

**OBSERVED prior classification:** PROCEDURAL FUNCTIONAL SYMBOLS — keep procedural by default. **Current disposition:** OBSERVED_REUSE. PROPOSED counts 0 minimum / 0 target additional files; aliases/procedural entries deliberately count0.

- `retain procedural`: canvas/css ×; source/master TBD; alpha True; anchor Existing geometry. src/presentation/renderer.js:11. Path `No external file`. Fallback: Live labels and Canvas/CSS. Zero physical files by design.

### C03 — Wreck / disabled RU overlay

**OBSERVED prior classification:** PROCEDURAL OVERLAY — artwork hook required. **Current disposition:** PROPOSED_TARGET_OPTIONAL. PROPOSED counts 0 minimum / 1 target additional files; aliases/procedural entries deliberately count0.

- `wreck-overlay`: png 256×128; source/master 3840x2160 for backgrounds;4x runtime for small art; alpha True; anchor 128,64. src/presentation/renderer.js:19. Path `assets/runtime/m7/wreck-overlay/wreck-overlay_{slot:03d}.png`. Fallback: Existing Canvas/CSS procedural treatment. Optional target additions can be omitted; no animation is required. All files within a template family share exact alpha/dimensions.

### C04 — Dust / impact / event effects

**OBSERVED prior classification:** PROCEDURAL RINGS/LABELS — optional animation hook required. **Current disposition:** PROPOSED_TARGET_OPTIONAL. PROPOSED counts 0 minimum / 3 target additional files; aliases/procedural entries deliberately count0.

- `static-effects`: png 128×128; source/master 3840x2160 for backgrounds;4x runtime for small art; alpha True; anchor 64,64. src/presentation/renderer.js:28. Path `assets/runtime/m7/static-effects/static-effects_{slot:03d}.png`. Fallback: Existing Canvas/CSS procedural treatment. Optional target additions can be omitted; no animation is required. All files within a template family share exact alpha/dimensions.

### C05 — Hazard indicator imagery

**OBSERVED prior classification:** PROCEDURAL YELLOW SQUARE — optional type mapping needed. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 3 minimum / 3 target additional files; aliases/procedural entries deliberately count0.

- `debris,animal,spectator`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/presentation/content/copy.generated.js:363. Path `assets/runtime/m7/icons/incident/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.

### C06 — Terrain surface textures

**OBSERVED prior classification:** FLAT CANVAS FILLS — optional renderer/material extension. **Current disposition:** PROPOSED_TARGET_OPTIONAL. PROPOSED counts 0 minimum / 5 target additional files; aliases/procedural entries deliberately count0.

- `surface-texture`: png 256×256; source/master 3840x2160 for backgrounds;4x runtime for small art; alpha False; anchor 128,128. src/presentation/renderer.js:19. Path `assets/runtime/m7/surface-texture/surface-texture_{slot:03d}.png`. Fallback: Existing Canvas/CSS procedural treatment. Optional target additions can be omitted; no animation is required. All files within a template family share exact alpha/dimensions.

### C07 — Course start/finish/checkpoint sign artwork

**OBSERVED prior classification:** DYNAMIC CANVAS LINES/LABELS — retain functional geometry. **Current disposition:** OBSERVED_REUSE. PROPOSED counts 0 minimum / 0 target additional files; aliases/procedural entries deliberately count0.

- `retain procedural`: canvas/css ×; source/master TBD; alpha True; anchor Existing geometry. src/presentation/renderer.js:10. Path `No external file`. Fallback: Live labels and Canvas/CSS. Zero physical files by design.

### C08 — Run Reward card icons

**OBSERVED prior classification:** TEXT-ONLY CARDS — optional, no existing image placeholder file. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 29 minimum / 29 target additional files; aliases/procedural entries deliberately count0.

- `focused-training,combat-drills,iron-nerves,conditioning,veterinary,surefooted,reinforced,balanced,emergency-repairs,fittings,implements,harness,familiarity,aggressive,defensive,rapid-recovery,field-repairs,medical,sponsor,supplier,negotiation,thunder-burst,second-wind,brace,perfect-line,savage-assault,absolute-focus,catch-breath,steady-team`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/career/m4/progression.js:32. Path `assets/runtime/m7/icons/run-reward/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.

### C09 — Permanent Legacy Upgrade card icons

**OBSERVED prior classification:** TEXT-ONLY CARDS — optional companion to B06. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 8 minimum / 8 target additional files; aliases/procedural entries deliberately count0.

- `recruiters,engineers,beastmaster,distinguished,dynasty,established,patron,strategist`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/career/m4/catalog.js:28. Path `assets/runtime/m7/icons/legacy/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.

### C10 — Championship insignias / trophy images

**OBSERVED prior classification:** TEXT-ONLY CURRENT PRESENTATION — optional future hook. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 15 minimum / 15 target additional files; aliases/procedural entries deliberately count0.

- `m6-intro,m6-prestige-N1,m6-prestige-N2,m6-prestige-N3,m6-prestige-N4,m6-prestige-N5,m6-prestige-N6,m6-prestige-N7,m6-prestige-N8`: svg 512×512; source/master SVG viewBox 0 0 512 512; alpha True; anchor 256,256. src/career/m6/world.js:19. Path `assets/runtime/m7/icons/championship-insignia/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.
- `trophy-dustroad,trophy-ironwheel,trophy-bannerfall,trophy-crownfire,trophy-thunder-crown,trophy-iron-gauntlet`: svg 512×512; source/master SVG viewBox 0 0 512 512; alpha True; anchor 256,256. src/career/championships/e5/catalog.js:16. Path `assets/runtime/m7/icons/trophy/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.

### C11 — Facilities / service illustrations

**OBSERVED prior classification:** TEXT-ONLY CURRENT CARDS — optional, not missing image files. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 16 minimum / 16 target additional files; aliases/procedural entries deliberately count0.

- `driver-recovery,driver-treatment,beast-care,beast-treatment,chariot-repair,chariot-refurbishment`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/career/economy/catalog.js:13. Path `assets/runtime/m7/icons/service/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.
- `staff-quarters,expanded-stables,driver-quarters,chariot-bay,workshop,treatment-ward,training-grounds`: png 512×256; source/master 1024x512 layered; alpha True; anchor 256,128. src/career/economy/catalog.js:6. Path `assets/runtime/m7/facilities/{native-key}.png`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.
- `short,standard,long`: svg 24×24; source/master SVG viewBox 0 0 24 24; alpha True; anchor 12,12. src/career/economy/catalog.js:5. Path `assets/runtime/m7/icons/contract/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.

### C12 — New Game cosmetic emblem choices / Options wheel

**OBSERVED prior classification:** EXISTING FUNCTIONAL INLINE VECTORS — polish optional. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 0 minimum / 0 target additional files; aliases/procedural entries deliberately count0.

- `wheel,shield,bolt`: inline-svg 48×48; source/master Existing inline SVG48x48; alpha True; anchor 12,12. src/persistence/e4/presentation.js:4. Path `assets/runtime/m7/icons/inline-emblem/{approved-file-key}.svg`. Fallback: Exact live text label. One per enumerable key; no rasterized labels or per-value variants.

### D01 — RU locomotion frames / atlas

**OBSERVED prior classification:** DEFER — current compositor is static. **Current disposition:** DEFER. DEFER, quantities TBD and excluded from active totals; existing static/procedural paths retained.

- `locomotion/atlas`: TBD ×; source/master TBD; alpha TBD; anchor TBD. src/presentation/renderer.js:19. Path `TBD`. Fallback: Existing static/procedural rendering. Static Bible default; no animation/directional sheets required.

### D02 — Modular race component layers

**OBSERVED prior classification:** DEFER — shared guides exist, runtime composition not implemented. **Current disposition:** DEFER. DEFER, quantities TBD and excluded from active totals; existing static/procedural paths retained.

- `full modular RU rig`: TBD ×; source/master TBD; alpha TBD; anchor TBD. src/presentation/renderer.js:19. Path `TBD`. Fallback: Existing static/procedural rendering. Static Bible default; no animation/directional sheets required.

### D03 — Ground contact shadow

**OBSERVED prior classification:** DEFER — dedicated layer not currently drawn. **Current disposition:** DEFER. DEFER, quantities TBD and excluded from active totals; existing static/procedural paths retained.

- `dedicated ground shadow`: TBD ×; source/master TBD; alpha TBD; anchor TBD. src/presentation/renderer.js:19. Path `TBD`. Fallback: Existing static/procedural rendering. Static Bible default; no animation/directional sheets required.

### D04 — Title / menu background illustration

**OBSERVED prior classification:** DEFER — current title is CSS/text, no image slot. **Current disposition:** PROPOSED_M7_REQUIRES_CHANGE. PROPOSED counts 1 minimum / 3 target additional files; aliases/procedural entries deliberately count0.

- `title-background`: png 1920×1080; source/master 3840x2160 for backgrounds;4x runtime for small art; alpha False; anchor 960,540. src/presentation/renderer.js:19. Path `assets/runtime/m7/title-background/title-background_{slot:03d}.png`. Fallback: Existing Canvas/CSS procedural treatment. Optional target additions can be omitted; no animation is required. All files within a template family share exact alpha/dimensions.

### D05 — Atmospheric backdrop / additional arena props

**OBSERVED prior classification:** DEFER — current backdrop is flat fill plus A07/A08. **Current disposition:** PROPOSED_TARGET_OPTIONAL. PROPOSED counts 0 minimum / 16 target additional files; aliases/procedural entries deliberately count0.

- `atmosphere`: png 1920×1080; source/master 3840x2160 for backgrounds;4x runtime for small art; alpha False; anchor 960,540. src/presentation/renderer.js:19. Path `assets/runtime/m7/atmosphere/atmosphere_{slot:03d}.png`. Fallback: Existing Canvas/CSS procedural treatment. Optional target additions can be omitted; no animation is required. All files within a template family share exact alpha/dimensions.
- `small-prop`: png 128×128; source/master 3840x2160 for backgrounds;4x runtime for small art; alpha True; anchor 64,64. src/presentation/renderer.js:19. Path `assets/runtime/m7/small-prop/small-prop_{slot:03d}.png`. Fallback: Existing Canvas/CSS procedural treatment. Optional target additions can be omitted; no animation is required. All files within a template family share exact alpha/dimensions.

## 5. New classes since old inventory

| ID | New class | Counts min/target | Dimensions/source | Status |
|---|---|---|---|---|
| E01 | Title/branding | 3/3 | × png | Proposed; approved UI/library originals missing |
| E02 | Shared native HTML controls/cards | 12/12 | × svg | Proposed; approved UI/library originals missing |
| E03 | Shared native HTML controls/cards | 4/4 | × svg | Proposed; approved UI/library originals missing |
| E04 | Shared native HTML controls/cards | 5/5 | × svg | Proposed; approved UI/library originals missing |
| E05 | World schematic nation card | 8/8 | 512×320 svg | M6 consumer exists; art binding proposed |
| E06 | World sample-team emblem | 8/8 | 256×256 svg | M6 consumer exists; art binding proposed |
| E07 | DOM and Canvas text | 2/4 | × woff2 | Proposed; approved UI/library originals missing |
| E08 | Resources and financial/condition status | 8/12 | 24×24 svg | M6 consumer exists; art binding proposed |
| E09 | Eight M6 race controls | 2/2 | 24×24 svg | M6 consumer exists; art binding proposed |
| E10 | Optional Gambling Den background | 0/1 | 1920×1080 png | M6 consumer exists; art binding proposed |
| E11 | Weather disclosure | 5/5 | 24×24 svg | M6 consumer exists; art binding proposed |
| E12 | Dialogs, dividers, tooltip/status treatments | TBD | × TBD | Proposed; approved UI/library originals missing |
E05/E06 are16unbound M6 briefs, not delivered map/emblem images. E09 adds No Sign and empty ability glyphs;8specific ability icons are already counted in C08's29Run icons, not counted again. World sample emblems8 and reusable rival emblem slots32/64 have different logical uses, even if all initially share template bytes. Logos3 and UI21state exports are original-source reuse, not silhouettes to regenerate.

## 6. Shared technical standards

All proposed path patterns and870target filenames (including4fonts) are in `M7_PROPOSED_FILENAME_MAP.csv`, a documentation table only. Metadata preserves native IDs A01/B01/N1, exact case; file slugs map explicitly and never rename native keys. Source families: `art-source/m7/templates`, editable masters separately under `art-source/m7/masters`, exports under `assets/runtime/m7`, generated embedding/report outputs outside editable art. Do not place generated career UUIDs into filenames; catalog pool slots are finite.

Portraits contain, no baked frame/label,8% safe border, complete ancestry/species extremities. Chariot/facility2:1illustrations contain. Backgrounds use central60% safe composition; cover cropping is explicitly separate from portrait contain. RU anchors and paired masks do not trim independently. Sprite colors affect designated livery only. Keep selection, condition, injury and disabled status in live CSS/Canvas overlays, not duplicate full portraits for every state. Color alone is never the only status/team cue.

SVG icons use24×24viewBox,2pxsafe inset, round-trip tested16/24/32CSS; no icon must replace live material price/eligibility text. Cache SVG rasterization before Canvas reuse. No filters or on-frame reparsing. Raster masters may be larger than runtime; alpha-edge checks against light/dark backgrounds are mandatory. Static is the default. Expose alt text in DOM; decorative frames pointer-events:none/aria-hidden:true. Map symbols/road geometry/meters remain procedural.

Rights/provenance per asset: creator, source and source hash, generated/commissioned provenance, license and rights constraints, approval status, template lineage/hash, runtime hash, compatible native keys, export specification. Reference to a franchise is a visual-principles reference only, never permission to copy its IP. No new art has been generated here.

## 7. Approved UI source intake, not reconstruction

Interim Bible establishes13UI palette tokens, Bangers Regular for buttons/navigation/headings and IM Fell English Regular—not Small Caps—for feature titles. Body face unresolved. Master Button v2: face320×60,triangle extension8,stroke1.75/perimeter2,wheel radius19,rail34,slice27,referenceBangers36tracking1.75. Card face244×346,padding20,art115high,headingIM Fell23,body13,grid3×2gap26. Secondary face196×37,Bangers22,perimeter.5,rails2,offset2,inset5,extra top6. These are reference faces, NOT verified SVG file dimensions. Original rails/transparent margins/slices and overlay source must be delivered before production. Never distort circular wheels with stretched whole-SVG scaling. Separate9slice base and fixed-proportion opposing diagonal overlay.

Enabled Purchase selects its own parent card then calls the existing quote/confirmation workflow. Disabled Purchase neither selects nor transacts, including pointerdown bubbling. Selection is transient UI, not purchase success or a save transaction. Preserve keyboard focus and native disabled controls. All6Master/5Secondary/4Card state exports are counted once per family, not once per button.

Measured fill-only contrasts from approved tokens: standard13.332:1, hover6.984:1, selected2.113:1, critical2.639:1. Selected/critical are design/accessibility risks even at a3:1large-text threshold; disabled3.892is treated separately. Actual outlines/shadows may alter the rendered result and were not supplied. Do not silently recolor approved states; owner/design thread must disposition after exact glyph/outline proof. See `evidence/contrast-diagnostic.json`.

### Exact interim-approved UI palette and states

| Token | Hex |
|---|---|
| Racing Umber | #1E140F |
| Deco Charcoal | #171A20 |
| Antique Ivory | #F4D39B |
| Thunder Gold | #FFBC19 |
| Antique Bronze | #B88742 |
| Deep Oxblood | #540F19 |
| Blood Crimson | #A61924 |
| Warm White | #FFF5E6 |
| Hover Orange | #E99A51 |
| Ink Black | #09090B |
| Muted Gray | #777777 |
| Burnt Orange | #A64B20 |
| Deep Burnt Orange | #633018 |

| Master state | Fill | Text | Frame/overlay |
|---|---|---|---|
| standard | #540F19 | #FFF5E6 | #A61924 |
| hover | #A61924 | #FFF5E6 | #E99A51 |
| pressed | #540F19 | #FFF5E6 | #E99A51 |
| selected | #E99A51 | #FFF5E6 | #A61924 |
| critical | #09090B | #A61924 | #FFBC19 |
| disabled | #171A20 | #777777 | #777777 |

Card normal surface#171A20at50%, selected#633018at50%; frame standard#A64B20, hover#E99A51, selected#FFBC19, disabled#777777. Secondary uses Master standard/hover/pressed/selected/disabled colors; no critical Secondary state is approved. These13tokens govern the UI, not a hardware palette limit for all illustration/livery. Source: interim Bible0.4.0§4/6/7.2. Typography formula H/60 remains a proposal; source slices and exact glyph outlines remain unknown.

## 8. Concrete silhouette template briefs (future production only)

Global brief for every T-template: original Dark Deco Retro Cartoon, confident smooth contour, strong negative space, flat two/three-tone silhouette, no pixel grid, no photographic texture, no final label or frame. For transparent subjects use contrasting Antique Ivory/Thunder Gold masses and Ink Black edge; do not make an invisible black silhouette on the dark game. Preview on checkerboard/dark/light surfaces, but never bake the preview background into alpha artwork. Preserve all dimensions/anchors and source provenance. SVGs use explicit namespace, width, height, viewBox and legal paths/hex paints only. PNG exports are8-bitRGBA. These are recommended briefs, not generated files or approved final designs.

### T-arch

**Role:** Race world scenery. **Runtime:** 512×256 SVG, alpha True. **Master:** SVG viewBox0 0 512 256. **Source:** `src/presentation/renderer.js:15`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Strict top-down gateway footprint with clear negative-space passage; no wall that appears to obstruct the native road. Anchor256,128 and same16x8world box. No new collision or lane markings.

### T-background

**Role:** Optional Gambling Den background; Race screen-fixed backdrop; Title and menus. **Runtime:** 1920×1080 PNG, alpha False. **Master:** 3840x2160 layered master. **Source:** `src/management/startup/shell.js:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Opaque Dark Deco arena/stable atmosphere, large angular distant masses, no baked menus/text. Dark low-contrast central60% safe area for live controls; outer corners may crop. No perspective cues that replace a top-down race view.

### T-beast-B01

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Horse (B01), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-beast-B02

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Storm Elk (Hroven) (B02), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-beast-B03

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Crown Boar (Brond) (B03), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-beast-B04

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Meadowstrider (Vellin) (B04), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-beast-B05

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Racing Ram (B05), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-beast-B06

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Grun’Jho (B06), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-beast-B07

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Dire Wolf (B07), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-beast-B08

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Wingless Drake (B08), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-beast-B09

**Role:** Market, Barn, RU preview. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `content/m5/v1/catalogs/beastSpecies.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One Sunhorn (Saelor) (B09), full body in a calm three-quarter inspection pose. Complete feet, ears and documented horns/tail inside canvas; no handler, chariot or scene. Species-neutral stock detailing allows all listed stock profiles to share this first template. Consult canonical stock bible; do not infer anatomy from an exotic name alone.

### T-character-A01

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:34`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Human head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Five fingers and toes; rounded external ears; flat nails; human dentition; no intrinsic horns, tails or unusual skin structures. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A02

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:90`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Orc head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Two lower-jaw tusks (size variable); five digits per hand; ordinary plantigrade feet; rounded-to-pointed ear tips; no mandatory facial piercings or tribal markings. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A03

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:146`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Goliath head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Five digits; rounded or slightly tapered ears; generally sparse body hair; skin patterns may resemble mottling or natural stone-like markings, not literal rock plating. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A04

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:202`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Hill Dwarf head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Five digits, broad hands and feet, dense hair, strong brows and jaws; female Hill Dwarves never grow facial hair. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A05

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:258`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Mountain Dwarf head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Broad five-fingered hands, sturdy feet, heavy brow and dense bone structure; female Mountain Dwarves may grow exaggerated sideburns and hair along the jawline and chin, but never full beards; no intrinsic stone skin or metallic features. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A06

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:314`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Halfling head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Five fingers, five toes, humanlike ears with subtle taper possible; comparatively large feet, often with natural hair on tops of feet. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A07

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:370`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Forest Elf head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Long pointed ears, five digits, fine hair, expressive eyes; no mandatory antlers, wings, glowing tattoos or overt faerie appendages. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A08

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:426`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult High Elf head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Pointed ears, five digits, finely textured skin; no innate glowing eyes, desert scales or supernatural markings. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A09

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:482`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Sea Elf head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: **Approved amphibious physiology:** breathe air and water; subtle subtle paired functional gill slits on the sides of the neck, behind and below the ears; mild webbing between fingers and toes; pointed ears; five digits. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A10

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:538`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Gnome head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Five fingers and toes, prominent external ears, humanlike nails and teeth; no intrinsic mechanical implants or goggles. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A11

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:594`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Goblin head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Five digits, large pointed ears, sharp canine teeth, humanlike feet; no compulsory claws, tails or oversized fangs. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A12

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:650`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Dragonkin head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Scaled hide, clawed five-fingered hands, reptilian snout and teeth, visible tail, external ear openings rather than human ears; **no wings**; no universal breath weapon. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-character-A13

**Role:** Market, Barn, race identity; shared Owner portraits. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable SVG/layered master. **Source:** `content/m5/v1/canon/Blood_and_Thunder_Ancestry_Reference_Bible_Canon_v1.0(3).md:706`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One adult Tortle head-and-shoulders silhouette for a shared Owner/Driver portrait. Canonical shared anatomy: Keratinous beak, scaled or pebbled skin, thick fingers and toes with blunt claws, dorsal shell and ventral plastron; no external human ears. Sex-neutral pose and costume; no beard or other sex-specific cue required. Neutral work/racing coat, no weapon, reins or occupation badge. Ears, shell contour, muzzle or other documented ancestry cue remains inside the frame.

### T-chariot

**Role:** Market and Barn. **Runtime:** 512×256 PNG, alpha True. **Master:** 1024x512 layered master. **Source:** `src/career/economy/market.js:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Single empty two-wheel racing chariot in three-quarter inspection view, wheels/chassis/shaft wholly contained. Generic construction, no driver/beasts, no implied light/heavy class. Stable geometric chassis silhouette readable at128x64CSS.

### T-effect

**Role:** Optional native-event decoration. **Runtime:** 128×128 PNG, alpha True. **Master:** 512x512 master. **Source:** `src/presentation/renderer.js:27`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Target-only optional template. 

**Production brief:** One sparse radial impact/dust burst silhouette, transparent background, anchor64,64,8px safe inset, no embedded damage numbers or injury symbols. Static, no animation frames; live event/state decides visibility.

### T-emblem

**Role:** Rival/Owner identity, standings, radio; World sample-team emblem. **Runtime:** 256×256 SVG, alpha True. **Master:** SVG viewBox0 0 256 256. **Source:** `src/presentation/identity.js:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** An original abstract wheel-and-shield sporting emblem, no text, no official nation flag, no franchise insignia. Use broad masses and interior negative space. It can temporarily fill every compatible full-emblem file; color is decorative.

### T-equipment

**Role:** Market, inventory, Workshop. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 layered master. **Source:** `src/career/economy/catalog.js:3`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** A neutral arrangement of hardware, straps and fittings, no body or scene. This temporary silhouette must not promise a specific harness/wheel/weapon subtype where native metadata does not specify one.

### T-facility

**Role:** Workshop & Facilities. **Runtime:** 512×256 PNG, alpha True. **Master:** 1024x512 layered master. **Source:** `src/career/economy/catalog.js:6`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Generic stable building/work area in inspection perspective, unoccupied, fully contained, no progression tier, labels or implied staffing capacity. Compatible first template for seven native improvement files.

### T-icon

**Role:** Contract duration choice; Eight M6 race controls; Hazards/incident help; Legacy market and equipped icons; Race command deck; Resources and financial/condition status; Run choice and selected ability control; Weather disclosure. **Runtime:** 24×24 SVG, alpha True. **Master:** SVG viewBox0 0 24 24. **Source:** `src/management/m4.js:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Neutral hexagonal token/star silhouette with a clear hollow center,2px safe inset. Used only as explicitly temporary glyph under live labels; do not imply healing/damage/currency effects. Finished icons replace exact individual files later.

### T-insignia

**Role:** Championship cards/Details/World. **Runtime:** 512×512 SVG, alpha True. **Master:** SVG viewBox0 0 512 512. **Source:** `src/career/m6/world.js:19`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Generic racing championship seal with wheel/laurel masses, no title lettering or fictional new official award.32px safe inset; distinguish from a physical trophy. Sporting identity remains the live native championship name.

### T-map

**Role:** World schematic nation card. **Runtime:** 512×320 SVG, alpha True. **Master:** SVG viewBox0 0 512 320. **Source:** `content/m6/world-asset-briefs-v1.json:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Non-geographic abstract landscape/racing-route vignette: mountains/architecture/route motifs, no map borders, capital positions or real-world geography. Transparent exterior,24px safe inset. Live nation label stays outside.

### T-mark

**Role:** Compact identity marks. **Runtime:** 24×24 SVG, alpha True. **Master:** SVG viewBox0 0 24 24. **Source:** `assets/runtime/proof/mark.svg:1`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Simplified reduced emblem/wheel, at most three large masses, no lettering or miniature spokes. Centered12,12 with2px safe inset. Derive identity from T-emblem without downscaling unreadable detail.

### T-mask

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** Exact shared RU guide. **Source:** `src/presentation/assets.js:13`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Technical alpha mask, not an illustration: opaque white only inside designated paintable chassis/livery regions, all other pixels transparent. Same256x128 dimensions, axle80,64 and alignment as T-ru-*; never tint beasts, face, ink, wheels or ground. Export separately and validate against each base.

### T-prop

**Role:** Optional world prop. **Runtime:** 128×128 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `src/presentation/renderer.js:15`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Target-only optional template. 

**Production brief:** One small top-down decorative stone/banner-base silhouette, transparent exterior, ground anchor64,112 and8px margin. No hazard coloring, racing lane or gameplay promise.

### T-ru-B01

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Horse (B01), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-ru-B02

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Storm Elk (Hroven) (B02), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-ru-B03

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Crown Boar (Brond) (B03), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-ru-B04

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Meadowstrider (Vellin) (B04), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-ru-B05

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Racing Ram (B05), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-ru-B06

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Grun’Jho (B06), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-ru-B07

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Dire Wolf (B07), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-ru-B08

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Wingless Drake (B08), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-ru-B09

**Role:** Championship and Practice race Canvas. **Runtime:** 256×128 PNG, alpha True. **Master:** 1024x512 editable guide; +X. **Source:** `assets/presentation.manifest.json:1; proposed M7 2x derivative`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One true orthographic top-down racing unit with two matching Sunhorn (Saelor) (B09), generic chariot and covered ancestry-neutral driver. Forward is right/+X. Axle(80,64), driver(64,64), wheel hubs(64,32)/(64,96), beast anchors(152,36)/(152,92); alpha visual bounds(32,16,192,96). Same chassis/livery region as every other RU template; no perspective, text or ground scene. These proposed doubled-pixel guides preserve reference(40,32), not collision size.

### T-service

**Role:** Recovery & Services. **Runtime:** 24×24 SVG, alpha True. **Master:** SVG viewBox0 0 24 24. **Source:** `src/career/economy/catalog.js:14`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Generic tool/hand service glyph, simple2px silhouette safe area; no medical plus sign promising healing for every service. All six distinct service labels remain live and authoritative.

### T-stable

**Role:** Home Stable. **Runtime:** 800×300 PNG, alpha False. **Master:** 1600x600 layered master. **Source:** `src/management/headquarters/consolidated.js:11`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Wide graphic stable facade, angular Dark Deco roof and broad doorway silhouette, no numbers/progression stage or baked labels. Central60% contains main architecture; left/right margins can crop. Opaque Racing Umber background with ivory/bronze contrasting structure.

### T-staff-beast-handler

**Role:** Staff & Contracts; Market. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `src/career/m5/generation.js:39`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One neutral occupational bust/symbol for Beast Handler, with a clear tool/workwear cue, face/anatomy concealed. It must not assert Human ancestry, sex, nationality or new skill. No specific employee likeness or invented clinical outcome.

### T-staff-mechanic

**Role:** Staff & Contracts; Market. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `src/career/m5/generation.js:39`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One neutral occupational bust/symbol for Mechanic, with a clear tool/workwear cue, face/anatomy concealed. It must not assert Human ancestry, sex, nationality or new skill. No specific employee likeness or invented clinical outcome.

### T-staff-physician

**Role:** Staff & Contracts; Market. **Runtime:** 256×256 PNG, alpha True. **Master:** 512x512 editable master. **Source:** `src/career/m5/generation.js:39`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** One neutral occupational bust/symbol for Physician, with a clear tool/workwear cue, face/anatomy concealed. It must not assert Human ancestry, sex, nationality or new skill. No specific employee likeness or invented clinical outcome.

### T-texture

**Role:** Optional clipped terrain. **Runtime:** 256×256 PNG, alpha False. **Master:** 512x512 seamless master. **Source:** `src/presentation/geometry.js:4`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Target-only optional template. 

**Production brief:** Opaque flat two-tone low-contrast seamless material patch; no stones or markings that imply hazards. Opposite edges must tile exactly. Runtime is RGBA with alpha255 even though artwork is opaque.

### T-tower

**Role:** Race world scenery. **Runtime:** 512×256 SVG, alpha True. **Master:** SVG viewBox0 0 512 256. **Source:** `src/presentation/renderer.js:15`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Strict top-down roof/tower footprint and short geometric cast shadow, not elevation or isometric architecture. Anchor256,128,16x8world box; keep silhouettes within16px inset and road-facing edge clear.

### T-trophy

**Role:** Existing earned trophies/Home results. **Runtime:** 512×512 SVG, alpha True. **Master:** SVG viewBox0 0 512 512. **Source:** `src/career/championships/e5/catalog.js:16`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Minimum catalog template. 

**Production brief:** Single stylized trophy silhouette with broad handles and base,32px safe inset; no baked rank, year, award value or invented national title. One technical template may fill six native trophy filename slots.

### T-wreck

**Role:** Optional wreck overlay. **Runtime:** 256×128 PNG, alpha True. **Master:** Shared RU guide. **Source:** `src/presentation/renderer.js:25`. **Quantity:** one unique template; copied only into compatible slots, not one new drawing per logical file. Target-only optional template. 

**Production brief:** Static transparent cross/scuff overlay localized to chassis, centered at native axle80,64. Never erase/relocate actors or depict a permanent death; it appears only for native wreck state.

## 9. Scope and acceptance

Proposed minimum **395image files+2fonts=397files**, target **866+4=870**. Source templates **49/53**, including one technical mask;73/77estimated unique image payloads after template dedup+21UIstate exports+3logos. No row authorizes implementation. Undefined dividers/tooltips/full modular/animation quantities remain TBD, not fictitious zero requirements. See sizing document for exact arithmetic, estimates and reuse.

Before implementation resolve M6 recruitment blocker, final Bible/library/fonts, viewport/internal scrolling policies, actual SVG slices, contrast and proposed manifest/cache contracts. Audit source and asset files remain unchanged.
