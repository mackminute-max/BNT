# M7 development plan and implementation advice

Audit date: **2026-11-25** (America/Los_Angeles). Audited commit: `0c29a65a7cf8bdf0ced1821eb59da314981507f6`; branch `feat/e5-d-m1-startup-slots-options`.

**OBSERVED** means verified source or a named audit probe. **PROPOSED M7 / REQUIRES CHANGE** is a recommendation, never an installed feature or approved quantity. **DEFER** is outside the initial visual scope. **UNKNOWN** is not silently estimated as a fact. All proposed tables are documentation, not runtime inputs.

## Recommendation

Implement a small shared presentation shell/component layer, then migrate one vertical slice at a time. Do not rewrite the game or introduce a framework. The long-term architecture remains deterministic native simulation → accepted buffered Worker/projection → view models/resolver → Canvas/DOM, with unchanged protected career transactions. Art loading is outside that authority chain. Current M6delivery is a committed candidate, not a recorded Windows acceptance.

A first authorized corrective gate must handle the verified M6driver acquisition failure separately. Do not conceal it with silhouette art, remove validation, bypass transaction commands or automatically migrate records. The future M7 scope must explicitly permit the presentation registry/cache/UI changes below; this audit grants none.

## Alternatives

| Option | Advantages | Problems | Recommendation |
|---|---|---|---|
| CSS-only skin | Fast first look, little routing work | Cannot remove long-page/dropdown workflows or connect identity art; preserves duplicated iframe tables | Use only for early token proof, not whole M7. |
| Replace all UI/rendering at once | Uniform final structure | Highest regressions/acceptance risk; native transactional gates easy to lose | Reject. |
| Shared shell+small adapters, incremental screen migration | Reusable native buttons/dialogs, one screen owns actions, isolated tests/rollback | Needs explicit transitional skin/route ownership | Recommended. Keep vanilla modules and native command ports. |
| Full modular/animated race art now | Maximum visual customization | Combinatorial assets, anchoring/ordering/animation burden not needed for static Bible | DEFER; complete species-compatible RUs+mask first. |
## Proposed bounded work packages

| Package | Effort/risk | Scope/deliverables | Boundaries | Acceptance gate | Dependencies |
|---|---|---|---|---|---|
| M7-0: authority/intake | Small; owner dependency | Record accepted M6revision, authorize its narrow recruitment fix, receive final Bible/library, validate fonts/licenses/original PNGs/SVGs/slices; freeze asset contract and viewport policy. | No production until source library proven. No gameplay/economic/save change implied. | Native driver hire succeeds once, metadata preserved offer→owned; all original hashes retained; approval/version matrix clear. | M6corrective owner review; final Bible and original library required. |
| M7-1: asset bridge / shell proof | Medium; high packaging risk | Presentation registry-v2 proposal implementation, legacy reader bridge, logical→payload resolver, lazy bounded decode, source/license validation, fonts and shared payload registry; smallest shell/keyboard/theme proof. | Keep native stores/schema untouched. Native old proof IDs remain fallbacks. | Valid/missing/corrupt/wrong-alpha/dimension fixtures; no network; wrong versions fail closed; no native state/RNG mutation; two deterministic standalone builds. | M7-0 +one compatible portrait/RU/mask/emblem template and approved UI assets. |
| M7-2: Market vertical slice | Medium; high interaction risk | Native asset-card component; 6cards at a verified large viewport, smaller paged composition; direct contract terms, detail pane, enabled Purchase selects parent then calls native preview/confirm; Barn/Home identity match. | No alternate price/grant/recruitment authority, no universal work-review routing. | Enabled unselected Purchase selects first; disabled pointer/keyboard neither selects nor transacts; quote expiry refreshes/reconfirms; no doubled fee; reload and focus; long names/tiny viewport. | M7-1 +approved Card/Secondary/Master originals and M6F01fix. |
| M7-3: management screens | Large aggregate, incremental small slices | Home/Barn →Staff/Workshop/Services/Finances →Championships/World/Den →Records/Options/Save/Help/recovery, reusing common shell/components. | Each function keeps one primary page; no save merely for navigation; no new economics/career events. | All empty/busy/locked/pending/failure states reachable without page scroll/dropdowns; existing roster replacements, reward gates, settlement, backup/deletion preserved;20navigation cycles no duplicated IDs/listeners. | M7-2; art families can arrive independently by class; content copy reconciliation needed. |
| M7-4: race presentation | Medium; high determinism/input risk | Species-compatible static RU/mask resolver, shared identity, consistent labels/fonts/markers/radio,8M6controls, Practice and AI-only Den skin. | Same geometry, world footprint, dt, native decisions/RNG/sign accounting; no mandatory animation or session persistence change. | Exact same setup+input outputs/goldens; no decode/composition inside draw loop; pause/speed/ability ordering; missing art cannot block eligibility; map all8entrants/rally checkpoints visible. | M7-1; silhouette/anchor proof, identity fallback; can proceed independently of most M7-3screens. |
| M7-5: catalog population / replacement tooling | Medium; low gameplay risk, high catalog quality risk | Future idempotent missing-only template copier, generated hashes/status/provenance reports and filename inventory; fill proposed target IDs with compatible templates; finished replacement validation. | No new native catalogs, personal file-per-UUID or automatic overwrite. Asset build metadata may change; gameplay code does not need edits for replacement. | Two runs identical; approved art untouched; no duplicate paths/IDs; every format real; alpha/anchors/masks/licensing checked; catalog expansion policy stable. | Approved quantity/window decision and minimum49/target53templates. Do not wait for finished art in every slot. |
| M7-6: integrated acceptance | Medium; owner/hardware dependency | Complete browser/native/persistence regression, layout and font checks, memory/package-size/draw-time profiling, manual Windows Chrome/Edge offline proof. | Do not update golden results to make visuals pass; old artifacts unchanged. | Full relevant Node/browser tests raw exits; no network; two byte-identical builds; Windows file://owner signoff; all data accessible on supported sizes and zoom. | All functional screen slices; pending art conspicuously labeled in metadata/DOM, not mechanics. |
Effort is relative complexity, not an invented calendar estimate. Use reviewable local checkpoints, not separate unapproved gameplay milestones. M7-3screens and M7-4race adapters may proceed independently after M7-1, but final regressions must use the combined source. Art production can proceed independently once template contracts/canon are frozen. Failure at any authority/transaction/determinism boundary stops that slice.

## Shared UI components and single-screen composition

Use a native `<button>` wrapper for approved Master/Secondary bases and decorative overlay layers. CSS layouts remain mostly frameless; only assets/actionable cards get selective visual frames. Retain `<dialog>`, accessible labels/disabled/focus, safe escaping and live native data. Common pure components: title/navigation, action button, asset card, condition/status display, direct-choice group, pager, details view, quote confirmation, busy/error/recovery panel. View models may contain `artRef`; native career/simulation objects may not acquire new art fields.

No player-facing native/custom dropdowns: Owner2sex/8nation/13ancestry choices; contract3terms; training/engineering attributes; Legacy slots; betting teams; speed; career slot lists all use direct visible options, tabs/pages or dedicated choice views. Do not replace a select with a disguised popover menu. A hidden nonfocusable native control may remain only as an internal adapter during migration, never as the player-facing chooser. Color controls can use explicit swatches; preserve custom saved hex values without silently resetting them to a theme palette.

Reference 3×2Card grid requires2×346+26=718CSSpx before header/footer; it cannot fit most768px-high windows unchanged. Preserve legibility instead of shrinking every label. Recommend1280×720minimum normal layout,1366×768/1600×900/1920×1080/2560×1440test matrix; fewer cards per page at smaller heights,6only where actually measured to fit. Keep13pxCard reference text unless owner approves typography adjustment; general14–16pxbody/race-status recommendation is not a license to silently override approved component studies. At800×600or200%zoom propose a compact single-card/text-detail page, less decorative art and explicit paging, with Save/Back/Options always reachable. Below supported minimum communicate the limit accessibly; do not hide critical overflow.

Use root height100dvh/grid, min-height:0 in structural containers, explicit page/detail routes and measured content budgets. `overflow:hidden` on body is not acceptance: test every content element has a reachable route and keyboard focus. Avoid deep tabs merely to simulate “no scrolling”; consolidate related fields when they fit. Long canonical names and financial obligations need readable detail views. Never truncate material costs, freeze conditions or storage errors without an accessible full view.

Optional user-gesture fullscreen with Esc return; no mandatory fullscreen or server. Resizing is presentation-only and must not restart races. Internal radio/history scrolling conflicts with the latest Bible's unresolved exceptions, though old in-race guidance approved a scrolling radio column. Recommend a bounded internal radio feed with Pause auto-follow/history access, while browser-page scroll remains prohibited. If not approved, use live recent lines+paginated history. Do not silently decide this policy.

## Catalog proposal — documentation only

Current manifest-v1 is not the proposed format. The following intentionally has TBDhashes and cannot be imported. Preserve native case in tags while allowing stable lowercased asset ID namespaces. Runtime source input remains whatever separately authorized M7registry implementation validates.

```json
{
  "kind": "BNT-M7-presentation-catalog-PROPOSAL",
  "version": 2,
  "resolverVersion": "m7-presentation-v1",
  "poolWindow": {"A01/male": 12},
  "assets": [{
    "id": "portrait.character.a01.male.001.v1",
    "categoryId": "A03",
    "sourceKey": {"ancestryId": "A01", "sex": "male"},
    "path": "assets/runtime/m7/portraits/A01/male/portrait_A01_male_001.png",
    "format": "png",
    "runtimeSize": [256, 256],
    "sourceSize": [512, 512],
    "anchor": [128, 128],
    "alpha": true,
    "status": "template",
    "template": {"id": "T-character-A01", "sourceHash": "TBD-after-export"},
    "sha256": "TBD-after-export",
    "fallbackRole": "same-ancestry-neutral",
    "rights": {"source": "TBD-original", "license": "TBD-verified"}
  }]
}
```

Temporary subject image may be sex-neutral even in a male/female slot; finished replacement must remain compatible. Stable paths are finite pool slots, not character UUIDs. File suffix/bytes/dimensions must match; source/template and runtime hashes are separate. Preserve actual source provenance and license approval. Builtin fallback roles are not missing PNGs. Source PSD/KRA/SVG masters remain outside shipping; no sourcePath fake extension to appease legacy SVG validation.

Body font decision and source glyph coverage remain open. Font files go through licensed WOFF2intake, not SVG `<text>` or a CDN. Inject font/theme declarations into each srcdoc viewer; outer-document CSS/FontFaceSet does not automatically style iframe DOM or Canvas. Canvas text requires explicit loaded font selection/measurement. Bangers and IM Fell Regular file names/weights must match originals; no automatic Small Caps substitute. Test canonical apostrophes, diacritics and required Latin glyphs before subsetting. A failed font preserves readable live fallback and never blocks native race steps.

## Future missing-only population algorithm

This is a design, not an implemented generator:

1. Read approved production plan/template ledger; validate target paths, native tags, bounds and exact alpha/format. Resolve explicit filename map and state exports; do not guess names from display text.
2. Existing file with recorded approved/hand-authored status is never overwritten. Existing unrecorded file produces a review conflict, not deletion. Existing template hash match is idempotent; edited files require explicit replacement registration, not refresh from a stock template.
3. Copy original compatible template bytes only into missing intended files. Distinct IDs/paths remain distinct; masks and base files have matching guides. Brand and approved UI originals are imported as supplied, never replaced by generic silhouettes. Missing originals remain blocked.
4. Derive hashes and status/provenance into generated build metadata; replacing finished bytes requires this metadata to refresh, but no gameplay code changes. Validate file signatures, dimensions, compatibility, alpha margins, references, ID/path uniqueness, rights and fallback cycles.
5. Emit logical catalog and a separate content-hash payload table, deduplicating identical bytes for embedding only. Alias references must resolve independently when one file later changes. Decode by shared hash+requested raster size/composite parameters with correct lifetimes/reference handling, not destructive per-ID eviction.
6. Load required visible-screen assets lazily from already embedded bytes, not network; handle cache eviction with explicit reload, bounded decoding/concurrency and fallbacks. RU composite keys include base/mask IDs+hashes, tint/style and output resolution, not only color. Never create composites or parse SVG inside actor loop.
7. One outer immutable payload registry avoids current triple embedding. Pass trusted presentation references to current UI iframes; retain standalone fallback embedding for independent viewers. Validate `file://` same-origin/srcdoc behavior in Windows Chrome/Edge; do not assume parent access/CSP/Blob behavior.

Pool identity rule: use presentation-domain hash of stable generation fingerprint/member/Owner identity+compatibility group, with frozen ordered target window. Do not consume native RNG, change attributes or attach image data to Worker/checkpoint/backup authority. A no-repeat global durable assignment map or resolver-version save pin is not authorized; propose separately if demanded. Missing-asset fallback never changes native eligibility, draft choices or stats.

## Validation matrix for future authorized implementation

| Gate | Required cases |
|---|---|
| Asset intake | Missing/corrupt/oversized/wrongformat/wrongdimensions/wrongalpha; forbiddenSVG/text/style/scripts/external refs; provenance/rights; unsupportedversion; duplicateID/path; fallbackcycle; base/mask pixelalignment. |
| Template idempotence | Missing-only behavior, identical second run, edited/approved art preserved, valid PNG/SVG—not renamed bytes; targeted replacement does not change other logical IDs; exact counts. |
| Identity continuity | Offer→owned→Barn→race→reload/backup; A01–A13sex matrix, all9species/39stocks; unknown/rival/staff safe fallback; no native RNG draws or actor mutations; pool expansion/replacement stability. |
| UI/purchases | Enabled Purchase selects then quotes/transacts once; disabled target neither selects nor transacts under click/pointerdown/keyboard; stale quote refresh and reconfirm; all blocked finance/contract states visible;20route cycles no duplicates. |
| Layout/accessibility | Viewport/DPR1,1.25,1.5,2,3;100/125/150/200%zoom; no page scroll/dropdowns; all controls reachable; native focus order/return, longlabels/Unicode, disabled reason, fontloading, contrast, reducedmotion, fullscreenEsc. |
| Race authority | 12historical+2payroll references, M6ability/Signs exact native comparisons, pause/speed/checkpointrestart/queued legacy context, official publication/idempotency; Canvas/tint/sprite replacement produces no outcome changes. |
| Persistence | Career/profile ownership, M3-Bpin/sidecar-v2/Ownersex, activeTeam/frozen registration, native save/load/export/completebackup/recovery/deletion, failedstorage/stalewriter/lostack; no art fields/migration in schema8. |
| Performance | Measure draw/DOM p95, decode/raster/composite times, scene-switch/frame longtasks, visible-cache steady state, iframe copies and heap/GPU approximations;8RUs/longRally/Worldlarge roster; no eager decode of full catalog. |
| Offline/build | One self-contained HTML, no network/adjacentfiles/CDN; two byte-identical builds and size/hash ledger; Windows owner Chrome/Edge directfile with networkdisabled; managed HTTP never substitutes. |
Performance targets remain proposals: p95presentation draw≤8ms and no new presentation task>50ms at documented hardware/viewport; memory budgets from sizing are proposed, not automatic cap changes. Separate inherited native/persistence cost from new asset decoding/rendering. M6retained-backup6.5sblocking evidence is not a Canvas benchmark; do not expand M7into unapproved E4persistence redesign.

## Owner/design inputs before production

1. Confirm M6accepted source; separately authorize F01recruitment correction and sex continuity, and classify Steady Team copy/mechanics discrepancy. This audit cannot amend gameplay.
2. Deliver completed Bible, exact original logos, all approved UI SVGs/studies/settings/slice metadata, fonts/licenses and asset-specific provenance. Missing final library blocks exact exports, not this investigation.
3. Confirm body face/weights, critical/selected contrast disposition, supported viewport/zoom/fullscreen behavior and bounded internal radio/history scrolling policy.
4. Choose minimum vs upfront target slot window; review49/53template plan,395/866images,2/4fonts, proposed256×128RU contract and performance/package budgets. Values are recommendations, not preapproved requirements.
5. Approve a versioned presentation-only registry/loader change, including planned1024logical bound and measured cache targets, while preserving legacy readers. No mechanical schema or native limit increase is part of it.
6. Decide whether future strict no-repeat/user portrait choice requires a separately authorized persisted presentation pin. Otherwise use stable stateless lookup and accept repeats.

## Exclusions / rollback

No new gameplay, rewards, prices, career qualifications, races, nation bonuses, AI/physics, equipment durability, RNG, record pruning, server, framework, save migration or authority changes. No animation/modular rig/extra directions required. Keep accepted M4/M5/M6artifacts and previous visual registry readers; migrate screens behind a presentation build/version switch and roll back that skin/resolver independently of saves. Art decode failure uses live fallbacks, not a race reroll. Stop after owner review; this plan is not implementation authorization.
