# M7 reference changelog

Audit date: **2026-11-25** (America/Los_Angeles). Audited commit: `0c29a65a7cf8bdf0ced1821eb59da314981507f6`; branch `feat/e5-d-m1-startup-slots-options`.

**OBSERVED** means verified source or a named audit probe. **PROPOSED M7 / REQUIRES CHANGE** is a recommendation, never an installed feature or approved quantity. **DEFER** is outside the initial visual scope. **UNKNOWN** is not silently estimated as a fact. All proposed tables are documentation, not runtime inputs.

This is a complete refresh rather than a patch to stale M3references. Old references cite a70ec6e/36b0048; current audit is0c29a65. Earlier proposed dimensions and proof constraints are not silently promoted to production contracts.

| Area | Prior reference | Current disposition | Source |
|---|---|---|---|
| Baseline | M3-era content/asset examples | M6committed candidate, schema8and new World/Den/ability consumers; owner acceptance unknown | M7_VISUAL_OVERHAUL_AUDIT.mdbaseline / src/career/m6/schema.js:28 |
| Path move | content/batch02/03/04 | Actual copy under content/presentation/m3-a; identity/radio under content/e5-d/m3-bc; old paths unavailable | src/presentation/content/copy.js:1 / m3-bc-data.js:1 |
| Identity count | 23authored offers were main finite set | 23retained legacy identities plus renewable M5/M6generators;16catalogs256records | src/career/m5/generation.js:17 |
| Species/ancestry | Cosmetic M3annotations | 13canonical ancestries/9species and actual affinity metadata;39stock profiles. Native generic_draft_beast string is not a license to depict every beast as Horse. | src/model/affinity.generated.js:2 |
| Owner/driver sex | Missing older reference axis | M6Owner male/female,13ancestries; driver male/female/unspecified validation; rivals/local/Den/staff demographic gaps | src/career/m6/current.js:20 / schema.js:23 |
| Recruitment blocker | No issue recorded in earlier reference | 5native purchases reject visual identity; source offer visual orphan, plus potential new-IDsex reseeding | evidence/identity-handoff-probe.json |
| Rewards | 14deferred notes | 21actual passive/immediate Run+8ActiveAbilities;8Legacy upgrades; completion LP/Gold/Rep separate | src/career/m4/catalog.js:5 / src/sim/m6-interaction.js:3 |
| Signs | Prestart/nextcrossing approval in old guidance | Old contexts keep queued boundaries; M6version2nextnative tick;6Signs+NoSign+Ability | src/ai/signs.js:12 / scripts/m6/viewer-presentation.mjs:1 |
| World assets | No new M6slots | 8schematic maps+8sampleteam emblems are unbound div refs, not images; native briefs have exactIDs | content/m6/world-asset-briefs-v1.json:1 |
| Competition | Six-signature board expectation | M6intro/renewablelocals/8nationalPrestige;6economic contexts still supply terms/trophies. No invented national trophies. | src/career/m6/world.js:19 |
| Production bounds | 64/24entries/8MiB were old proof notes | Reverified stillcurrent:64manifest,24images8MiB; eager preload and no auto reload are scaling blockers | src/presentation/contracts.js:4 / assets.js:4 |
| Packaging | Embedding/dedup treated generally | 8payloads occur3times in actual M6HTML; one shared outer table proposed, not implemented | evidence/asset-validation.json |
| Dimensions | 128x64RUproof / generic proposedportrait sizes | Observed maintained; proposed M7RU256x128with doubledanchors, portraits256square/chariot512x256; approved UI face sizes are not known exports | VISUAL_ASSET_REFERENCE.md§2/6/7 |
| Art direction | Oldpixel/animation/frames-as-universal assumptions | Static nonpixelated DarkDeco, selective framing, no player dropdowns or browserpagescroll, approved13tokens | Interim Bible0.4.0§2/4/7 |
| Fonts | Earlier Barlow/Atkinson suggestions | Bangers Regular +IM Fell English Regular approved; bodyface stillopen, actualfiles/licenses unavailable | Interim Bible0.4.0§5/10 |
| UIkit | Generic corner/frame brief | Master Buttonv2.0, AssetCardv1.0, Secondaryv1.0 approveddesign; originalassetsmissing. RemainingUIkitTBD. | Interim Bible0.4.0§6/7.2/8 |
| Purchase interaction | Contexttransaction button only | M7requires parentselection first on enabledPurchase; disabled doesneither. Existing source has no shared Market selection contract found. | src/management/player-pages.js:10 / context-actions.js:7 |
| Pool scope | Fewgeneric images; no cardinalities | Shared Owner/Driver portrait matrices;49/53template plan;395/866images+2/4fonts. No ancestry×nation×role explosion. | M7_ASSET_CATALOG_PLAN.csv |
| Deferred assets | Optional6frame animation,modularrig,shadow | RemainDEFER/TBD; static Bible doesnot require new frame timing/rig. Texture/effect/background targets optional. | VISUAL_ASSET_REFERENCE.md§4/8 |
| Validation | Oldtargetedreference approval | This audit44presentation tests and assetbyte validation; inherited1394M6regression notrerun; no Windowsacceptance inferred | evidence/presentation-tests.log |
| Copy drift | Oldplaceholdersdescriptions | Active label/control-vs-fatigue wording needs reconciliation; native behavior not changed | content/m6/active-rewards-v1.json / src/sim/environment.js |
## Old33IDs retained

| Old ID | Old family | M7 handling |
|---|---|---|
| A01 | Complete racing-unit sprite | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| A02 | Racing-unit primary livery mask | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| A03 | Driver portraits | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| A04 | Full stable/team emblem | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| A05 | Tiny emblem / reduced identity mark | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| A06 | Reusable Deco panel corner | Preserved in plan; OBSERVED_REUSE |
| A07 | Trackside tower / architectural cluster | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| A08 | Trackside arch / gateway module | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| A09 | Home Stable illustration | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| A10 | Owner portrait | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| B01 | Beast portraits | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| B02 | Chariot inspection / roster illustrations | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| B03 | Staff / specialist portraits | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| B04 | Equipment / inventory item images | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| B05 | Barn driver/beast/chariot slot illustrations | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| B06 | Active Legacy perk icons and empty slot | Preserved in plan; OBSERVED_REUSE |
| C01 | Strategy Sign icons | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| C02 | Tactical-map entrant symbols | Preserved in plan; OBSERVED_REUSE |
| C03 | Wreck / disabled RU overlay | Preserved in plan; PROPOSED_TARGET_OPTIONAL |
| C04 | Dust / impact / event effects | Preserved in plan; PROPOSED_TARGET_OPTIONAL |
| C05 | Hazard indicator imagery | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| C06 | Terrain surface textures | Preserved in plan; PROPOSED_TARGET_OPTIONAL |
| C07 | Course start/finish/checkpoint sign artwork | Preserved in plan; OBSERVED_REUSE |
| C08 | Run Reward card icons | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| C09 | Permanent Legacy Upgrade card icons | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| C10 | Championship insignias / trophy images | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| C11 | Facilities / service illustrations | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| C12 | New Game cosmetic emblem choices / Options wheel | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| D01 | RU locomotion frames / atlas | Preserved in plan; DEFER |
| D02 | Modular race component layers | Preserved in plan; DEFER |
| D03 | Ground contact shadow | Preserved in plan; DEFER |
| D04 | Title / menu background illustration | Preserved in plan; PROPOSED_M7_REQUIRES_CHANGE |
| D05 | Atmospheric backdrop / additional arena props | Preserved in plan; PROPOSED_TARGET_OPTIONAL |
New IDsE01–E12are audit categories, not native game IDs: brand,Master,Card,Secondary,Worldmaps,Worldsampleemblems,fonts,resourceglyphs,NoSign/Abilityutility,Denbackground,weather andpendingUIkit. Category C08is subdivided to include8ActiveAbilities; no additional duplicate ability files. Every source/production path is mapped by the plan and documentation-only filename table.

No old file was deleted, renamed or registered by the audit. Unknown original logo/SVG/font dimensions, pending bodyface/viewport/internalfeeds and unbound visual metadata remain explicitly unresolved. The sidecar pack pin now exists; do not reuse old “wait for pack pin implementation” advice. M7still cannot add fields/migrations to strict sidecar-v2 without separate approval.
