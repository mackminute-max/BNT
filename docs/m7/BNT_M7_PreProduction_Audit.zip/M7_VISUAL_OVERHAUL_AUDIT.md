# M7 visual overhaul pre-production audit

Audit date: **2026-11-25** (America/Los_Angeles). Audited commit: `0c29a65a7cf8bdf0ced1821eb59da314981507f6`; branch `feat/e5-d-m1-startup-slots-options`.

**OBSERVED** means verified source or a named audit probe. **PROPOSED M7 / REQUIRES CHANGE** is a recommendation, never an installed feature or approved quantity. **DEFER** is outside the initial visual scope. **UNKNOWN** is not silently estimated as a fact. All proposed tables are documentation, not runtime inputs.

## Executive finding

**Investigation complete; M7 production is not yet specified/authorized.** Keep the deterministic simulation, buffered Worker, native command/transaction authority and Canvas2D geometry. Add a presentation identity resolver, a bounded shared asset pipeline and a coherent UI shell through a vertical slice, then migrate screens incrementally. A CSS-only reskin cannot meet the approved no-dropdown/no-browser-page-scroll requirements.

Proposed catalog: **395images+2fonts minimum; 866images+4fonts target**. These are new logical production file slots, not unique drawings; **49/53templates** plus originals can fill compatible slots. No placeholder images have been generated. See the detailed reference/pool documents and filename map.

A concrete pre-existing **M6 driver recruitment defect** was verified in5isolated native purchases, without mutating any production save: each rejected `Invalid driver visual identity`, with no purchase effects. This blocks a complete recruitment/portrait continuity proof and should receive separate owner-authorized correction before M7 acceptance. The audit does not repair it.

## 1. Baseline and milestone status

- Repository `/workspace/BNT`, branch`feat/e5-d-m1-startup-slots-options`, commit`0c29a65a7cf8bdf0ced1821eb59da314981507f6` (“Deliver M6 career world, race interaction and gambling candidate”).
- Current HTML `dist/Blood-and-Thunder-M6-Playable.html`: **5,793,928bytes**, SHA-256`3bdfb86d06a59c1b9672f2adf716413f7d110e5e9b07f3d9c16d6c810255660c`. M6 is delivered/committed; owner Windows acceptance has not been independently recorded in this thread. Do not equate a push with acceptance.
- Pre-existing modified evidence: four files in `docs/m2-a`, `docs/m2-b`, `docs/persistence-foundation`; untracked M2-E readiness document and Python cache. They remain unchanged. Exact status and965protected-file hashes are in `evidence/repository_before.json` and final comparison.
- Build: vanilla JavaScript ES modules, Canvas2D, HTML/CSS, esbuild; embedded Worker/iframes and standalone HTML. Existing dev dependencies are esbuild/playwright-core; none installed. `scripts/m6/build.mjs` is the relevant entry, not default historical `npm run build`.
- Prior M6 reports cite1394full Node passes; that was prior milestone evidence, not rerun here. This audit ran44read-only presentation tests and image validation, not a complete gameplay acceptance suite. No new standalone build or migration was run.
- Governance: interim Bible0.4.0, old in-race guidance, old M3 references and33-category inventory read as reference layers; current native mechanics remain authoritative. Final Design Library/source SVG/font/logo exports are unavailable. No AGENTS.md was found for this checkout.

## 2. Findings and disposition

| ID | Priority/status | Finding | Evidence | Disposition |
|---|---|---|---|---|
| F01 | HIGH / verified defect | M6 driver acquisition rejects visual identity | 5/5in-memory native transactions failed after correct native capacity/quote; no Gold/personnel/save mutation. Old offer visual entry survives identity deletion. | Separate M6 corrective authorization; retest offer→owned sex/provenance, renewal, backup/reload. No fix in audit. |
| F02 | HIGH / potential continuity bug | Visual sex derived from a changed asset ID | driverVisuals hashes career+current ID; acquired owned ID differs from source offer. Actual sex transition cannot be observed because F01prevents commit. | Preserve existing offered sex when separately correcting; do not infer sex from names or change RNG. |
| F03 | BLOCKING intake | Final Bible and original library not provided | No three approved logo originals, Bangers/IM Fell files/licenses, button/card exports, settings/studies or slice metadata found. | Audit can conclude; exact export sizes/geometry and production registration must wait for originals. |
| F04 | BLOCKING pipeline | Current proof manifest and eager loader cannot host planned catalog | 64entries / temporary-proof status only / images eager / get does not reload evictions. | Versioned presentation registry and lazy/payload-shared loader proposal; explicit M7 implementation approval needed. |
| F05 | HIGH layout scope | Player dropdowns and long pages remain widespread | Owner nationality/ancestry/sex; hire terms; training/engineering; Legacy loadouts; Den teams/speed; Options selects. Management pages grow vertically. | Shared shell+direct-choice components, pagination/detail views; never hide inaccessible overflow. |
| F06 | OWNER design decision | Approved state fill contrast risk | Selected2.113:1, critical2.639:1without unsupplied outline/shadow. | Validate exact fonts/frames and obtain design disposition; no silent palette change. |
| F07 | MEDIUM metadata gap | Rival/local/Den driver sex; specialist ancestry/sex absent | No reliable sex field in displayIdentity/teamProfile; specialist generation exposes nativeRole but not ancestry/sex. | Neutral compatible fallback. New persisted data/guessed demographic distribution not authorized. |
| F08 | MEDIUM content mismatch | Old copy/briefs do not describe M6 rules/rewards | 14deferred notes vs29real Run rewards; old crossing activation vsM6nexttick; Steady Team wording/control-vs-fatigue mismatch; old paths absent. | Refresh copy against native version context; never use art/copy to change mechanics. |
| F09 | HIGH packaging risk | Same proof payload is repeated three times in standalone HTML | All8embedded image data URLs occur3times; current hash dedup is only pertable. | One immutable outer payload registry, safe iframe access/caching; no server. Test file-origin behavior. |
| F10 | OPEN acceptance | M6 acceptance and future supported viewport/feeds not confirmed | Interim Bible leaves body face, minimum viewport, fullscreen/internal scrolling and fitting rules open. | Owner decisions before production; recommend minimum1280x720with compact fallback and optional fullscreen. |
Code anchors: F01/F02 `src/career/m6/current.js:31` / `src/career/m6/schema.js:32`; F04 `src/presentation/contracts.js:3` / `src/presentation/assets.js:4`; F05 `src/management/player-pages.js:12` / `src/management/creation/m6-owner.js:4` / `src/management/m6-den.js:8`; F07 `src/career/m5/d2/generation.js:28`; F08 `src/sim/environment.js:122`.

## 3. Complete screen/consumer audit

| Screen | Source | Observed/current | Proposed/requires change |
|---|---|---|---|
| Startup/title/load | `src/management/startup/shell.js:12` | CSS/text title,3inline emblems/Options wheel; no supplied brand PNG | Brand/titlebackdrop/fonts; loadable/empty/error/uncertain slot variants; direct profile cards, no long page. |
| New Career / package compare | `src/management/creation/wizard.js:13` | Native inputs/selects and five package disclosures; M6 Owner helper adds4selects | Direct Owner/sex/nation/ancestry choices;13ancestry options paginate; preserve unlocked/locked/review/back/cancel/atomic creation. |
| Home Stable | `src/management/headquarters/consolidated.js:13` | Inline stable/Owner SVGs, resources, trophies, Legacy state | A09stable +shared portrait; unframed identity/accomplishments; preserve Go Race/Continue and actual counters. |
| Roster & Barn | `src/management/headquarters/consolidated.js:16` | Four symbol slots, owned-card monograms, active highlight | Shared portraits/beasts/chariot; pagination/legible condition; preserve third-beast explicit slot replacement and cancel/frozen registration. |
| Market / Legacy market | `src/management/player-pages.js:10` | Text/monograms; native preview Hire/Purchase; terms selects | Approved Card+Secondary; optional selected parent state before enabled Purchase; no disabled selection or transaction; complete terms in detail/confirm. F01blocks driver proof. |
| Staff & Contracts | `src/management/player-pages.js:28` | Role cards, employment states, renewal selectors | Neutral staff portraits; direct3term controls; expired/unavailable/payroll and release occupancy not obscured. |
| Workshop & Facilities | `src/management/player-pages.js:37` | 7text upgrade cards, equipment detach, engineering attribute selector | 7illustrations, generic equipment; segmented attributes/detail view; preserve capacities and live quotes. |
| Recovery & Services | `src/management/headquarters/workflow.js:7` | Work review plus native instantaneous service/training controls | 6service icons; no invented timed job queue/animation; keep injury/wear/integrity/contract eligibility and price. |
| Finances | `src/management/headquarters/workflow.js:6` | Treasury/obligations; old ledger code also supports historical schemas | Dense readable tables/aggregate facts; M6does not retain a full transaction archive. Do not invent missing lineitems. |
| Championship Events/Details/Registration | `src/management/career-race/flow.js:27` | M6generated board, native schedule/reward disclosures and team registration | 9marks/local-derivedbranding; full material schedule/fee access via explicit details/pages; no extra fee or altered offer. |
| Current championship/intermission/results | `src/management/championship-e5.js:5` | Trusted lifecycle, official/pending/blocked states | Reuse stateful HTML; all Run/completion choices, final settlement and AI continuation remain gated. Stage evidence is not an official result. |
| World | `src/management/m6-world.js:7` | 8long profiles and16div placeholder refs; fixed rivals/current locals | Nation tabs/cards+one selected detail panel; schematic512x320 and sampleemblem256. Preserve all paragraphs/status/counters through pagination. |
| Gambling parlor | `src/management/m6-den.js:8` | 3opportunities, dropdown-backed team choice, live odds/stake/returns | Team choicecards +emblems/neutral portraits; optional background; no fake events or promotional implication of guaranteed returns. |
| Den spectator race | `src/management/m6-den.js:9` | 900x400 Canvas overview+radio/standings/speed select | Styling/adapted common renderer only; no player Signs/abilities. Preserve actual skip-to-result simulation and no progression sideeffects. |
| Career race / Practice | `src/management/career-race/host.js:3` | Embedded viewer; generic portrait/emblem/RU +map/radio and eightM6buttons | Identity-aware art, selected abilityicon, safe mapLOD; retain native buffer/inputs, pause, speed and original-seed restart. |
| Run / completion selections | `src/management/m4.js:2` | Text3choice cards and confirmation; actual29Run definitions | 29icons; completion LP/Gold/Rep resource glyphs; keep replacement confirmation/eligibility/one selection. No old14placeholder imagery. |
| Career Records / Last Event | `src/management/m6-world.js:9` | 20row compact-summary pages; no lifetime full race viewer | Adaptive page size/detail; native net/gross and pending rewards accurate. Never fabricate historical telemetry. |
| Options / Save & Load / Help | `src/management/startup/shell.js:30` | Native dialog, tabs; save/load/import/backup/recovery/delete/help; some overflow/controls | Unobtrusive common shell; paginated career/backup lists; explicit destructive confirmations; accurate storage errors and unfinished race policy. |
| Confirmations / transient errors / recovery | `src/management/startup/dialogs.js:1` | Native dialog and role=status/error text | Exact selected action/updated quote visible; focus return/Escape/lost ack/stale storage; no new browser alerts. |
| Developer tools | `src/management/workspace.js:1` | Separate diagnostics and selectors | DEFER visual polish; clearly separated, not a loophole to retain player-facing dropdowns. |
All screens need explicit empty, unavailable/disabled, error, busy, long-label, large-roster and keyboard-focus treatment. Source inspection establishes consumers and branches, not visual acceptance at new dimensions. This audit did not play through every screen or create a browser career. Existing M6packaged screenshots/reports are historical evidence only.

## 4. Reuse and architecture advice

Reuse unchanged: deterministic simulation/AI/RNG, native course geometry, buffered Worker, CareerStore/IndexedDB authority, result D5/settlement/reward gates, safe native dialogs, existing quote/previews and offline single-file architecture. Reuse/adapt procedural tactical markers, shared world transforms, road tile caches, canvas sizing, emblems, escaping and accessible controls. Preserve old proofs as fallbacks, not approved finished art.

Requires change: presentation identity resolver, multi-RU/mask cache key, lazy asset loading, production-status/font intake, cross-iframe payload sharing, shared skin/component wrappers, direct-choice/pagination widgets, focus-safe routing and real art bindings for monograms/World/rewards. No framework/server/second race engine is needed. Shared shell with incremental screen migration is preferable to either a single giant rewrite or CSS-only patching.

A vertical slice should demonstrate one actual Market6card page at a large viewport, a compact3card page at minimum viewport, parent selection/Purchase native quote/confirmation, Barn/Owner portrait identity and one native race with sameidentity and exact8controls. Do not make all final art a prerequisite: one Human, Horse, staticRU+mask, emblem+mark, backdrop/stable template and approved UI sources can validate the pipeline; full49template coverage precedes claiming the whole minimum catalog is supported.

## 5. Validation actually performed

1. Git status/branch/HEAD and read-only965file input snapshot; no fetch/commit/build/source mutation. No hidden assumption that old a70ec6e/36b0048 describes current paths.
2. Read current manifest, build embedding, PNG/SVG validators, cache/renderer/DOM consumers; `embedAssets()` in memory validated all8file bytes/hashes/masters/licenses. Observed8unique payloads, no duplicates inside a table, each3times in actual current HTML.
3. `node --test tests/p2.test.js`: **44tests,44pass,0fail,exit0**, including geometry, DPR, cache, manifest, PNG, SVG rejection and offline scan contracts. No expected references edited.
4. Native current content/export enumeration in memory:16catalogs/256records, competition inputs, COPY counts and native reward IDs. Initial diagnostic import used a non-exported weather symbol and was corrected; no product change or false test pass.
5.5native in-memory driver purchase probes after authoritative capacity purchase:5rejections with no purchase state effects; this is a finding, not a passing recruitment suite. Initial facility payload typo was corrected to propertyId/upgradeId. Probe evidence includes exact operation shape.
6. sRGB fill-pair contrast arithmetic; no exact source SVG/font rendering claimed.
7. Filename/count validation, native key links, source citation existence, initial/final repository hash comparison; final evidence is separate.

Not executed: full Node/gameplay/browser suites, new build, Windowsfilelaunch, new art generation, M7renderer/performance proof or save migration. No network runtime resources or dependencies were introduced. No M6acceptance claim is made. All generated files are audit documents/proposed tables in `/workspace/deliverables/bnt-m7-audit`.

## 6. Owner review / stop

Approve a separate M6recruitment correction and metadata continuity test; supply completed Bible/library sources; decide bodyfont, viewport/internalfeed exceptions, contrast, catalog scope/pool window and proposed decoder/manifest budgets. The implementation plan provides bounded gates. Acceptance of this audit does not authorize M7production, placeholder filling or schema changes.

**No production source, tests, runtime catalogs/manifests, save schemas, assets or build configuration were changed.** Existing dirty files remain untouched. Stop after owner review.
