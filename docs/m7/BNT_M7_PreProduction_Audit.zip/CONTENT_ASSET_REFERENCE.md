# Blood and Thunder — Content Asset Reference (M7 audit refresh)

Audit date: **2026-11-25** (America/Los_Angeles). Audited commit: `0c29a65a7cf8bdf0ced1821eb59da314981507f6`; branch `feat/e5-d-m1-startup-slots-options`.

**OBSERVED** means verified source or a named audit probe. **PROPOSED M7 / REQUIRES CHANGE** is a recommendation, never an installed feature or approved quantity. **DEFER** is outside the initial visual scope. **UNKNOWN** is not silently estimated as a fact. All proposed tables are documentation, not runtime inputs.

## Authority and authoring boundary

This replaces the supplied M3-era reference as a technical inventory, not as a new gameplay specification. Existing source and accepted native contracts govern mechanics. The interim Visual Design Bible0.4.0 governs its settled presentation decisions; it is not the completed M7 implementation specification. The original canon beats AI summaries. No content catalog has been changed. M6 owner Windows acceptance is not recorded in the available thread; the repository proves delivery, not acceptance.

Use UTF-8 JSON, unique case-sensitive keys and IDs, finite numeric values, supported versions, escaped live text and immutable source provenance. Preserve `sources`, canonical IDs, native attribute names and protected prices. Reference mirrors and art briefs are not reducer inputs. Never add a native ID merely to give artwork a filename. Do not infer gameplay species from appearance or sex from a name.

Baseline artifact: `5,793,928` bytes, SHA-256 `3bdfb86d06a59c1b9672f2adf716413f7d110e5e9b07f3d9c16d6c810255660c`. Build entry: `scripts/m6/build.mjs:1`; package scripts still default to historical `scripts/build.mjs`, so `npm run build` alone is not the current M6 packaging entry. M6 current-state family: `src/career/m6/schema.js:2`; presentation sidecar-v1/v2 and immutable pack pin: `src/persistence/career-presentation.js:4`.

## 1. Native fixed families and live consumers

| Family | Enumerable count | Exact keys | Source | Consumer / authoring contract |
|---|---|---|---|---|
| Starting packages | 5 | traditional, beastmaster, mechanist, veteran, scrappy | `src/career/packages.js:7` | Creation comparison/review; authoritative contents/grants. Reuse live packagePreview; no illustrative grant claims. |
| Employment terms | 3 | short, standard, long | `src/career/economy/catalog.js:5` | Hire/renew; costs, wage multipliers and durations from quote, not copy. |
| Facilities | 7 | staff-quarters, expanded-stables, driver-quarters, chariot-bay, workshop, treatment-ward, training-grounds | `src/career/economy/catalog.js:6` | Workshop/Stable Progress; one illustration/key, no invented progression stages. |
| Paid services | 6 | driver-recovery, driver-treatment, beast-care, beast-treatment, chariot-repair, chariot-refurbishment | `src/career/economy/catalog.js:13` | Recovery/Services; treatment, recovery, repair and wear remain distinct. |
| Passive/immediate Run rewards | 21 | focused-training, combat-drills, iron-nerves, conditioning, veterinary, surefooted, reinforced, balanced, emergency-repairs, fittings, implements, harness, familiarity, aggressive, defensive, rapid-recovery, field-repairs, medical, sponsor, supplier, negotiation | `src/career/m4/catalog.js:5` | Actual stat, condition, purchase and Gold effects; not old placeholders. |
| Active Run abilities | 8 | thunder-burst, second-wind, brace, perfect-line, savage-assault, absolute-focus, catch-breath, steady-team | `src/sim/m6-interaction.js:3` | One run slot, one charge/race; new icons reuse in selected-ability button. |
| Legacy upgrades | 8 | recruiters, engineers, beastmaster, distinguished, dynasty, established, patron, strategist | `src/career/m4/catalog.js:28` | Five permanent +three equipped active;3slot images reuse same upgrade IDs. |
| Signs | 6 | Push the Pace, Conserve Strength, Seek Open Track, Race Defensively, Engage Rivals, Hold Position | `src/ai/signs.js:4` | Exact strings native; six instructions plus No Sign and Ability UI controls. |
| Weather | 5 | Clear, Rain, Heavy Rain/Mud, Dust/Wind, Extreme Heat | `src/sim/environment.js:5` | No new weather mechanics/odds; icon and copy only. |
| Incident kinds | 3 | debris, animal, spectator | `src/presentation/content/copy.generated.js:363` | Native event help; do not promise an injury or outcome. |
| Surface materials | 5 | dirt, gravel, sand, mud, stone | `src/presentation/geometry.js:3` | Current fills; optional future textures do not change grip. |
| Native economic contexts/trophy keys | 6 | dustroad, ironwheel, bannerfall, crownfire, thunder-crown, iron-gauntlet | `src/career/championships/e5/catalog.js:14` | Economic definitions still matter in M6; six fixed trophy IDs are not eight invented national trophies. |
### Actual native record examples (read-only, not new import formats)

**Facility staff-quarters**, `src/career/economy/catalog.js:6`:

```json
{
  "name": "Staff Quarters",
  "cost": 300,
  "capacity": "specialists",
  "amount": 2
}
```

**Treatment beast-treatment**, `src/career/economy/catalog.js:13`:

```json
{
  "registry": "beasts",
  "field": "injury",
  "cost": 80,
  "role": "Beast Handler",
  "ward": true
}
```

**Run reward focused-training**, `src/career/m4/catalog.js:5`:

```json
{
  "id": "focused-training",
  "name": "Focused Training",
  "category": "Driver Development",
  "kind": "stat",
  "target": "driver.driving",
  "amount": 5,
  "description": "+5 Driving for your driver.",
  "weight": 10
}
```

**Ability thunder-burst**, `src/sim/m6-interaction.js:3`:

```json
{
  "name": "Thunder Burst",
  "seconds": 5
}
```

**Traditional package**, `src/career/packages.js:7`:

```json
{
  "name": "Traditional",
  "gold": 1200,
  "drivers": [
    [
      50,
      50,
      50,
      50,
      50
    ]
  ],
  "beasts": [
    [
      50,
      50,
      50,
      50,
      50,
      50
    ],
    [
      50,
      50,
      50,
      50,
      50,
      50
    ]
  ],
  "chariot": [
    50,
    50,
    50,
    50,
    50
  ],
  "equipment": [
    "Standard harness",
    "Standard wheels"
  ],
  "facility": "Basic Stable"
}
```

### M6 copy mismatches and historical mirrors

`content/m6/active-rewards-v1.json` is a descriptive mirror: `catch-breath` is labeled “Catch Your Breath” there but runtime `ABILITIES` uses “Catch Breath”; `steady-team` similarly differs (“Steady the Team”/“Steady Team”). More importantly its Steady Team prose says control recovery while `integrateCondition` modifies eligible beast fatigue recovery. This audit does not change either. Have the design/content owner reconcile wording against native behavior before publishing claims. Do not use the mirror to silently change mechanics.

The old14 `run-*-notes`/`legacy-*-notes` records remain in generated explanatory copy but are not the current29 Run definitions or8 Legacy upgrades. Do not commission14 obsolete placeholder reward pictures. Completion reward choice is a separate generated LP/Gold/Reputation offer; reuse resource glyphs, not a new permanent-upgrade catalog.

Sources: `src/sim/environment.js:122`; `src/career/m4/progression.js:34`; `content/m6/active-rewards-v1.json`.

## 2. Procedural production inputs:16 catalogs,256 records

Current generated runtime source: `src/career/m5/content.generated.js:1`; original editable catalog files under `content/m5/v1/catalogs/`, with schemas `content/m5/v1/schemas/M5_Audit_Content_Schemas.json` and supplemental metadata schema. `generateIdentity` consumes them at `src/career/m5/generation.js:17`. Author amendments through versioned content work, never overwrite original accepted bytes.

| Family | Count | Native record IDs | Fields of actual first record |
|---|---|---|---|
| ancestryGameplay | 13 | ancestry.a01, ancestry.a02, ancestry.a03, ancestry.a04, ancestry.a05, ancestry.a06, ancestry.a07, ancestry.a08, ancestry.a09, ancestry.a10, ancestry.a11, ancestry.a12, ancestry.a13 | id, version, label, sources, canonicalAncestryId, subdivisionId, baseline, ancestryDelta, individualVariation, correlations, backgroundWeights, experienceDelta, qualityProfileId, age, visualProfileId, eligibility, rarityWeight |
| beastBloodline | 39 | stock.b01.1-1, stock.b01.1-2, stock.b01.1-3, stock.b01.1-4, stock.b01.1-5, stock.b01.1-6, stock.b01.1-7, stock.b02.2-1, stock.b02.2-2, stock.b02.2-3, stock.b02.2-4, stock.b03.3-1, stock.b03.3-2, stock.b03.3-3, stock.b03.3-4, stock.b04.4-1, stock.b04.4-2, stock.b04.4-3, stock.b04.4-4, stock.b05.5-1, stock.b05.5-2, stock.b05.5-3, stock.b05.5-4, stock.b06.6-1, stock.b06.6-2, stock.b06.6-3, stock.b06.6-4, stock.b07.7-1, stock.b07.7-2, stock.b07.7-3, stock.b07.7-4, stock.b08.8-1, stock.b08.8-2, stock.b08.8-3, stock.b08.8-4, stock.b09.9-1, stock.b09.9-2, stock.b09.9-3, stock.b09.9-4 | id, version, label, sources, canonicalSpeciesId, sourceLocalId, classification, statDelta, physicalVariantTags, temperamentWeights, rarityWeight, visualProfileId |
| beastSpecies | 9 | species.b01, species.b02, species.b03, species.b04, species.b05, species.b06, species.b07, species.b08, species.b09 | id, version, label, sources, canonicalSpeciesId, baseline, individualVariation, stockProfileIds, temperamentWeights, qualityProfileId, age, compatibility, visualProfileId, eligibility, nativeSpeciesAdapter |
| beastTemperament | 8 | temperament.steady, temperament.spirited, temperament.aggressive, temperament.nervous, temperament.stubborn, temperament.eager, temperament.tireless, temperament.docile | id, version, label, sources, temperament, attributeDelta, description, unsupportedClaims, independentAI |
| chariotNaming | 8 | chariot.n1, chariot.n2, chariot.n3, chariot.n4, chariot.n5, chariot.n6, chariot.n7, chariot.n8 | id, version, label, sources, namingProfileId, manufacturers, modelNames, nicknames, format, mechanicalTemplateReference, inventStats |
| culturalNaming | 35 | culture.n1.r1, culture.n1.r2, culture.n1.r3, culture.n1.r4, culture.n1.r5, culture.n1.r6, culture.n2.r1, culture.n2.r2, culture.n2.r3, culture.n3.r1, culture.n3.r2, culture.n3.r3, culture.n3.r4, culture.n4.r1, culture.n4.r2, culture.n4.r3, culture.n5.r1, culture.n5.r2, culture.n5.r3, culture.n5.r4, culture.n6.r1, culture.n6.r2, culture.n6.r3, culture.n6.r4, culture.n6.r5, culture.n7.r1, culture.n7.r2, culture.n7.r3, culture.n7.r4, culture.n7.r5, culture.n8.r1, culture.n8.r2, culture.n8.r3, culture.n8.r4, culture.n8.r5 | id, version, label, sources, canonicalNationIds, ancestryAffinityIds, language, given, family, clan, nicknames, titles, beastNames, organizationRoots, organizationEndings, grammar, nicknameProbability, maxNameLength, collisionPolicy, maxRetries |
| driverAI | 10 | ai.technical, ai.brawler, ai.daredevil, ai.endurance, ai.opportunist, ai.defensive, ai.professional, ai.showboat, ai.front-runner, ai.patient-pursuer | id, version, label, sources, archetype, traits, individualVariation, influences, unsupportedClaims, preserveGlobalAI |
| driverBackground | 8 | background.courier, background.circuit, background.handler, background.arena, background.rally, background.marshal, background.festival, background.hauler | id, version, label, sources, attributeDelta, experienceLevels, aiProfileWeights, eligibility |
| equipmentNaming | 8 | equipment.n1, equipment.n2, equipment.n3, equipment.n4, equipment.n5, equipment.n6, equipment.n7, equipment.n8 | id, version, label, sources, namingProfileId, manufacturers, modelNames, nicknames, format, mechanicalTemplateReference, inventStats |
| nation | 8 | nation.n1, nation.n2, nation.n3, nation.n4, nation.n5, nation.n6, nation.n7, nation.n8 | id, version, label, sources, canonicalNationId, ancestryWeights, cultureWeights, backgroundWeights, aiWeights, staffWeights, speciesWeights, stockWeights, qualityWeights, namingProfileId, teamIdentityProfileId, visualProfileId, importWeight, racingTraditions, equipmentPreferences, economicPolicy |
| qualityRarity | 5 | quality.affordable, quality.ordinary, quality.specialized, quality.rare, quality.exceptional | id, version, label, sources, tier, ratingBounds, driverDelta, beastDelta, weight, valuation, cap, rarityLabel, budgetPolicy |
| rivalGeneration | 40 | rival.n1.dustroad, rival.n1.ironwheel, rival.n1.bannerfall, rival.n1.crownfire, rival.n1.thunder-crown, rival.n2.dustroad, rival.n2.ironwheel, rival.n2.bannerfall, rival.n2.crownfire, rival.n2.thunder-crown, rival.n3.dustroad, rival.n3.ironwheel, rival.n3.bannerfall, rival.n3.crownfire, rival.n3.thunder-crown, rival.n4.dustroad, rival.n4.ironwheel, rival.n4.bannerfall, rival.n4.crownfire, rival.n4.thunder-crown, rival.n5.dustroad, rival.n5.ironwheel, rival.n5.bannerfall, rival.n5.crownfire, rival.n5.thunder-crown, rival.n6.dustroad, rival.n6.ironwheel, rival.n6.bannerfall, rival.n6.crownfire, rival.n6.thunder-crown, rival.n7.dustroad, rival.n7.ironwheel, rival.n7.bannerfall, rival.n7.crownfire, rival.n7.thunder-crown, rival.n8.dustroad, rival.n8.ironwheel, rival.n8.bannerfall, rival.n8.crownfire, rival.n8.thunder-crown | id, version, label, sources, identityProfileId, driverAncestryWeights, driverAIWeights, beastSpeciesWeights, qualityWeights, staffProfileIds, chariotNamingProfileId, equipmentNamingProfileId, beastCount, persistence, championshipDifficultyReference, personalityFreeze, simulateOffscreenEconomy |
| rivalIdentity | 8 | team.n1, team.n2, team.n3, team.n4, team.n5, team.n6, team.n7, team.n8 | id, version, label, sources, canonicalNationId, cultureProfileId, namingProfileId, organizationNameMode, racingPhilosophy, visualProfileId |
| staffExpertise | 3 | expertise.developing, expertise.practiced, expertise.veteran | id, version, label, sources, tier, valuation, experienceDescription, specializationTags, mechanicalScaling |
| staffProfession | 24 | staff.handler.n1, staff.mechanic.n1, staff.physician.n1, staff.handler.n2, staff.mechanic.n2, staff.physician.n2, staff.handler.n3, staff.mechanic.n3, staff.physician.n3, staff.handler.n4, staff.mechanic.n4, staff.physician.n4, staff.handler.n5, staff.mechanic.n5, staff.physician.n5, staff.handler.n6, staff.mechanic.n6, staff.physician.n6, staff.handler.n7, staff.mechanic.n7, staff.physician.n7, staff.handler.n8, staff.mechanic.n8, staff.physician.n8 | id, version, label, sources, nativeRole, expertiseProfileIds, namingProfileId, serviceIds, newMechanicalSkills, eligibility |
| visualMetadata | 30 | visual.a01, visual.a02, visual.a03, visual.a04, visual.a05, visual.a06, visual.a07, visual.a08, visual.a09, visual.a10, visual.a11, visual.a12, visual.a13, visual.b01, visual.b02, visual.b03, visual.b04, visual.b05, visual.b06, visual.b07, visual.b08, visual.b09, visual.n1, visual.n2, visual.n3, visual.n4, visual.n5, visual.n6, visual.n7, visual.n8 | id, version, label, sources, style, ancestryIds, speciesIds, ageCategories, bodyTags, hairTags, facialHairTags, skinOrCoatPalette, markings, clothingTags, culturalAccessoryTags, professionTags, heraldicMotifs, teamPalette, chariotLiveryTags, portraitAssetIds, spriteAssetIds, fallbackAssetId, assetResolution |
The13 ancestry records include Hill/Mountain Dwarf and Forest/High/Sea Elf as separate native IDs, not additional generic Dwarf/Elf IDs. Drivers use ancestry/background/experience/quality to derive attributes and AI profiles to derive personality. Cultures35 and AI profiles10 are NOT mandatory portrait Cartesian axes. All catalog fields above are real; only fields used by a consumer are runtime authority. Visual metadata30 includes13 anatomy profiles,9species profiles and8national profiles; `portraitAssetIds`/`spriteAssetIds` are not proof that files exist. Empty arrays and an old generic fallback remain common. Age, hair, coat, profession and motif tags are guidance, not installed customization controls.

**Actual ancestryGameplay field projection** (not a complete import record), `content/m5/v1/catalogs/ancestryGameplay.json:1`:

```json
{
  "id": "ancestry.a01",
  "version": 1,
  "label": "Human",
  "canonicalAncestryId": "A01"
}
```

**Actual beastSpecies field projection** (not a complete import record), `content/m5/v1/catalogs/beastSpecies.json:1`:

```json
{
  "id": "species.b01",
  "version": 1,
  "label": "Horse",
  "canonicalSpeciesId": "B01",
  "stockProfileIds": [
    "stock.b01.1-1",
    "stock.b01.1-2",
    "stock.b01.1-3",
    "stock.b01.1-4",
    "stock.b01.1-5",
    "stock.b01.1-6",
    "stock.b01.1-7"
  ]
}
```

**Actual beastBloodline field projection** (not a complete import record), `content/m5/v1/catalogs/beastBloodline.json:1`:

```json
{
  "id": "stock.b01.1-1",
  "version": 1,
  "label": "Heavy draft",
  "canonicalSpeciesId": "B01",
  "sourceLocalId": "1.1",
  "classification": "descriptive_stock_style"
}
```

**Actual staffProfession field projection** (not a complete import record), `content/m5/v1/catalogs/staffProfession.json:1`:

```json
{
  "id": "staff.handler.n1",
  "version": 1,
  "label": "Beast Handler — Northreach Confederation",
  "nativeRole": "Beast Handler"
}
```

**Actual visualMetadata field projection** (not a complete import record), `content/m5/v1/catalogs/visualMetadata.json:1`:

```json
{
  "id": "visual.a01",
  "version": 1,
  "label": "Human anatomy metadata",
  "ancestryIds": [
    "A01"
  ],
  "speciesIds": [],
  "portraitAssetIds": [],
  "spriteAssetIds": [],
  "fallbackAssetId": "portrait.generic.marker.v1"
}
```

## 3. Renewable identities and metadata coverage

| Family | Actual identity/fields | Eligibility / generation | Art linkage and fallback |
|---|---|---|---|
| Drivers | m6.identities[id]: ancestryId, ancestryLabel, backgroundId, aiProfileId, attributes, personality, contextFingerprint; m6.driverVisuals[id]:version/sex | 13ancestries; male/female fresh visual hash; unspecified accepted compatibility value. Quality/ownership/contracts still govern entry. | Match ancestry+known sex, otherwise ancestry-neutral; do not infer from names. |
| Owners | m6.owner:{version,nationality,ancestry,sex,startingNation} | N1–N8; A01–A13; male/female. N5 selects an ordinary starting nation. | Share character pool with role-neutral clothing; no new save fields needed for deterministic lookup. |
| Specialists | nativeRole, staffProfileId, expertiseProfileId; no generated ancestryId/sex | 24national profession profiles, only Beast Handler/Mechanic/Physician native functions | Neutral occupational portraits. Fixed authored metadata may permit a more specific depiction; do not assume all staff Human. |
| Beasts | speciesId, speciesLabel, stockProfileId/Label, temperamentId; native base species can still say generic_draft_beast | 9canonical species;39stocks; same-species pair and affinity already mechanical | Art follows canonical metadata/affinity, never changes them. Generic same-species stock silhouette is safe. |
| Chariots | category, qualityProfileId, naming/valuation; native weight, capacity and5attributes | 8national naming profiles;3native tiers; no fixed light/heavy class enum | Generic chassis art/palette variants; no invented class statistics. |
| Equipment | category, qualityProfileId, manufacturer/model name; native mass/combat | 6base source offers,8national naming profiles; no reliable generated subtype field | Generic hardware until a display-only subtype mapping is approved. |
| Rival organizations | organization.id, driver/memberIds, native, nation, ancestry, species | 4persistent profiles/nation lazy-born, up to32/career; select2 +locals as field permits | Use stable organization/member IDs. Local/rival/Den drivers have no guaranteed sex metadata; neutral portraits. |
| Local/Den teams | Frozen scheduled entrant IDs, names, setup, affinity; disposable after allowed closure | Native generator, not an offscreen economy; Den3committed opportunities | Bounded reusable emblem/RU pools, not a file per infinite generated entrant. |
Identity sources: `src/career/m6/current.js:20`, `src/career/m5/generation.js:17`, `src/career/m5/d2/generation.js:18`, `src/career/m6/den.js:10`, `src/management/creation/m6-owner.js:4`.

### Verified recruitment blocker — no fix authorized

Five isolated in-memory Traditional-career native M6 driver acquisitions failed `Invalid driver visual identity`, after valid capacity purchase and quote. All five left purchase bytes, treasury and personnel unchanged. In `transactM6`, acquired identity is moved from offer ID to owned asset ID and the old identity is deleted; the old `driverVisuals` entry is not deleted with it. Cold validation requires every visual entry to have a matching driver identity. This prevents the purchase from publishing. Evidence: `evidence/identity-handoff-probe.json`.

If that rejection is separately corrected, sex continuity still needs an explicit test: `driverVisuals()` hashes the new owned ID, rather than reusing the offer's visual metadata. Do not report a sex change as observed—the transaction currently never commits. Do not auto-repair existing saves or add a visual schema under this audit. Owner should authorize a narrow M6 corrective pass before relying on M7 recruitment acceptance.

`src/career/m6/current.js:31`; `src/career/m6/schema.js:32`; `src/persistence/m6/store.js:19`.

## 4. Championships, tracks and World

The v1.1 reference competition catalog has121venues,72events,40competition profiles,35cultural/subregion profiles,18geometry bindings and8regional market profiles; these are generator inputs, not one bespoke image each. Runtime material: `src/career/m5/d2/content.generated.js:1`, `content/m5/v1.1/competition-catalog-v1.1.json`. M6 constructs its own national board at `src/career/m6/world.js:25`.

M6 uses `m6-intro`, renewable `m6-local-<fingerprint>` definitions and `m6-prestige-N1` through `m6-prestige-N8`. Three locals until two local wins, then two locals+fixed Prestige; completed ordinary nations keep reduced-repeat locals. Sundaran requires all seven ordinary Prestige victories, with Iron Gauntlet economics and accepted Thunder Crown generation strength. Do not restore Bannerfall qualification through an art/copy change. The six original economic contexts are not the current visible six-signature board.

Native course keys are three ovals, C01–C12, plus distinct legacy technical-circuit/fast-circuit/mixed-rally/technical-rally keys. Generated Rally uses actual normalized course definitions with segments, distances and checkpoints; cannot be replaced with a static entire-track bitmap. The19 old track-copy keys are descriptions, not aliases. M6 short loops/C01 minimum3laps, other loops≥2, Rally point-to-point. Preserve exact course IDs and current frozen schedule.

M6 World supplies8canonical profiles,8schematic-map briefs and8illustrative team-emblem briefs. Exact IDs are `world.map.n1.v1`…`world.map.n8.v1` and `world.team.n1.v1`…`world.team.n8.v1`. They are `<div data-asset-ref>` placeholders, NOT registered image files. Their production brief dimensions are512×320 and256×256 SVG. Missing/ambiguous capitals and numerical populations remain explicit unknowns; do not commission maps with invented political borders.

`src/track/catalog.js:3`; `src/track/rally-generator.js:1`; `src/career/m6/world.js:16`; `src/management/m6-world.js:7`; `content/m6/world-profiles-v1.json:1`, `content/m6/world-asset-briefs-v1.json:1`.

## 5. Copy, radio, interface families and actual source paths

| Compiled copy family | Records / exact keys | Current interpretation |
|---|---|---|
| packages | 5: traditional, beastmaster, mechanist, veteran, scrappy | Live text; retain keys, context and escaped labels |
| championships | 6: dustroad, ironwheel, bannerfall, crownfire, thunder-crown, iron-gauntlet | Historical/contextual copy; mechanics always native |
| contracts | 3: short, standard, long | Live text; retain keys, context and escaped labels |
| facilities | 7: staff-quarters, expanded-stables, driver-quarters, chariot-bay, workshop, treatment-ward, training-grounds | Live text; retain keys, context and escaped labels |
| services | 6: driver-recovery, driver-treatment, beast-care, beast-treatment, chariot-repair, chariot-refurbishment | Live text; retain keys, context and escaped labels |
| ui | 12: new_career_empty, package_commit, market_fixed, ru_composition, service_locked, contract_expiry, reward_pending, reward_credited, reward_deferred, legacy_slots, race_results, load_warning | Historical/contextual copy; mechanics always native |
| incidents | 3: debris, animal, spectator | Live text; retain keys, context and escaped labels |
| rewards | 14: run-driver-notes, run-beast-notes, run-chariot-notes, run-equipment-notes, run-racing-notes, run-support-notes, run-opportunity-notes, legacy-stable-notes, legacy-owner-notes, legacy-invitation-notes, legacy-recruitment-notes, legacy-package-notes, legacy-facility-notes, legacy-distinction-notes | Historical/contextual copy; mechanics always native |
| tracks | 19: short-oval, oval, grand-oval, C01, C02, C03, C04, C05, C06, C07, C08, C09, C10, C11, C12, technical-circuit, fast-circuit, mixed-rally, technical-rally | Live text; retain keys, context and escaped labels |
| signs | 6: Push the Pace, Conserve Strength, Seek Open Track, Race Defensively, Engage Rivals, Hold Position | Live text; retain keys, context and escaped labels |
| weather | 5: Clear, Rain, Heavy Rain/Mud, Dust/Wind, Extreme Heat | Live text; retain keys, context and escaped labels |
| raceIncidents | 3: debris, animal, spectator | Live text; retain keys, context and escaped labels |
Old paths `content/batch02`, `content/batch03`, `content/batch04` do not exist in this checkout. Actual retained copy lives under `content/presentation/m3-a/batch02/` and `batch04/`, compiled into `src/presentation/content/copy.generated.js:1`, read by `src/presentation/content/copy.js:8`. Current23 authored identities live in `content/e5-d/m3-bc/RECRUITMENT_IDENTITIES.json`; counts: 5 drivers, 6 beasts, 3 chariots, 3 specialists, 6 equipment. The immutable pack pin is implemented now, unlike the old draft-only reference. Native generated ancestry/species still wins over cosmetic legacy descriptors.

Radio has22standard display-template families plus1special `DIRECTIVE_RESISTANCE` path: `src/presentation/content/m3-bc.js:41`, `content/e5-d/m3-bc/COMMENTARY_TEMPLATES.json`, `COMMENTARY_SPECIAL_PATH.json`. Exact standard keys: RACE_STARTED, OVERTAKE, LEAD_CHANGED, CONTACT, ATTACK, DAMAGE, CONTROL_CHANGED, RU_RETIRED, WRECK_CREATED, WRECK_IMPACT, INCIDENT, INCIDENT_CLEARED, SIGN_ACTIVATED, COURSE_ENTERED, SEGMENT_ENTERED, CHECKPOINT_CROSSED, FINAL_LAP, RU_FINISHED, RU_EXITED, RACE_STALLED, RACE_ENDED, INTEGRITY_ERROR. Do not add a reporter event for an icon. M6 abilities can emit native events without an alternate commentary mapping; retain existing reporter fallback, do not manufacture additional lines.

The visual requirement total must not be inferred from copy count: the original M5 metadata file actually contains55art-production briefs, not55registered images. The current manifest registers11entries, only8external image files. The old33-category inventory is a separate classification, not another55files. These three counts must never be summed.

UI text families include startup/errors, package review, roster eligibility, material hire/purchase terms, facilities/services/training, championship phases, wagers/odds/returns, pending Run/completion choices, World status, compact records, save/import/recovery/delete and Options/Help. Many strings are inline JavaScript, not centralized in COPY. Inventory and localize them separately before reskinning, with native state gates preserved. No fixed count of all UI labels is asserted.

## 6. Validation / authoring status

Source/catalog counts and actual examples are recorded in audit evidence;44presentation/asset tests passed in this audit. Full M6 regression evidence exists from the prior delivery but was NOT rerun by this read-only audit. For future content edits validate IDs, sources/hashes, source family schemas, mechanical-vs-copy separation, token sets, eligibility and field types, then compile through the existing authorized generators. For M7 art validate native-key resolution without modifying any generation probabilities, attributes, prices, champion definitions or protected history.

Authoring priorities: reconcile active reward/Sign wording; connect existing native identity tags; define neutral fallbacks; supply completed Bible/UI library/logo/font files; clarify equipment art subtype labels. No M7 gameplay catalogs, migrations, new races, nations, ancestries or services are proposed.
