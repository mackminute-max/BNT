# Blood and Thunder — M7 audit return

Date: 2026-11-25 (America/Los_Angeles). Audited commit: `0c29a65a7cf8bdf0ced1821eb59da314981507f6`.

## Actual read-only commands / diagnostics

- `git status --short`, `git log -1`, `git rev-parse HEAD`, `git ls-files -co --exclude-standard`: inspection/snapshot, exit0. No fetch/stage/commit/push.
- Python ZipFile extraction of the supplied handoff to `/workspace/attachments/m7-audit`; read all governing task/return/Bible documents and relevant old reference sections. No production paths written.
- `node --input-type=module` importing `embedAssets()` from `scripts/p2/assets.mjs`: validated8real images/master hashes and checked payload occurrences in existing HTML; exit0; no build writes.
- `node --test tests/p2.test.js`:44pass/0fail/exit0; raw log/exit retained.
- Read-only native/catalog exports through `node --input-type=module`: counts/keys/examples written to audit evidence only. One initial import requested a nonexistent weatherProfiles export (exit1); corrected inspection used weatherPresets and produced current facts.
-5in-memory native fixtures using `fixture(traditional,m7-sex-audit-0..4)`, M6CareerStore(Map), native facility.purchase(propertyId,upgradeId), then market.acquire(offerId,standard): all5driver acquisitions rejected with no purchase effects. This is a confirmed finding, not a passing gameplay suite. Initial incorrect facility payload was corrected before the recorded probe.
- Contrast arithmetic on supplied exact palette hex values: diagnostic only, not a rendered font/outline test.
- Documentation CSV expansion/count/path checks and protected-input SHA-256 comparison:870unique target paths/397minimum,176plan strata,965input hashes unchanged and exact Git status preserved. No image files, runtime catalogs or pipeline implementations were produced.

## Reproduce the finding without any disk saves

From repository root, use Node ES modules and import `fixture` from `scripts/e5-d/m4/fixture.mjs`, `M6CareerStore` from `src/persistence/m6/store.js`, `actionCommand` from `src/management/model.js`. Create a fresh Traditional fixture with suffix `m7-sex-audit-0`; create a new M6store backed exclusively by a new Map, Owner `{version:1,nationality:N1,ancestry:A01,sex:female,startingNation:N1}` (string values). Purchase `driver-quarters` on the fixture's first property with the native facility command. Select the first driver offer and save store.raw/treasury/personnel count. Apply native `market.acquire` with `term:standard`. Expect `Invalid driver visual identity`, unchanged raw/Gold/personnel. Repeat suffixes1..4. Use the source-defined command builder; do not directly edit protected fields or use an actual owner store.

This audit did not run full M6regression, create a browser career, build an artifact, launch Windowsfile://, generate art or install dependencies.
