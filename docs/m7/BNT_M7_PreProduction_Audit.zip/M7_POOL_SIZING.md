# M7 pool sizing and file-count reconciliation

Audit date: **2026-11-25** (America/Los_Angeles). Audited commit: `0c29a65a7cf8bdf0ced1821eb59da314981507f6`; branch `feat/e5-d-m1-startup-slots-options`.

**OBSERVED** means verified source or a named audit probe. **PROPOSED M7 / REQUIRES CHANGE** is a recommendation, never an installed feature or approved quantity. **DEFER** is outside the initial visual scope. **UNKNOWN** is not silently estimated as a fact. All proposed tables are documentation, not runtime inputs.

## Recommendation and definitions

The current game can function with no new artwork; the following minimum means complete replaceable-catalog coverage, not the fewest images needed to draw any playable screen. Recommend planning the full target catalog upfront, filling unpainted compatible slots from templates later. **Minimum 395PNG/SVG files+2fonts=397new files; target 866+4=870.** These are proposed quantities, not approved requirements and not generated assets. Minimum includes49distinct silhouette/technical templates; target53. Of these one is a technical livery mask, so48/52are pictorial templates. There are also4approved UI geometry masters yielding21state exports and3approved logo originals—reuse, not silhouette generation. Assuming every state/logo is a distinct payload gives73/77unique placeholder image payloads, before2/4fonts. Masters, license records, metadata and source documents are not counted as image files.

“Logical file” is a finite catalog pool slot or fixed art role, NOT a generated person/offer UUID. Separate files may have identical bytes. Minimum/target refer to alternative initial catalog scopes; target includes optional background/effects/texture additions and two proposed body fonts. The unfinished dividers/modular/animation families have unknown quantities and are excluded, not counted as zero.

The existing8proof files/3builtin entries stay unchanged. If retained in the future unified registry, target870new entries+11legacy entries=881logical entries, not64. Font intake may be a separate registry section. No cap is changed here.

## 1. Driver ancestry×sex and shared Owner matrix

Actual labels: `src/model/affinity.generated.js:1`. Driver sex validation: `src/career/m6/schema.js:28`; Owner validation: `src/career/m6/schema.js:23`. Current generator fresh owned/offer drivers use male/female. `unspecified` is a supported driver compatibility value, not an Owner choice. Rivals/local/Den lack guaranteed sex; missing values resolve to neutral art without writing a new enum into saves. All26male/female ancestry groups are supported; there are no extra generic Dwarf/Elf ancestry IDs or inferred nonbinary generation rules.

| Native ancestry | Label | Male min/target | Female min/target | Neutral min/target | Subtotal min/target |
|---|---|---|---|---|---|
| A01 | Human | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A02 | Orc | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A03 | Goliath | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A04 | Hill Dwarf | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A05 | Mountain Dwarf | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A06 | Halfling | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A07 | Forest Elf | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A08 | High Elf | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A09 | Sea Elf | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A10 | Gnome | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A11 | Goblin | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A12 | Dragonkin | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
| A13 | Tortle | 4 /12 | 4 /12 | 1 /2 | 9 /26 |
Arithmetic:13×2×4=104known-sex minimum portraits;13neutral=117total. Target13×2×12=312known-sex+26neutral=338. Thirteen sex-neutral anatomical templates can fill all39strata while finished male/female/neutral art is added. Do not draw a visibly male/female template and label it as the opposite sex.

Owners:26eligible ancestry×sex groups share the same104/312known-sex files, so **0additional Owner files**. Each group still offers4/12compatible options. Shared portraits need role-neutral clothing; race-specific helmet/rein action portraits cannot automatically become Owner art. Older unknown Owner metadata uses a neutral medallion or ancestry-neutral bust, never an assumed male Human. Owner nationality8 is an optional cultural art tag, not another×8 multiplier.

At maximum eight race entrants, some neutral-rival repetition will occur with one neutral image/group. That is accepted as an MVP tradeoff; target2neutral reduces exact repetition but does not guarantee uniqueness. No collision-free assignment is promised from stateless hashes.

## 2. Beast species/stock matrix

| Canonical species | Native label | Stock profiles | Min(1/stock) | Target(3/stock) | Template |
|---|---|---|---|---|---|
| B01 | Horse | 7 | 7 | 21 | T-beast-B01 |
| B02 | Storm Elk (Hroven) | 4 | 4 | 12 | T-beast-B02 |
| B03 | Crown Boar (Brond) | 4 | 4 | 12 | T-beast-B03 |
| B04 | Meadowstrider (Vellin) | 4 | 4 | 12 | T-beast-B04 |
| B05 | Racing Ram | 4 | 4 | 12 | T-beast-B05 |
| B06 | Grun’Jho | 4 | 4 | 12 | T-beast-B06 |
| B07 | Dire Wolf | 4 | 4 | 12 | T-beast-B07 |
| B08 | Wingless Drake | 4 | 4 | 12 | T-beast-B08 |
| B09 | Sunhorn (Saelor) | 4 | 4 | 12 | T-beast-B09 |
39stock profiles: Horse7, eight other species4each;7+8×4=39minimum;3×39=117target. Nine species silhouettes initially suffice; stock-profile and coat/tack details are not another species. Preserve species as mandatory anatomy; stock may use its species-neutral fallback if detailed morphology is not reviewed. Neither beast sex nor new breed IDs are generated for M7. Same-species pair legality and117affinity combinations remain source mechanics, not art selection rules to change.

## 3. Other pools, fixed assets and derivatives

| Family group | Minimum files | Target files | Kind |
|---|---|---|---|
| A01 race RU | 9 | 27 | pool |
| A02 race RU | 9 | 27 | paired derivative |
| A03 character | 117 | 338 | shared pool |
| A04 organization/world | 32 | 64 | pool |
| A05 organization/world | 32 | 64 | paired derivative |
| A07 architecture | 1 | 4 | pool |
| A08 architecture | 1 | 4 | pool |
| A09 stable | 1 | 8 | pool |
| B01 beast | 39 | 117 | pool |
| B02 chariot | 3 | 12 | pool |
| B03 specialist | 12 | 24 | pool |
| B04 equipment | 6 | 12 | pool |
| C01 sign | 6 | 6 | fixed |
| C03 presentation | 0 | 1 | fixed |
| C04 presentation | 0 | 3 | pool |
| C05 incident | 3 | 3 | fixed |
| C06 presentation | 0 | 5 | pool |
| C08 run-reward | 29 | 29 | fixed |
| C09 legacy | 8 | 8 | fixed |
| C10 championship-insignia | 9 | 9 | fixed |
| C10 trophy | 6 | 6 | fixed |
| C11 contract | 3 | 3 | fixed |
| C11 facility | 7 | 7 | fixed |
| C11 service | 6 | 6 | fixed |
| D04 presentation | 1 | 3 | pool |
| D05 presentation | 0 | 16 | pool |
| E01 brand | 3 | 3 | fixed |
| E02 ui-design | 12 | 12 | fixed |
| E03 ui-design | 4 | 4 | fixed |
| E04 ui-design | 5 | 5 | fixed |
| E05 organization/world | 8 | 8 | fixed |
| E06 organization/world | 8 | 8 | fixed |
| E07 font | 2 | 4 | fixed |
| E08 resource | 8 | 12 | fixed |
| E09 race-utility | 2 | 2 | fixed |
| E10 presentation | 0 | 1 | fixed |
| E11 weather | 5 | 5 | fixed |
Interpretation:

- Specialists:3native roles×4/8=12/24neutral role portraits.24national profession records are not24distinct jobs, and ancestry/sex are not populated for generated specialists. Do not commission624staff strata.
- Rival emblems:8nations×4/8=32/64full emblems; paired reduced marks add32/64physical files. Four persistent rivals/nation gives a natural4slot minimum, but event-local collisions remain possible. Neutral abstract motifs do not invent official heraldry.
- Chariots3/12and equipment6/12are visual pools, not new mechanical classes. Native attributes/quality determine gameplay; generic art avoids unsupported item subtypes.
- Race RUs:9species×1/3=9/27static images; masks add9/27. This is not13driver ancestries×39stocks×chariots×liveries. One covered driver and generic shared chassis keep first templates compatible; portraits provide identity detail.
- Fixed29Run icons include21passive/immediate+8Active Abilities.8Legacy upgrade icons are reused in equipped slots; no duplicate B06files. Empty slots remain CSS. Eight race action glyphs are6Signs+NoSign+emptyAbility; selectedAbility reuses its Run icon.
-9championship marks=8national Prestige+intro; renewable locals derive host mark+live title.6native economic trophy images are separate; national asset marks do not create new awarded trophy IDs.
- World8maps+8sample-team emblems are distinct logical filenames, not new geography or playable rivals. Sample emblems may share the generic T-emblem bytes.
- Seven facility illustrations and6service icons,3contract icons,5weather icons,3incident icons cover enumerable records. UI labels, attributes, standings, meters, selection, errors and radio remain live HTML/CSS/Canvas.
- Brand3originals and21approved UI state exports are counted as required reuse, with unknown actual dimensions/rights until originals arrive. Fonts2approved faces minimum; target adds2body weights if approved.

## 4. Procedural identity assignment without gameplay/save changes

Existing identity roots are available: generated `contextFingerprint`, canonical ancestry/species/stock, stable organization/member IDs, and Owner profile/career identity. Use a separate presentation-domain hash—not simulation RNG—to select among compatible catalog slots. `contextFingerprint` transfers with acquired identity and is preferable to a new owned asset ID. Player driver visual sex is available in `m6.driverVisuals`, but acquisition continuity is currently blocked by the verified M6 defect. Rival/local/Den sex remains unknown. See `src/career/m6/current.js:20` and `src/career/m5/d2/generation.js:23`.

Proposed resolution order: exact compatible approved/pool artwork → same-ancestry sex-neutral or same-species stock-neutral template → non-anatomical unknown medallion/procedural race marker. Never borrow another ancestry/sex/species merely because it has more available art. Compatibility filters precede aesthetic nationality/role/quality tags. Owner and Driver share only role-neutral portraits. Default unknown is resolution logic, not a new save value.

Stable identity versus expansion: modulo a changing list or rendezvous hashing over a growing pool WILL change some existing depictions. To avoid any new save-schema pin, predeclare target slot IDs/window from first M7release, fill unfinished slots with identical compatible template bytes, and freeze resolver-v1 ordering. Replacing an existing slot's bytes changes only its artwork. Appended slots stay outside the old resolver window. A future resolver expansion/version pin or user-selected portrait is a separate approval; do not retrofit fields into exact sidecar-v2. MVP4/group and target12/group must not be switched silently on an existing save. Prefer target slot reservation upfront, even if only minimum unique art is finished.

Repeat avoidance: choose enough variants and accept occasional deterministic duplicates. Reassigning based on visible sorted roster makes portraits change when a card disappears or is acquired. Batch-without-replacement also needs retained birth-cohort information to survive acquisition. A strict no-repeat guarantee needs a durable presentation assignment map/version and separate approval. This audit recommends no such extension for initial M7.

## 5. Storage, decode and packaging estimates

**Measured current:** M6HTML5,793,928bytes=5.526MiB;8unique proof image payloads=28,640raw bytes, `38,396`data-URL characters. Each appears **3times** in the final HTML (outer/embedded viewer content); manifest dedup is local to a table, not outer cross-document packaging. No new M7art was generated to measure size.

| Assumed unique finished-art scenario | Raw art+font MiB | Base64 payload MiB | One shared table+M6base+1KiB/slot MiB | If duplicated3× MiB |
|---|---|---|---|---|
| Minimum | 12.56 | 16.75 | 22.66 | 56.16 |
| Target | 39.34 | 52.45 | 58.82 | 163.72 |
These are planning budgets, NOT measured exports or a promised file size. Assumptions are in CSV `planning_KiB_per_unique_file`:50KiB/person/equipment portrait,60KiB/beast,90KiB/chariot,16KiB/RU,4KiB/mask,140KiB/stable,700KiB/background,2KiB/small SVG,8KiB/emblem/UI source budget,128KiB/font,256KiB/logo. Actual originals and compression can be materially smaller/larger. Metadata1KiB/slot is an estimate. Illustration entropy matters; SVG is not universally smaller/faster than PNG. The old≤5MiB first-proof HTML target is already exceeded by the current5.526MiB application before a production catalog.

For identical-template catalog, estimated new art payloads are49/53template images+24library image exports, not395/866unique illustrations. Estimate a fewKiB per simple template, up to16KiB for a flat1920×1080background, plus the unknown logo/font originals and manifest metadata. A planning total around8–10MiB HTML is plausible with one shared payload table, but is unmeasured and not an acceptance guarantee. Finished target unique art may approach59MiB under the stated budgets; duplicating it through three frame documents could exceed160MiB. Deduplicate before embedding, preserve separate logical IDs and forbid external fetches. No lossy conversion or format switch is assumed.

If every known-size file were decoded simultaneously, arithmetic lower bounds are **90.8MiB minimum / 285.6MiB target**, excluding unknown logo/UI sizes and DOM/GPU/font overhead. Identical-payload decoding should be shared; current ID-keyed eager loading does not provide this. A256×256RGBA portrait costs0.25MiB;1920×1080background costs7.91MiB.

Recommended future proof: versioned registry bound1024logical entries (881with retained legacy), shared lazy payload cache≈24MiB/64decoded images, composite cache≈8MiB and aggregate presentation budget≈96MiB including existing tiles/maps/geometry. These are engineering proposals requiring review and measurement, NOT authorized/current limits. No cap is changed in the audit. A large decoded background must not evict every portrait silently. Use visible-screen requirements, reference-safe shared resources, bounded rasterizations and explicit reload-after-eviction. Measure each document's allocations; a per-cache bound is not process memory.

## 6. Count validation

The176-row catalog plan is the count authority; filename map expands870target file paths,397of which belong to the alternative minimum catalog. Alias/procedural rows are intentionally0additional files. Unknown/deferred rows are blank. Shared Owner portraits/Barn assets/equipped Legacy icons are not added twice. The49/53template list and per-family size arithmetic are in `evidence/reconciled-quantities.json`. No images, placeholders or runtime manifests were produced.
